sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/table/TablePersoController",
	"./DemoPersoService",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment"

], function(Controller, TablePersoController, DemoPersoService, JSONModel, mBox, Filter, FilterOperator, Fragment) {
	"use strict";

	return Controller.extend("ZFLEXIPAY_APPR.controller.Main", {
		onInit: function() {
			//Global Model
			this._oModel = this.getOwnerComponent().getModel();
			//Routing
			this._oRouter = this.getOwnerComponent().getRouter();
			this._oRouter.getRoute("Main").attachPatternMatched(this._onRouteMatched, this);
			this.token = this.getOwnerComponent().getModel().getSecurityToken();

		},
		_onRouteMatched: function() {
			var that = this;

			/*Table Perso for Column*/
			this._oTPC = new TablePersoController({
				table: this.byId("reportTable"),
				persoService: DemoPersoService
			});
			//	this._onAPICall();
			this.onProgramApi();
			var oDate = new Date();
			// var oModel = new JSONModel([{
			// 	"Amount1": '2000',
			// 	"CheckNumber1": "456477",
			// 	"CheckDate1": oDate,
			// 	"Amount2": '2000',
			// 	"CheckNumber2": "456748",
			// 	"CheckDate2": oDate,
			// 	"Amount3": '2000',
			// 	"CheckNumber3": "456748",
			// 	"CheckDate3": oDate,
			// 	"TotalAmount": "6000"

			// }, {

			// 	"Amount1": '1000',
			// 	"CheckNumber1": "456748",
			// 	"CheckDate1": new Date(),
			// 	"Amount2": '1000',
			// 	"CheckNumber2": "456748",
			// 	"CheckDate2": new Date(),
			// 	"Amount3": '1000',
			// 	"CheckNumber3": "456748",
			// 	"CheckDate3": new Date(),
			// 	"TotalAmount": "3000"
			// }, {
			// 	"Amount1": '3000',
			// 	"CheckNumber1": "456748",
			// 	"CheckDate1": new Date(),
			// 	"Amount2": '3000',
			// 	"CheckNumber2": "456748",
			// 	"CheckDate2": new Date(),
			// 	"Amount3": '3000',
			// 	"CheckNumber3": "456748",
			// 	"CheckDate3": new Date(),
			// 	"TotalAmount": "9000"

			// }]);
			// this.getView().setModel(oModel, "alocal");

		},

		onChngeProgram: function(oEvent) {
			var aKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var aStatus = "";
			var bStatus = "";
			if (aKey === 'pen') {
				aStatus = "01";
				bStatus = "04";
			} else if (aKey === 'app') {
				aStatus = "02";
				bStatus = "05";
			} else if (aKey === 'rej') {
				aStatus = "03";
				bStatus = "05";

			}
			var oProgKey = oEvent.getSource().getSelectedKey();
			this.Programid = oEvent.getSource().getSelectedKey();

			var aFilter = [];
			var oModel = new JSONModel(),
				that = this;
			aFilter.push(new sap.ui.model.Filter("Zprogram", "EQ", oProgKey));
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/InstallmentChequeSet", {
				filters: aFilter,
				success: function(odata) {
					sap.ui.core.BusyIndicator.hide();
					if (odata.results.length > 0) {
						oModel.setData(odata.results);
						that.getView().setModel(oModel, "StudentsDataModel");
					} else {
						oModel.setData([]);
						that.getView().setModel(oModel, "StudentsDataModel");

					}
					var a = 0,
						b = 0,
						c = 0,
						d = 0;
					if (odata.results.length > 0) {
						for (var i = 0; i < odata.results.length; i++) {

							switch (odata.results[i].Status) {
								case '01':
									a = a + 1;
									break;
								case '02':
									b = b + 1;
									break;
								case '03':
									c = c + 1;
									break;
								case '04':
									d = d + 1;
									break;

							}

						}
					}
					var all = odata.results.length;
					var pending = a + d;
					var approve = b;
					var reject = c;

					that.getView().byId("iconall").setCount(all);
					that.getView().byId("iconpen").setCount(pending);
					that.getView().byId("iconacc").setCount(approve);
					that.getView().byId("icondec").setCount(reject);

					that._FilterApi(aStatus, bStatus);

				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					mBox.error(oMessage.error.message.value);

				}
			});

		},

		// onChngeProgram: function(oEvent) {
		// 	debugger;
		// 	var aKey = this.getView().byId("idIconTabBar").getSelectedKey();
		// 	var aStatus = "";
		// 	if (aKey === 'pen') {
		// 		aStatus = "01";
		// 	} else if (aKey === 'app') {
		// 		aStatus = "02";
		// 	} else if (aKey === 'rej') {
		// 		aStatus = "03";
		// 	}
		// 	var oProgKey = oEvent.getSource().getSelectedKey();
		// 	this.Programid = oEvent.getSource().getSelectedKey();

		// 	var aFilter = [];
		// 	var oModel = new JSONModel(),
		// 		that = this;
		// 	aFilter.push(new sap.ui.model.Filter("ZPROGRAM", "EQ", oProgKey));
		// 	sap.ui.core.BusyIndicator.show();
		// 	this.getOwnerComponent().getModel().read("/InstallmentStatusSet", {
		// 		urlParameters: {
		// 			"$expand": "NavStsToChq"
		// 		},
		// 		filters: aFilter,
		// 		success: function(odata) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 			if (odata.results.length > 0) {
		// 				oModel.setData(odata.results[0].NavStsToChq.results);
		// 				that.getView().setModel(oModel, "StudentsDataModel");
		// 			} else {
		// 				oModel.setData([]);
		// 				that.getView().setModel(oModel, "StudentsDataModel");

		// 			}
		// 			var a = 0,
		// 				b = 0,
		// 				c = 0;
		// 			if (odata.results.length > 0) {
		// 				for (var i = 0; i < odata.results[0].NavStsToChq.results.length; i++) {

		// 					switch (odata.results[0].NavStsToChq.results[i].Status) {
		// 						case '01':
		// 							a = a + 1;
		// 							break;
		// 						case '02':
		// 							b = b + 1;
		// 							break;
		// 						case '03':
		// 							c = c + 1;
		// 							break;
		// 					}

		// 				}
		// 			}
		// 			var all = odata.results[0].NavStsToChq.results.length;
		// 			var pending = a;
		// 			var approve = b;
		// 			var reject = c;

		// 			that.getView().byId("iconall").setCount(all);
		// 			that.getView().byId("iconpen").setCount(pending);
		// 			that.getView().byId("iconacc").setCount(approve);
		// 			that.getView().byId("icondec").setCount(reject);

		// 			that._FilterApi(aStatus);

		// 		},
		// 		error: function(oError) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 			var oMessage = JSON.parse(oError.responseText);
		// 			mBox.error(oMessage.error.message.value);

		// 		}
		// 	});

		// },
		statusText: function(oVal) {
			if (oVal == "04") {
				return "Modified";
			} else if (oVal == "01") {
				return "Applied";
			} else if (oVal == "02") {
				return "Approved";

			} else if (oVal == "03") {
				return "Rejected";

			}

		},
		onProgramApi: function() {
			var that = this;
			var FinalAmt = 0;
			var oModel = new JSONModel();
			this.getView().setModel(oModel);
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/programSet", {
				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();
					oModel.setData(oData.results);
					that.getView().setModel(oModel, "ProgramModel");
				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					mBox.error(oMessage.error.message.value);

				}
			});

		},
		onApproveReject: function(oEvent, sKey) {
			var that = this;
			var aObj = this.getView().getModel("local").getProperty("/");
			var oAmount = 0;
			var oFlag = false;
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});

			aObj.forEach(function(ele) {
				//	ele.CheckDate = dateFormat.format(ele.CheckDate);
				if (ele.Amount === "") {
					ele.Amount = 0;
				}
				oAmount = oAmount + parseFloat(ele.Amount);
				if (ele.CheckDate === null || ele.CheckDate === '' || ele.Amount === 0) {
					oFlag = true;
				}
			});
			if (oFlag) {
				mBox.error("Please fill all the details");
				return true;

			}
			if (oAmount !== parseFloat(this.SelectedObj.TOTAL_AMT)) {
				mBox.error("Addition of Emi amount should be equal Total Amount");
				return true;

			}

			var oPayload = {};
			oPayload.RollNo = this.SelectedObj.RollNo;
			oPayload.TOTAL_AMT = this.SelectedObj.TOTAL_AMT;
			oPayload.StudentObjid = this.SelectedObj.StudentObjid;
			oPayload.Zprogram = this.SelectedObj.Zprogram;
			oPayload.Zsession = this.SelectedObj.Zsession;
			oPayload.Zstage = this.SelectedObj.Zstage;
			oPayload.Zyear = this.SelectedObj.Zyear;

			oPayload.ChequeNo1 = aObj[0].CheckNumber;
			oPayload.ValueDate1 = aObj[0].CheckDate;
			oPayload.PaymentAmt1 = aObj[0].Amount;
			oPayload.PaymentAmtDate1 = this.SelectedObj.PaymentAmtDate1;
			oPayload.PaymentAmtDate2 = this.SelectedObj.PaymentAmtDate2;
			oPayload.PaymentAmtDate3 = this.SelectedObj.PaymentAmtDate3;

			oPayload.ChequeNo2 = aObj[1].CheckNumber;
			oPayload.ValueDate2 = aObj[1].CheckDate;
			oPayload.PaymentAmt2 = aObj[1].Amount;
			oPayload.ChequeNo3 = aObj[2].CheckNumber;
			oPayload.ValueDate3 = aObj[2].CheckDate;
			oPayload.PaymentAmt3 = aObj[2].Amount;

			if (aObj.length === 4) {
				oPayload.ChequeNo4 = aObj[3].CheckNumber;
				oPayload.ValueDate4 = aObj[3].CheckDate;
				oPayload.PaymentAmt4 = aObj[3].Amount;
			}
			if (aObj.length === 5) {
				oPayload.ChequeNo4 = aObj[3].CheckNumber;
				oPayload.ValueDate4 = aObj[3].CheckDate;
				oPayload.PaymentAmt4 = aObj[3].Amount;

				oPayload.ChequeNo5 = aObj[4].CheckNumber;
				oPayload.ValueDate5 = aObj[4].CheckDate;
				oPayload.PaymentAmt4 = aObj[4].Amount;

			}
			var aMsg;
			var ResMsg;
			if (sKey === "A") {
				aMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("32");
				ResMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("34");
				oPayload.Status = "02";
			} else if (sKey === "R") {
				aMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("33");
				ResMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("35");
				oPayload.Status = "03";

			} else if (sKey === "M") {
				aMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("Modify");
				ResMsg = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("Modified");
				oPayload.Status = "04";

			}
			mBox.confirm(aMsg, {
				actions: [mBox.Action.YES, mBox.Action.NO],
				emphasizedAction: mBox.Action.OK,
				onClose: function(oAction) {
					if (oAction === "YES") {
						sap.ui.core.BusyIndicator.show();
						var oDataModel = that.getOwnerComponent().getModel();
						oDataModel.create("/InstallmentChequeSet", oPayload, {
							success: function(oResponse) {
								sap.ui.core.BusyIndicator.hide();
								mBox.success(ResMsg, {
									actions: [mBox.Action.OK],
									emphasizedAction: mBox.Action.OK,
									onClose: function(oAction) {
										that._pDialog.close();
										//   that.onClose();
										that._onAPICall();

									}
								});

							},
							error: function(oError) {
								// window.location.reload();

								sap.ui.core.BusyIndicator.hide();

							}
						});
					} else {
						that.getView().byId("dynamicPageId").setBusy(false);
					}
				}
			});

		},
		_State: function(oVal) {
			if (oVal === "02" || oVal === "05" || oVal === "06") {
				return "Success";
			} else if (oVal === "01" || oVal === "08" || oVal === "04") {
				return "Warning";
			} else if (oVal === "03" || oVal === "07") {
				return "Error";
			}
		},

		onAdd: function() {
			sap.ui.core.Fragment.byId("idFragemts", "idModify").setVisible(true);
			sap.ui.core.Fragment.byId("idFragemts", "idApprove").setVisible(false);
			var obj = sap.ui.core.Fragment.byId("idFragemts", "idTableFragment");
			// if (this.getView().getModel("local").getProperty("/").length >= 5) {
			// 	mBox.error("Cant add More than 5 rows");
			// 	return true;
			// }
			if (this.getView().getModel("local").getProperty("/").length === 4) {
				sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(false);

			} else {
				sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(true);

			}
			var aitems = {
				"CheckNumber": "",
				"CheckDate": null,
				"Amount": "",
				"flag": true
			};
			var oNewRow = this.getView().getModel("local").getProperty("/");
			oNewRow.push(aitems);
			this.getView().getModel("local").setProperty("/", oNewRow);
			this.getView().getModel("local").refresh();

		},
		onFragment: function() {
			var oTable = this.byId("reportTable");
			var iIndex = oTable.getSelectedIndex();
			var oView = this.getView(),
				that = this;
			if (iIndex === -1) {
				mBox.error("Please select a Row");
				return true;
			}
			this.SelectedObj = oTable.getContextByIndex(iIndex).getObject();

			//  oHistoryData = oEvent.getSource().getBindingContext("HistoryModel").getObject(),
			if (this.SelectedObj.PaymentAmt3 !== "0.000" && this.SelectedObj.PaymentAmt4 === "0.000") {
				var oModel = new JSONModel([{
					"Amount": this.SelectedObj.PaymentAmt1,
					"CheckNumber": this.SelectedObj.ChequeNo1,
					"CheckDate": this.SelectedObj.ValueDate1,
					"flag": false

				}, {

					"Amount": this.SelectedObj.PaymentAmt2,
					"CheckDate": this.SelectedObj.ValueDate2,
					"CheckNumber": this.SelectedObj.ChequeNo2,
					"flag": false

				}, {
					"Amount": this.SelectedObj.PaymentAmt3,
					"CheckDate": this.SelectedObj.ValueDate3,
					"CheckNumber": this.SelectedObj.ChequeNo3,
					"flag": false

				}]);
				this.getView().setModel(oModel, "local");
			}
			if (this.SelectedObj.PaymentAmt4 !== "0.000" && this.SelectedObj.PaymentAmt5 === "0.000") {
				var oModel = new JSONModel([{
					"Amount": this.SelectedObj.PaymentAmt1,
					"CheckNumber": this.SelectedObj.ChequeNo1,
					"CheckDate": this.SelectedObj.ValueDate1,
					"flag": false

				}, {

					"Amount": this.SelectedObj.PaymentAmt2,
					"CheckDate": this.SelectedObj.ValueDate2,
					"CheckNumber": this.SelectedObj.ChequeNo2,
					"flag": false

				}, {
					"Amount": this.SelectedObj.PaymentAmt3,
					"CheckDate": this.SelectedObj.ValueDate3,
					"CheckNumber": this.SelectedObj.ChequeNo3,
					"flag": false

				}, {
					"Amount": this.SelectedObj.PaymentAmt4,
					"CheckDate": this.SelectedObj.ValueDate4,
					"CheckNumber": this.SelectedObj.ChequeNo4,
					"flag": false

				}]);
				this.getView().setModel(oModel, "local");
			}
			if (this.SelectedObj.PaymentAmt5 !== "0.000") {
				var oModel = new JSONModel([{
					"Amount": this.SelectedObj.PaymentAmt1,
					"CheckNumber": this.SelectedObj.ChequeNo1,
					"CheckDate": this.SelectedObj.ValueDate1,
					"flag": false

				}, {

					"Amount": this.SelectedObj.PaymentAmt2,
					"CheckDate": this.SelectedObj.ValueDate2,
					"CheckNumber": this.SelectedObj.ChequeNo2,
					"flag": false

				}, {
					"Amount": this.SelectedObj.PaymentAmt3,
					"CheckDate": this.SelectedObj.ValueDate3,
					"CheckNumber": this.SelectedObj.ChequeNo3,
					"flag": false

				}, {
					"Amount": this.SelectedObj.PaymentAmt4,
					"CheckDate": this.SelectedObj.ValueDate4,
					"CheckNumber": this.SelectedObj.ChequeNo4,
					"flag": false

				}, {
					"Amount": this.SelectedObj.PaymentAmt5,
					"CheckDate": this.SelectedObj.ValueDate5,
					"CheckNumber": this.SelectedObj.ChequeNo5,
					"flag": false

				}]);
				this.getView().setModel(oModel, "local");

			}

			if (!this._pDialog) {

				this._pDialog = sap.ui.xmlfragment("idFragemts", "ZFLEXIPAY_APPR.fragments.Dialog", this);
				this.getView().addDependent(this._pDialog);
				if (this.SelectedObj.PaymentAmt5 !== "0.000") {
					sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(false);

				} else {
					sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(true);

				}

			}
			if (this.SelectedObj.PaymentAmt5 !== "0.000") {
				sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(false);

			} else {
				sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(true);

			}

			this._pDialog.open();

		},
		onClose: function() {
			sap.ui.core.Fragment.byId("idFragemts", "idModify").setVisible(false);
			sap.ui.core.Fragment.byId("idFragemts", "idApprove").setVisible(true);

			this._pDialog.close();
			//this._pDialog.destroy(true);

		},
		onDeleteRow: function(oEvent) {

			var oModel = this.getView().getModel("local").getProperty("/");
			sap.ui.core.Fragment.byId("idFragemts", "idAdd").setEnabled(true);

			if (this.SelectedObj.PaymentAmt3 !== "0.000" && this.SelectedObj.PaymentAmt4 === "0.000") {
				if (oModel.length === 4) {
					sap.ui.core.Fragment.byId("idFragemts", "idModify").setVisible(false);
					sap.ui.core.Fragment.byId("idFragemts", "idApprove").setVisible(true);
				}

			}
			if (this.SelectedObj.PaymentAmt4 !== "0.000" && this.SelectedObj.PaymentAmt5 === "0.000") {
				if (oModel.length === 5) {
					sap.ui.core.Fragment.byId("idFragemts", "idModify").setVisible(false);
					sap.ui.core.Fragment.byId("idFragemts", "idApprove").setVisible(true);
				}

			}

			var oSpath = oEvent.getSource().getBindingContext("local").sPath,
				oIndex = oSpath.split('/')[1];
			oModel.splice(oIndex, 1);
			this.getView().getModel("local").refresh();

		},
		openPersoDialogrep: function(oEvt) {
			this._oTPC.openDialog();
		},
		_onAPICall: function() {
			var aKey = this.getView().byId("idIconTabBar").getSelectedKey();
			var aStatus = "";
			var bStatus = "";
			if (aKey === 'pen') {
				aStatus = "01";
				bStatus = "04";

			} else if (aKey === 'app') {
				aStatus = "02";
				bStatus = "05";

			} else if (aKey === 'rej') {
				aStatus = "03";
				bStatus = "05";

			}
			//	var oProgKey = oEvent.getSource().getSelectedKey();

			var aFilter = [];
			var oModel = new JSONModel(),
				that = this;
			aFilter.push(new sap.ui.model.Filter("Zprogram", "EQ", this.Programid));
			sap.ui.core.BusyIndicator.show();
			this.getOwnerComponent().getModel().read("/InstallmentChequeSet", {
				filters: aFilter,
				success: function(odata) {
					sap.ui.core.BusyIndicator.hide();
					if (odata.results.length > 0) {
						oModel.setData(odata.results);
						that.getView().setModel(oModel, "StudentsDataModel");
					} else {
						oModel.setData([]);
						that.getView().setModel(oModel, "StudentsDataModel");

					}
					var a = 0,
						b = 0,
						c = 0,
						d = 0;
					if (odata.results.length > 0) {
						for (var i = 0; i < odata.results.length; i++) {

							switch (odata.results[i].Status) {
								case '01':
									a = a + 1;
									break;
								case '02':
									b = b + 1;
									break;
								case '03':
									c = c + 1;
									break;
								case '04':
									d = d + 1;
									break;
							}

						}
					}
					var all = odata.results.length;
					var pending = a + d;
					var approve = b;
					var reject = c;

					that.getView().byId("iconall").setCount(all);
					that.getView().byId("iconpen").setCount(pending);
					that.getView().byId("iconacc").setCount(approve);
					that.getView().byId("icondec").setCount(reject);

					that._FilterApi(aStatus, bStatus);

				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					mBox.error(oMessage.error.message.value);

				}
			});

		},

		// _onAPICall: function() {
		// 	debugger;
		// 	var aKey = this.getView().byId("idIconTabBar").getSelectedKey();
		// 	var aStatus = "";
		// 	if (aKey === 'pen') {
		// 		aStatus = "01";
		// 	} else if (aKey === 'app') {
		// 		aStatus = "02";
		// 	} else if (aKey === 'rej') {
		// 		aStatus = "03";
		// 	}
		// 	//	var oProgKey = oEvent.getSource().getSelectedKey();

		// 	var aFilter = [];
		// 	var oModel = new JSONModel(),
		// 		that = this;
		// 	aFilter.push(new sap.ui.model.Filter("ZPROGRAM", "EQ", this.Programid));
		// 	sap.ui.core.BusyIndicator.show();
		// 	this.getOwnerComponent().getModel().read("/InstallmentStatusSet", {
		// 		urlParameters: {
		// 			"$expand": "NavStsToChq"
		// 		},
		// 		filters: aFilter,
		// 		success: function(odata) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 			if (odata.results.length > 0) {
		// 				oModel.setData(odata.results[0].NavStsToChq.results);
		// 				that.getView().setModel(oModel, "StudentsDataModel");
		// 			} else {
		// 				oModel.setData([]);
		// 				that.getView().setModel(oModel, "StudentsDataModel");

		// 			}
		// 			var a = 0,
		// 				b = 0,
		// 				c = 0;
		// 			if (odata.results.length > 0) {
		// 				for (var i = 0; i < odata.results[0].NavStsToChq.results.length; i++) {

		// 					switch (odata.results[0].NavStsToChq.results[i].Status) {
		// 						case '01':
		// 							a = a + 1;
		// 							break;
		// 						case '02':
		// 							b = b + 1;
		// 							break;
		// 						case '03':
		// 							c = c + 1;
		// 							break;
		// 					}

		// 				}
		// 			}
		// 			var all = odata.results[0].NavStsToChq.results.length;
		// 			var pending = a;
		// 			var approve = b;
		// 			var reject = c;

		// 			that.getView().byId("iconall").setCount(all);
		// 			that.getView().byId("iconpen").setCount(pending);
		// 			that.getView().byId("iconacc").setCount(approve);
		// 			that.getView().byId("icondec").setCount(reject);

		// 			that._FilterApi(aStatus);

		// 		},
		// 		error: function(oError) {
		// 			sap.ui.core.BusyIndicator.hide();
		// 			var oMessage = JSON.parse(oError.responseText);
		// 			mBox.error(oMessage.error.message.value);

		// 		}
		// 	});

		// },
		onexlDownload: function() {
			var aTableData = [],
				oTable = this.getView().byId("reportTable").getBinding().aIndices,
				o18n = this.getView().getModel("i18n").getResourceBundle();
			oTable.forEach(function(index) {
				aTableData.push(this.getView().byId("reportTable").getModel("StudentsDataModel").getData()[index]);
			}, this);
			var oXlFile = new JSONModel(aTableData);
			jQuery.sap.require("sap.ui.core.util.Export");
			jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");

			var oExport = new sap.ui.core.util.Export({

				// Type that will be used to generate the content. Own ExportType's can be created to support other formats
				exportType: new sap.ui.core.util.ExportTypeCSV({
					separatorChar: "\t",
					mimeType: "application/vnd.ms-excel",
					charset: "utf-8",
					fileExtension: "xls"
				}),
				// Pass in the model created above
				models: oXlFile,

				// binding information for the rows aggregation 
				rows: {
					path: "/"

				},
				// column
				columns: [{
						name: o18n.getText("Status"),
						template: {
							content: "{Status}"
						}
					}, {
						name: o18n.getText("Studentname"),
						template: {
							content: "{StdName}"
						}
					}, {
						name: o18n.getText("Student_roll"),
						template: {
							content: "{RollNo}"
						}
					}, {
						name: o18n.getText("prg"),
						template: {
							content: "{PRG_TEXT}"
						}
					}, {
						name: o18n.getText("year"),
						template: {
							content: "{Zyear}"
						}
					}, {
						name: o18n.getText("Stage"),
						template: {
							content: "{STAGE_TEXT}"
						}
					}

				]

			});
			// download exported file
			oExport.saveFile("Report").catch(function(oError) {
				mBox.error(o18n.getText("31") + oError);
			}).then(function() {
				oExport.destroy();
			});

		},

		// onFilterSelect: function(oEvent) {

		// 	var oBinding = this.byId("reportTable").getBinding("rows"),
		// 		sKey = oEvent.getParameter("key"),

		// 		// Array to combine filters
		// 		aFilters = [],
		// 		// Values for Filter
		// 		pen = "01",
		// 		app = "02", // Approve
		// 		rej = "03"; //Reject

		// 	if (sKey === "pen") {
		// 		var filter = new Filter("Status", FilterOperator.EQ, pen);
		// 		this.getView().byId("idCheckinfo").setVisible(true);

		// 		// this.getView().byId("idApprove").setVisible(true);
		// 		// this.getView().byId("idReject").setVisible(true);
		// 		this.getView().byId("reportTable").setSelectionMode("Single");
		// 		aFilters.push(filter);
		// 	} else if (sKey === "app") {
		// 		// this.getView().byId("idApprove").setVisible(false);
		// 		// this.getView().byId("idReject").setVisible(false);
		// 		this.getView().byId("idCheckinfo").setVisible(false);
		// 		filter = new Filter("Status", FilterOperator.EQ, app);
		// 		this.getView().byId("reportTable").setSelectionMode("None");
		// 		aFilters.push(filter);

		// 	} else if (sKey === "all") {
		// 		// this.getView().byId("idApprove").setVisible(false);

		// 		this.getView().byId("idCheckinfo").setVisible(false);

		// 		// this.getView().byId("idReject").setVisible(false);
		// 		this.getView().byId("reportTable").setSelectionMode("None");
		// 	} else if (sKey === "rej") {
		// 		this.getView().byId("idCheckinfo").setVisible(false);
		// 		// this.getView().byId("idApprove").setVisible(false);
		// 		// this.getView().byId("idReject").setVisible(false);
		// 		this.getView().byId("reportTable").setSelectionMode("None");
		// 		filter = new Filter("Status", FilterOperator.EQ, rej);
		// 		aFilters.push(filter);
		// 	}

		// 	oBinding.filter(aFilters);

		// },

		onFilterSelect: function(oEvent) {

			var oBinding = this.byId("reportTable").getBinding("rows"),
				sKey = oEvent.getParameter("key"),

				// Array to combine filters
				aFilters = [],
				// Values for Filter
				pen = "01",
				app = "02", // Approve
				rej = "03", //Reject
				mod = "04"; //Modified

			if (sKey === "pen") {
				//	var filter = new Filter("Status", FilterOperator.EQ, pen);
				this.getView().byId("idCheckinfo").setVisible(true);
				var InputFilter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, pen),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, mod)
					],
					and: false
				});
				this.getView().byId("reportTable").setSelectionMode("Single");
				aFilters.push(InputFilter);
			} else if (sKey === "app") {
				this.getView().byId("idCheckinfo").setVisible(false);
				//	filter = new Filter("Status", FilterOperator.EQ, app);
				var InputFilter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, app),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, '05')
					],
					and: false
				});

				this.getView().byId("reportTable").setSelectionMode("None");
				aFilters.push(InputFilter);

			} else if (sKey === "all") {

				this.getView().byId("idCheckinfo").setVisible(false);

				// this.getView().byId("idReject").setVisible(false);
				this.getView().byId("reportTable").setSelectionMode("None");
			} else if (sKey === "rej") {
				this.getView().byId("idCheckinfo").setVisible(false);
				this.getView().byId("reportTable").setSelectionMode("None");
				//	filter = new Filter("Status", FilterOperator.EQ, rej);
				var InputFilter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, rej),
						new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, '05')
					],
					and: false
				});

				aFilters.push(InputFilter);
			}

			oBinding.filter(aFilters);

		},
		// _FilterApi: function(aStatus) {
		// 	var oBinding = this.byId("reportTable").getBinding("rows"),
		// 		aFilters = [];
		// 	var filter = new Filter("Status", FilterOperator.EQ, aStatus);
		// 	//this.getView().byId("reportTable").setSelectionMode("None");
		// 	aFilters.push(filter);
		// 	oBinding.filter(aFilters);
		// 	//

		// },
		_FilterApi: function(aStatus, bStatus) {
			var oBinding = this.byId("reportTable").getBinding("rows"),
				aFilters = [];
			var InputFilter = new sap.ui.model.Filter({
				filters: [
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, aStatus),
					new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, bStatus)
				],
				and: false
			});
			aFilters.push(InputFilter);
			oBinding.filter(aFilters);

		},

		handleRowSelection: function(oEevnt) {
			var selectedRow = oEevnt.getSource().getSelectedIndices();
			var oTable = this.byId("reportTable");
			var iIndex = oTable.getSelectedIndex();

			if (selectedRow.length > 0) {
				var action = oTable.getContextByIndex(iIndex).getObject().Action;
				if (action === "01") {

					this.getView().byId("idAction").setVisible(true);
					this.getView().byId("idAction").setEnabled(true);
				} else {
					this.getView().byId("idAction").setVisible(false);
				}
			} else {
				this.getView().byId("idAction").setEnabled(false);
				this.getView().byId("idAction").setVisible(false);
			}

		},
		onClick: function() {
			var oTable = this.byId("reportTable");
			var iIndex = oTable.getSelectedIndex();
			this.SelectedObj = oTable.getContextByIndex(iIndex).getObject();

		},
		handleUploadPress: function(oEvent) {

			var id = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("StudentObjid");
			var program = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("Zprogram");
			var session = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("Zsession");
			var stage = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("Zstage");
			var year = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("Zyear");
			var ChequeNo1 = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("ChequeNo1");
			// var ChequeNo2 = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("ChequeNo2");
			// var ChequeNo3 = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("ChequeNo3");
			// var ChequeNo4 = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("ChequeNo4");
			// var ChequeNo5 = oEvent.getSource().getBindingContext("StudentsDataModel").getProperty("ChequeNo5");

			var oFileUploader = oEvent.getSource();
			if (ChequeNo1 !== '') {
				var Doctyp = "ZFICA_CH1";
			}
			// } else if (transType === '0003') {
			// 	Doctyp = "ZDIPLOMA";
			// } else if (transType === '0003') {
			// 	Doctyp = "ZDIPLOMA";
			// } else if (transType === '0003') {
			// 	Doctyp = "ZDIPLOMA";
			// } else if (transType === '0003') {
			// 	Doctyp = "ZDIPLOMA";
			// }
			oFileUploader.destroyHeaderParameters();

			var oToken = new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.token
			});
			var slash="/";
			var doc = "D" + ":" + slash + 1000000001 + slash + 1000000001 + "." + "PDF";
			var oSlug = new sap.ui.unified.FileUploaderParameter({
				
				name: "slug",
				
				value: encodeURIComponent(id) + "," + program + "," + year + "," + session + "," + stage + "," + Doctyp  + "," + doc
			});
			var oReq = new sap.ui.unified.FileUploaderParameter({
				name: "X-Requested-With",
				value: "X"
			});
			oFileUploader.insertHeaderParameter(oToken);
			oFileUploader.insertHeaderParameter(oSlug);
			oFileUploader.insertHeaderParameter(oReq);
			oFileUploader.upload();

		},
		handleTypeMissmatch: function(oEvent) {
			var aFileTypes = oEvent.getSource().getFileType();
			aFileTypes.map(function(sType) {
				return "*." + sType;
			});
			sap.m.MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
				" is not supported. Choose one of the following types: " +
				aFileTypes.join(", "));
		},
		handleFileSizeExceed: function() {
			sap.m.MessageToast.show("The file size exceed. Choose less than 2 MB.");
		},
		onViewFound: function() {
			var doc = "ZINSTALL";
			sap.m.URLHelper.redirect("/sap/opu/odata/SAP/ZFICA_ST_INSTALLMENT_PLAN_APPR_SRV/DocumentsSet(StudentObjid='" +
				encodeURIComponent(
					this.id) +
				"',Doctyp='" + doc + "')/$value", true);
		}
		
	

	});
});