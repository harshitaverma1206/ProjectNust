sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/format/DateFormat",
	"../util/Formatter"
], function(Controller, MessageBox, DateFormat,Formatter) {
	"use strict";

	return Controller.extend("MyTutionFee.controller.MyTution", {

		onInit: function() {

			// var oModel = this.getOwnerComponent().getModel("tutionModel");
			// this.getView().getModel("tutionModel");

			// var oBox = this.getView().byId("mini");
			// oBox.bindElement("tutionModel>/StudentHeader");

			this.onReadTutionData();
			this.onReadYearData();
			this.onReadPaymentData();
			this.onReadBalanceData();
		},
		// formatDate: function(oDate) {
		// 	if (!oDate || !(oDate instanceof Date)) {
		// 		return ""; // return empty string if oDate is not a valid date object
		// 	}
		// 	var oDateFormat = DateFormat.getDateInstance({
		// 		pattern: "dd/MM/yyyy"
		// 	});
		// 	return oDateFormat.format(oDate);
		// },

		onReadTutionData: function() {
			// var oModel = this.getOwnerComponent().getModel();

			var sServiceUrl = "/sap/opu/odata/sap/ZSL_MYTUTION_FEE_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);
			// var oJSONModel = new sap.ui.model.json.JSONModel();

			oModel.read("/StudentHeaderSet", {
				success: function(response) {

					var resarry = response.results;

					this.getView().byId("ac").setText(resarry[0].AcademicYear);
					this.getView().byId("additional").setText(resarry[0].AdditionalId);
					this.getView().byId("session").setText(resarry[0].AcademicSession);
					this.getView().byId("stage").setText(resarry[0].Stage);
					this.getView().byId("studentname").setText(resarry[0].StudentName);
					this.getView().byId("studentcat").setText(resarry[0].StudentCat);
					this.getView().byId("progname").setText(resarry[0].ProgramName);

				}.bind(this),
				error: function(error) {
					//MessageBox.error("technical problem ");

				}
			});
		},

		onReadYearData: function() {
			// var oModel = this.getOwnerComponent().getModel();

			var ssServiceUrl = "/sap/opu/odata/sap/ZSL_MYTUTION_FEE_SRV/";
			var oModel1 = new sap.ui.model.odata.ODataModel(ssServiceUrl, true);
			this.getView().setModel(oModel1);
			// var oJSONModel1 = new sap.ui.model.json.JSONModel();

			oModel1.read("/YearDataSet", {
				success: function(response) {

					this.getView().byId("year").setText(response.results[0].Year);

				}.bind(this),
				error: function(error) {
					//MessageBox.error("technical problem ");

				}
			});
		},

		onReadPaymentData: function() {
			// var oModel = this.getOwnerComponent().getModel();

			var ssServiceUrl2 = "/sap/opu/odata/sap/ZSL_MYTUTION_FEE_SRV/";
			var oModel2 = new sap.ui.model.odata.ODataModel(ssServiceUrl2, true);
			this.getView().setModel(oModel2);

			oModel2.read("/PaymentHistorySet", {
				success: function(response) {
					var oJSONModel2 = new sap.ui.model.json.JSONModel();
					oJSONModel2.setData(response.results);
					this.getView().setModel(oJSONModel2, "paymentdateModel");

				}.bind(this),
				error: function(error) {
					//MessageBox.error("technical problem ");

				}
			});
		},

		onReadBalanceData: function() {
			// var oModel = this.getOwnerComponent().getModel();

			var ssServiceUrl3 = "/sap/opu/odata/sap/ZSL_MYTUTION_FEE_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(ssServiceUrl3, true);
			this.getView().setModel(oModel3);
			var oJSONModel3 = new sap.ui.model.json.JSONModel();

			oModel3.read("/BalanceDueSet", {
				success: function(response) {

					oJSONModel3.setData(response.results);
					// var length= response.results.length;
					// for(var i=0; i<length; i++){
					// var date=response.results[0].DueDate.slice(0,4)+"/"+response.results[0].DueDate.slice(4,6)+"/"+response.results[0].DueDate.slice(6,8);
					// 	oJSONModel3.setData(respon  );
					// }
					this.getView().setModel(oJSONModel3, "BalanceModel");

				}.bind(this),
				error: function(error) {
					//MessageBox.error("technical problem ");

				}
			});
		}

	});
});