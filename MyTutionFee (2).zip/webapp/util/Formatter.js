sap.ui.define([
	"sap/ui/core/Element",
	"sap/ui/core/format/DateFormat"
], function(Element, DateFormat) {
	"use strict";

	var Formatter = Element.extend("MyTutionFee.util.Formatter");

	// Formatter.formatDate = function (oDate, sledManagedValue, sPattern) {
	// 	var oDateOld=new Date(oDate),
	// 	 pattern = sPattern,
	// 		sDefaultDate = oDate ? oDateOld : new Date();
	// 	if (!pattern) {
	// 		pattern = "dd.MM.yyyy";
	// 	}
	// 	var oDateFormat = DateFormat.getDateInstance({
	// 		pattern: pattern
	// 	});
	// 	if (sledManagedValue === undefined) {
	// 		/*sledManagedValue = "";*/
	// 	} else if (sledManagedValue.toUpperCase() === "E") {
	// 		sDefaultDate = "";
	// 	} else {
	// 		sDefaultDate = oDateFormat.format(sDefaultDate);
	// 	}
	// 	return sDefaultDate;
	// };

	Formatter.formatDate = function(oDate) {

		if (!oDate || !(oDate instanceof Date)) {

			return ""; // return empty string if oDate is not a valid date object

		}

		var oDateFormat = DateFormat.getDateInstance({
			pattern: "dd-MM-yyyy"
		});

		return oDateFormat.format(oDate);

	};
	Formatter.formatDecimalValue = function(value) {

      return parseFloat(value).toFixed(3);
};
	return Formatter;

});



// sap.ui.define([], function(C) {
// 	"use strict";

// 	return {
		
// 	};
// });