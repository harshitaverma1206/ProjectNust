sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData"
], function(Controller, History, MessageToast, ODataModel, MessageBox, JSONModel, StandardListItem, CustomData) {
	"use strict";
	var selectedCheckboxText = "";
	var selectedCheckboxText2 = "";
	var note;
	return Controller.extend("HostelFacility.controller.HostelRequest", {
		draftData: {},
		onInit: function() {

			this.onReadCollageData();
			this.onReadProrityData();
			this.onReadResponsibiltyData();
			this.onReadNotificationData();

		},

		onReadCollageData: function() {
			// var oDropdown = this.getView().byId("label1");
			// var oCollageModel = this.getOwnerComponent().getModel("MainModel");

			// oCollageModel.read("/ZIPMPLANTVH", {
			// 	success: function(oData) {

			// 		oDropdown.setModel(new sap.ui.model.json.JSONModel(oData.results));

			// 	}.bind(this),
			// 	error: function(err) {

			// 	}
			// });
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label1");
			oModel.read("/ZIPMPLANTVH", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		onReadProrityData: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label3");
			oModel.read("/PriorityVHSet", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		onReadResponsibiltyData: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label4");
			oModel.read("/ResponsibilitiesSet", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);

					// Set the binding path of date picker control
					var oDatePicker = this.getView().byId("date");
					oDatePicker.bindProperty("value", {
						path: "ReportedOn"
					});
				},
				error: function(oError) {
					// Handle error
				}
			});

			// oModel.read("/ResponsibilitiesSet", {
			// 	success: function(response) {
			// 		var resarry = response.results;
			// 		this.getView().byId("By").setText(resarry[0].ReportedBy);
			// 		this.getView().byId("date").setValue(resarry[0].ReportedOn);

			// 	}.bind(this),
			// 	error: function(error) {
			// 		//MessageBox.error("technical problem ");
			// 	}
			// });

		},
		onReadNotificationData: function() {

			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);
			var oDropdown = this.getView().byId("label2");
			oModel.read("/I_PMNotificationTypeStdVH", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		// onSubmit: function(oEvent) {
		// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 	// oRouter.navTo("ChangeScreen");

		// 	// var selectedData =	this.getView().byId("label1").getSelectedItem().getText();

		// 	// 		oRouter.navTo("ChangeScreen",{
		// 	// 			selectedData:selectedData

		// 	// 		});

		// 	var selectedData = this.getView().byId("label1").getSelectedItem().getText();
		// 	var selectedData1 = this.getView().byId("label3").getSelectedItem().getText();
		// 	var selectedData2 = this.getView().byId("label8").getSelectedItem().getText();
		// 	var selectedData3 = this.getView().byId("label4").getSelectedItem().getText();
		// 	var selectedData4 = this.getView().byId("date").getValue();

		// 	oRouter.navTo("ChangeScreen", {
		// 		Code: selectedData,
		// 		Priority: selectedData1,
		// 		Notification: selectedData2,
		// 		By: selectedData3,
		// 		On: selectedData4

		// 	});

		// },

		onUploadButtonPress: function() {
			var fileUploader = this.byId("fileUploader");
			fileUploader.upload();
		},
		onFileUploadChange: function(event) {
			var uploadedFile = event.getParameter("files")[0];
			if (uploadedFile) {
				MessageToast.show("File selected: " +
					uploadedFile.name
				);
				this.handleFile(uploadedFile);
			} else {
				MessageToast.show("No file selected");
			}
		},
		handleFile: function(file) {
			var fileType = file.type.toLowerCase();
			if (fileType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
				// Excel file handling
				this.handleExcelFile(file);
			} else if (fileType === "text/csv") {
				// CSV file handling
				this.handleCsvFile(file);
			} else if (fileType.startsWith("image/")) {
				// Image file handling
				this.handleImageFile(file);
			} else if (fileType === "text/plain") {
				// Text file handling
				this.handleTextFile(file);
			} else {
				// Unsupported file type
				MessageToast.show("Unsupported file type. Please select a valid file.");
			}
		},
		handleExcelFile: function(file) {
			// Handle Excel file parsing
			MessageToast.show("Excel file uploaded: " +
				file.name
			);
		},
		handleCsvFile: function(file) {
			// Handle CSV file parsing
			MessageToast.show("CSV file uploaded: " +
				file.name
			);
		},
		handleImageFile: function(file) {
			// Handle image file parsing
			MessageToast.show("Image file uploaded: " +
				file.name
			);
		},
		handleTextFile: function(file) {
			// Handle text file parsing
			MessageToast.show("Text file uploaded: " +
				file.name
			);
		},
		onFileUploadComplete: function(event) {
			var response = event.getParameter("response");
			if (response) {
				MessageToast.show("File uploaded successfully");
			} else {
				MessageToast.show("File upload failed");
			}
		},

		onAddLink: function(oDialogName) {
			// if (!oDialogName) {
			// 			oDialogName = sap.ui.xmlfragment("HostelFacility.fragment.AddLink" , this);
			// 			this.getView().addDependent(oDialogName);
			// 		}
			// 	oDialogName.open();
			// }
			this._Dialog = sap.ui.xmlfragment("HostelFacility.fragment.AddLink",
				this);
			this._Dialog.open();

		},
		onOk: function() {
			this._Dialog.close();
		},
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View1", {}, true);
			}
		},

		onCheckboxSelect: function(oEvent) {
			// var oSourceCheckbox = oEvent.getSource();
			// var oView = this.getView();
			// var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			// for (var i = 0; i < aCheckboxes.length; i++) {
			// 	if (aCheckboxes[i] !== oSourceCheckbox) {
			// 		aCheckboxes[i].setEditable(oSourceCheckbox.getSelected() ? false : true);
			// 	}
			// }
			selectedCheckboxText = oEvent.getSource().getText(); // Store the text of the selected checkbox
			var oView = this.getView();
			var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			for (var i = 0; i < aCheckboxes.length; i++) {
				if (aCheckboxes[i] !== oEvent.getSource()) {
					aCheckboxes[i].setEditable(oEvent.getSource().getSelected() ? false : true);
				}
			}

		},
		onCheckboxSelect2: function(oEvent) {
			// var oSourceCheckbox = oEvent.getSource();
			// var oView = this.getView();
			// var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			// for (var i = 0; i < aCheckboxes.length; i++) {
			// 	if (aCheckboxes[i] !== oSourceCheckbox) {
			// 		aCheckboxes[i].setEditable(oSourceCheckbox.getSelected() ? false : true);
			// 	}
			// }
			selectedCheckboxText2 = oEvent.getSource().getText(); // Store the text of the selected checkbox
			var oView = this.getView();
			var aCheckboxes = [oView.byId("checkbox13"), oView.byId("checkbox14"), oView.byId("checkbox15")];
			for (var i = 0; i < aCheckboxes.length; i++) {
				if (aCheckboxes[i] !== oEvent.getSource()) {
					aCheckboxes[i].setEditable(oEvent.getSource().getSelected() ? false : true);
				}
			}

		},

		onCreate: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/"; // Replace this with your actual service URL
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			// Set the model to the view
			this.getView().setModel(oModel);

			var oTable = this.getView().byId("tableId");
			var aSelectedItems = oTable.getSelectedItems();

			var aData = [];
			aSelectedItems.forEach(function(oItem) {
				var oBindingContext = oItem.getBindingContext();
				var oSelectedData = oBindingContext.getObject();
				aData.push(oSelectedData);
			});

			var oPayload = {
				"data": aData
			};
			oModel.create("/CreateNotificationSet", oPayload, {
				success: function(oData, response) {
					// Handle success response

					MessageBox.success("created successfully");
				},
				error: function(oError) {
					// Handle error response
					MessageBox.error("getting error");
				}
			});
		},

		onSubmit: function(oEvent) {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// // oRouter.navTo("ChangeScreen");

			// // var selectedData =	this.getView().byId("label1").getSelectedItem().getText();

			// // 		oRouter.navTo("ChangeScreen",{
			// // 			selectedData:selectedData

			// // 		});

			// var selectedData = this.getView().byId("label1").getSelectedItem().getText();
			// var selectedData1 = this.getView().byId("label3").getSelectedItem().getText();
			// var selectedData2 = this.getView().byId("label8").getSelectedItem().getText();
			// var selectedData3 = this.getView().byId("label4").getSelectedItem().getText();
			// var selectedData4 = this.getView().byId("date").getValue();

			// oRouter.navTo("ChangeScreen", {
			// 	Code: selectedData,
			// 	Priority: selectedData1,
			// 	Notification: selectedData2,
			// 	By: selectedData3,
			// 	On: selectedData4

			// });
			// second
			// 	var oView = this.getView();

			// 	// var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/");
			// 	var oModel = this.getView().getModel();
			// 	// Add headers to the request
			// var clg = oView.byId("label1").getSelectedItem().getText();
			// 	var dateValue= oView.byId("date1").getDateValue();
			// 	var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 		pattern: "yyyyMMdd"
			// 	});
			// 	var oPayload = {
			// 		"CollegeCode":clg,
			// 		"RequestType": oView.byId("label2").getSelectedItem().getText(),
			// 		// RoomType: oView.byId("checkbox1").getSelected().toString(),
			// 	    "RoomType":selectedCheckboxText,
			//         "RequestDate": dateFormat.format(dateValue),
			// 		"Description": oView.byId("dis").getValue(),
			// 		"LongText": oView.byId("long").getValue(),
			// 		"Priority": oView.byId("label3").getSelectedItem().getText().split("-")[0],
			// 		"ReportedBy": oView.byId("label4").getSelectedItem().getText(),
			// 		"ReportedOn": oView.byId("date").getValue(),
			// 		"NotificationNumber": "",
			// 		"Message": ""

			// 	};
			// 	// var mParameter = {

			// 	// 	success: function(data, response) {
			// 	// 		MessageBox.success("created successfully");
			// 	// 		var successMessage = data.message;
			// 	// 		MessageBox.success("created successfully", successMessage);

			// 	// 	},
			// 	// 	error: function(err) {
			// 	// 		var errmsg = err.message;
			// 	// 		MessageBox.error(errmsg);

			// 	// 	}
			// 	// };
			// 	oModel.create("/CreateNotificationSet",oPayload, null, {
			// 			success: function(data, response) {
			// 			MessageBox.success("created successfully");
			// 			var successMessage = data.message;
			// 			MessageBox.success("created successfully", successMessage);

			// 		},
			// 		error: function(err) {
			// 			var errmsg = err.message;
			// 			MessageBox.error(errmsg);

			// 		}
			// 	}); 

			// ajax code

			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label1").getSelectedItem().getText();
			var dateValue = oView.byId("date1").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});

			var oData = {
				CollegeCode: clg,
				// RequestType: oView.byId("label2").getSelectedItem().getText(),
				RequestType: "N1 - Hostel FacilityReqst",
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
				RoomType: selectedCheckboxText,
				// RequestDate: oView.byId("date1").getValue(),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority: oView.byId("label3").getSelectedItem().getText().split("-")[0],
				ReportedBy: oView.byId("label4").getSelectedItem().getText(),
				ReportedOn: oView.byId("date").getValue(),
				NotificationNumber: "",
				Message: "X"

				// Add other properties as needed
			};

			$.ajax({
				url: oModel,
				method: "POST",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response

					var d = response.querySelector("Message").textContent;

					MessageBox.success("Data successfully updated in backend:" + d);

					note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					// MessageBox.success("created successfully", successMessage);

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageToast.show("data not added", error);
				}
			});
			this.refreshCombo();

		},
		refreshCombo: function() {
			var combo1 = this.getView().byId("label1");
			// var combo2 = this.getView().byId("label2");
			var combo3 = this.getView().byId("label3");
			var combo4 = this.getView().byId("label4");
			combo1.setSelectedKey("");
			// combo1.removeAllItems();

			combo3.setSelectedKey("");
			// combo3.removeAllItems();

			combo4.setSelectedKey("");
			// combo4.removeAllItems();

			var input1 = this.getView().byId("date1");
			var input2 = this.getView().byId("dis");
			var input3 = this.getView().byId("long");
			var input4 = this.getView().byId("date");
			input1.setValue("");
			input2.setValue("");
			input3.setValue("");
			input4.setValue("");

		},
		onSaveDraft: function() {
			// var oView = this.getView();
			// var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			// var clg = oView.byId("label1").getSelectedItem().getText();
			// var dateValue = oView.byId("date1").getDateValue();
			// var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 	pattern: "yyyyMMdd"
			// });

			// var oData = {
			// 	CollegeCode: clg,
			// 	RequestType: oView.byId("label2").getSelectedItem().getText(),
			// 	// RoomType: oView.byId("checkbox1").getSelected().toString(),
			// 	RoomType: selectedCheckboxText,
			// 	// RequestDate: oView.byId("date1").getValue(),
			// 	RequestDate: dateFormat.format(dateValue),
			// 	Description: oView.byId("dis").getValue(),
			// 	LongText: oView.byId("long").getValue(),
			// 	Priority: oView.byId("label3").getSelectedItem().getText().split("-")[0],
			// 	ReportedBy: oView.byId("label4").getSelectedItem().getText(),
			// 	ReportedOn: oView.byId("date").getValue(),
			// 	NotificationNumber: "",
			// 	Message: ""

			// 	// Add other properties as needed
			// };

			// $.ajax({
			// 	url: oModel,
			// 	method: "POST",
			// 	contentType: "application/json",
			// 	data: JSON.stringify(oData),

			// 	success: function(response) {
			// 		// Handle success response
			// 		MessageToast.show("Data successfully updated in backend:", response);
			// 		// var a = response.Message;

			// 		MessageBox.success("Data successfully created");

			// 	},
			// 	error: function(error) {
			// 		// Handle error response
			// 		MessageToast.show("data not added", error);
			// 	}

			// });
			// var btn = this.getView().byId("sub");
			// btn.setEnabled(false);
			// this.refreshCombo();

			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label1").getSelectedItem().getText();
			var dateValue = oView.byId("date1").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});

			var oData = {
				CollegeCode: clg,
				RequestType: oView.byId("label2").getSelectedItem().getText(),
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
				RoomType: selectedCheckboxText,
				// RequestDate: oView.byId("date1").getValue(),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority: oView.byId("label3").getSelectedItem().getText().split("-")[0],
				ReportedBy: oView.byId("label4").getSelectedItem().getText(),
				ReportedOn: oView.byId("date").getValue(),
				NotificationNumber: "",
				Message: ""

				// Add other properties as needed
			};

			$.ajax({
				url: oModel,
				method: "POST",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response) {
					// Handle success response
					// MessageToast.show("Data successfully updated in backend:", response);
					// var a = response.Message;
					var d = response.querySelector("Message").textContent;

					MessageBox.success("Data successfully updated in backend:" + d);

					note = response.querySelector("NotificationNumber").textContent;

					// 'name' now holds the value of 'd:name' element

				},
				error: function(error) {
					// Handle error response
					MessageToast.show("data not added", error);
				}

			});

			var btn = this.getView().byId("sub");
			btn.setEnabled(false);
			this.refreshCombo();

		},
		onCancel: function() {
			this.refreshCombo();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");

		},
		onChangeMenu: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(true);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(false);
		},
		onItemSelected: function(oEvent) {
			var selectedIndex = oEvent.getParameter("selectedItem").getKey();
			// Perform actions based on selected item
			switch (selectedIndex) {
				case "1":
					this.handleButton1Click();
					break;
				case "2":
					this.handleButton2Click();
					break;
				case "3":
					this.handleButton3Click();
					break;
				default:
					break;
			}
		},
		handleButton1Click: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(false);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(true);
			var Sub = this.getView().byId("sub");
			Sub.setVisible(true);
			var Sub2 = this.getView().byId("sub2");
			Sub2.setVisible(false);
			var Sub3 = this.getView().byId("sub3");
			Sub3.setVisible(false);

		},
		handleButton2Click: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(true);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(false);
			var Cr = this.getView().byId("sub2");
			Cr.setVisible(true);
			var Cr1 = this.getView().byId("sub");
			Cr1.setVisible(false);
			var Cr3 = this.getView().byId("sub3");
			Cr3.setVisible(false);
			// code for hide
			var hide1 = this.getView().byId("label10");
			hide1.setVisible(true);
			var hide2 = this.getView().byId("room1");
			hide2.setVisible(true);
			var hide3 = this.getView().byId("date16");
			hide3.setVisible(true);
			var hide4 = this.getView().byId("dis17");
			hide4.setVisible(true);
			var hide5 = this.getView().byId("long18");
			hide5.setVisible(true);
			var hide6 = this.getView().byId("label19");
			hide6.setVisible(true);
			var hide7 = this.getView().byId("label22");
			hide7.setVisible(true);
			var hide8 = this.getView().byId("date23");
			hide8.setVisible(true);
			var hide9 = this.getView().byId("general");
			hide9.setVisible(true);
			var hide10 = this.getView().byId("responsi");
			hide10.setVisible(true);

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			var oView = this.getView();
			var entityId = note;
			oModel.read("/CreateNotificationSet('" + entityId + "')", {

				success: function(oData) {
					// Handle successful data retrieval

					var defaultId = oData.NotificationNumber;
					this.getView().byId("notification").setValue(defaultId);

					var defaultIdCollege = oData.CollegeCode;
					this.getView().byId("label10").setValue(defaultIdCollege);

					// var defaultIdRequest = oData.RoomType;
					// this.getView().byId("room1").setValue(defaultIdRequest);

					var defaultIdDate = oData.RequestDate;
					this.getView().byId("date16").setValue(defaultIdDate);

					var defaultIdDis = oData.Description;
					this.getView().byId("dis17").setValue(defaultIdDis);

					var defaultIdPrior = oData.Priority;
					this.getView().byId("label19").setValue(defaultIdPrior);

					var defaultIdBy = oData.ReportedBy;
					this.getView().byId("label22").setValue(defaultIdBy);

					var defaultIdOn = oData.ReportedOn;
					this.getView().byId("date23").setValue(defaultIdOn);

					var defaultIdLong = oData.LongText;
					this.getView().byId("long18").setText(defaultIdLong);

				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			oView.setModel(oModel);

			var oModel2 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");

			oModel2.read("/NotificationNoSet", {
				success: function(oData) {
					// Handle successful data retrieval
				},
				error: function(oError) {
					// Handle error
				}
			});
		},

		handleButton3Click: function() {
			var Sub = this.getView().byId("sub");
			Sub.setVisible(false);
			var Sub2 = this.getView().byId("sub2");
			Sub2.setVisible(false);
			var Sub3 = this.getView().byId("sub3");
			Sub3.setVisible(true);

			// code for hide
			var hide1 = this.getView().byId("label10");
			hide1.setVisible(false);
			var hide2 = this.getView().byId("room1");
			hide2.setVisible(false);
			var hide3 = this.getView().byId("date16");
			hide3.setVisible(false);
			var hide4 = this.getView().byId("dis17");
			hide4.setVisible(false);
			var hide5 = this.getView().byId("long18");
			hide5.setVisible(false);
			var hide6 = this.getView().byId("label19");
			hide6.setVisible(false);
			var hide7 = this.getView().byId("label22");
			hide7.setVisible(false);
			var hide8 = this.getView().byId("date23");
			hide8.setVisible(false);
			var hide9 = this.getView().byId("general");
			hide9.setVisible(false);
			var hide10 = this.getView().byId("responsi");
			hide10.setVisible(false);

		},

		onUrl: function() {
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			var entityId = "NotificationNumber";
			oModel.read("/CreateNotificationSet('" + entityId + "')", {
				success: function(oData) {
					// Handle successful data retrieval
				},
				error: function(oError) {
					// Handle error
				}
			});
		},

		onSelectionChange: function(oEvent) {
			var selectedItem = oEvent.getParameter("selectedItem");
			var selectedId = selectedItem.getKey();
			// Assuming you have an ODataModel named "oDataModel2" for the second OData service
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			oModel.read("/CreateNotificationSet('" + selectedId + "')", {
				success: function(oData) {
					// Assuming property1 and property2 are properties in the returned data
					var property1 = oData.CollegeCode;
					// var property2 = oData.RequestType;
					var property3 = oData.RoomType;
					var property4 = oData.RequestDate;
					var property5 = oData.Priority;
					var property6 = oData.ReportedBy;
					var property7 = oData.ReportedOn;
					var property8 = oData.Description;
					var property9 = oData.LongText;

					// Assuming you have Input fields with IDs "inputField1" and "inputField2"
					this.getView().byId("label10").setValue(property1);
					// this.getView().byId("label11").setValue(property2);
					this.getView().byId("room1").setValue(property3);
					this.getView().byId("date16").setValue(property4);
					this.getView().byId("label19").setValue(property5);
					this.getView().byId("label22").setValue(property6);
					this.getView().byId("date23").setValue(property7);
					this.getView().byId("dis17").setValue(property8);
					this.getView().byId("long18").setValue(property9);
				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
		},

		refreshCombo1: function() {

			var input1 = this.getView().byId("dis17");
			var input2 = this.getView().byId("long18");
			var input3 = this.getView().byId("label19");
			var input4 = this.getView().byId("label22");
			var input5 = this.getView().byId("label10");
			var input6 = this.getView().byId("date16");
			var input7 = this.getView().byId("label22");
			var input8 = this.getView().byId("date23");
			var input9 = this.getView().byId("room1");
			var input10 = this.getView().byId("notification");

			input1.setValue("");
			input2.setValue("");
			input3.setValue("");
			input4.setValue("");
			input5.setValue("");
			input6.setValue("");
			input7.setValue("");
			input8.setValue("");
			input9.setValue("");
			input10.setValue("");

		},

		onSubmit3: function() {
			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label10").getValue();
			var dateValue = oView.byId("date16").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var ref = oView.byId("notification").getValue();

			var oData = {

				// CollegeCode: clg,
				// // RequestType: oView.byId("label2").getSelectedItem().getText(),
				// RequestType: "N1 - Hostel FacilityReqst",
				// // RoomType: oView.byId("checkbox1").getSelected().toString(),
				// RoomType: oView.byId("room1").getValue(),
				// // RequestDate: oView.byId("date1").getValue(),
				// RequestDate: dateFormat.format(dateValue),
				// Description: oView.byId("dis17").getValue(),
				// LongText: oView.byId("long18").getValue(),
				// Priority: oView.byId("label19").getValue(),
				// ReportedBy: oView.byId("label22").getValue(),
				// ReportedOn: oView.byId("date23").getValue(),
				NotificationNumber: ref,
				Message: "X"

				// Add other properties as needed
			};
			var supdateurl = oModel + "('" + ref + "')";
			$.ajax({
				url: supdateurl,
				method: "DELETE",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response

					// var d = response.querySelector("Message").textContent;

					// MessageBox.success("Data successfully updated in backend:" + d);

					// note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					MessageBox.success("Notification Number" + "'" + ref + "'" + "closed successfully");

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageBox.error("Notification Number" + "'" + ref + "'" + " already closed");

				}
			});
			var input10 = this.getView().byId("notification");
			input10.setValue("");
			this.refreshCombo1();
		},

		onSubmit2: function() {
			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label10").getValue();
			var dateValue = oView.byId("date16").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var ref = oView.byId("notification").getValue();

			var oData = {

				CollegeCode: clg,
				// RequestType: oView.byId("label2").getSelectedItem().getText(),
				RequestType: "N1 - Hostel FacilityReqst",
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
				RoomType: selectedCheckboxText2,
				// RequestDate: oView.byId("date1").getValue(),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis17").getValue(),
				LongText: oView.byId("long18").getValue(),
				Priority: oView.byId("label19").getValue(),
				ReportedBy: oView.byId("label22").getValue(),
				ReportedOn: oView.byId("date23").getValue(),
				NotificationNumber: ref,
				Message: "X"

				// Add other properties as needed
			};
			var supdateurl = oModel + "('" + ref + "')";
			$.ajax({
				url: supdateurl,
				method: "PUT",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					MessageBox.success("Notification updated successfully" + ref);
					var d = response.querySelector("Message").textContent;

					MessageBox.success("Data successfully updated in backend:" + d);

					note = response.querySelector("NotificationNumber").textContent;

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageToast.show("data not added", error);
				}
			});
			this.refreshCombo1();

		},

		_codeValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelFacility.fragments.ReferenceValueHelp", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onCodeValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "/NotificationNoSet",
				"entityProperties": {
					title: "{path:'NotifNo',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._codeValueHelpDialog(sBindingObj, null);

		},

		onDialogClose1: function(oEvent) {

			// var sTitle = oEvent.getParameter("selectedItem").getTitle();
			// this.getView().byId("notification").setValue(sTitle);
				var selectedItem = oEvent.getParameter("selectedItem");
				if(selectedItem){
					var sTitle = selectedItem.getTitle();
					this.getView().byId("notification").setValue(sTitle);
					this._fetchAdditionalData(sTitle);
					
				}
			

		},
		_fetchAdditionalData:function(selectedData){
			
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			oModel.read("/CreateNotificationSet('" + selectedData + "')", {
				success: function(oData) {
					// Assuming property1 and property2 are properties in the returned data
					var property1 = oData.CollegeCode;
					// var property2 = oData.RequestType;
					// var property3 = oData.RoomType;
					var property4 = oData.RequestDate;
					var property5 = oData.Priority;
					var property6 = oData.ReportedBy;
					var property7 = oData.ReportedOn;
					var property8 = oData.Description;
					var property9 = oData.LongText;

					// Assuming you have Input fields with IDs "inputField1" and "inputField2"
					this.getView().byId("label10").setValue(property1);
					// this.getView().byId("label11").setValue(property2);
					// this.getView().byId("room1").setValue(property3);
					this.getView().byId("date16").setValue(property4);
					this.getView().byId("label19").setValue(property5);
					this.getView().byId("label22").setValue(property6);
					this.getView().byId("date23").setValue(property7);
					this.getView().byId("dis17").setValue(property8);
					this.getView().byId("long18").setValue(property9);
				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			
		}
	});
});