sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/m/MessageBox",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData"
], function(Controller, History, MessageToast, MessageBox, StandardListItem, CustomData) {
	"use strict";
	var selectedCheckboxText = "";
	var selectedCheckboxText2 = "";
    var note;
	return Controller.extend("HostelFacility.controller.HostelData", {

		onInit: function() {
			var oModel = this.getOwnerComponent().getModel("MainModel");
			this.getView().setModel(oModel, "newModel");

			this.onReadCollageData();
			this.onReadProrityData();
			this.onReadResponsibiltyData();
			this.onReadNotificationData();

		},

		onReadCollageData: function() {
			// var oDropdown = this.getView().byId("label1");
			// var oCollageModel = this.getOwnerComponent().getModel("MainModel");

			// oCollageModel.read("/ZIPMPLANTVH", {
			// 	success: function(oData) {

			// 		oDropdown.setModel(new sap.ui.model.json.JSONModel(oData.results));

			// 	}.bind(this),
			// 	error: function(err) {

			// 	}
			// });
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label1");
			oModel.read("/ZIPMPLANTVH", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		onReadProrityData: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label3");
			oModel.read("/PriorityVHSet", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		onReadResponsibiltyData: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label4");
			oModel.read("/ResponsibilitiesSet", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);

					// Set the binding path of date picker control
					var oDatePicker = this.getView().byId("date");
					oDatePicker.bindProperty("value", {
						path: "ReportedOn"
					});
				},
				error: function(oError) {
					// Handle error
				}
			});

			// oModel.read("/ResponsibilitiesSet", {
			// 	success: function(response) {
			// 		var resarry = response.results;
			// 		this.getView().byId("By").setText(resarry[0].ReportedBy);
			// 		this.getView().byId("date").setValue(resarry[0].ReportedOn);

			// 	}.bind(this),
			// 	error: function(error) {
			// 		//MessageBox.error("technical problem ");
			// 	}
			// });

		},
		onReadNotificationData: function() {

			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);
			var oDropdown = this.getView().byId("label2");
			oModel.read("/I_PMNotificationTypeStdVH", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},
		onHostelSubmit: function(oEvent) {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("ChangeData");
		},
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View1", {}, true);
			}
		},

		onCheckboxSelect: function(oEvent) {
			selectedCheckboxText = oEvent.getSource().getText(); // Store the text of the selected checkbox
			var oView = this.getView();
			var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			for (var i = 0; i < aCheckboxes.length; i++) {
				if (aCheckboxes[i] !== oEvent.getSource()) {
					aCheckboxes[i].setEditable(oEvent.getSource().getSelected() ? false : true);
				}
			}

		},
		onCheckboxSelect2: function(oEvent) {
			// var oSourceCheckbox = oEvent.getSource();
			// var oView = this.getView();
			// var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			// for (var i = 0; i < aCheckboxes.length; i++) {
			// 	if (aCheckboxes[i] !== oSourceCheckbox) {
			// 		aCheckboxes[i].setEditable(oSourceCheckbox.getSelected() ? false : true);
			// 	}
			// }
			selectedCheckboxText2 = oEvent.getSource().getText(); // Store the text of the selected checkbox
			var oView = this.getView();
			var aCheckboxes = [oView.byId("checkbox12"), oView.byId("checkbox13"), oView.byId("checkbox14")];
			for (var i = 0; i < aCheckboxes.length; i++) {
				if (aCheckboxes[i] !== oEvent.getSource()) {
					aCheckboxes[i].setEditable(oEvent.getSource().getSelected() ? false : true);
				}
			}

		},
		
			refreshCombo: function() {
			var combo1 = this.getView().byId("label1");
			// var combo2 = this.getView().byId("label2");
			var combo3 = this.getView().byId("label3");
			var combo4 = this.getView().byId("label4");
			// var combo5 = this.getView().byId("com1");
			var combo6 = this.getView().byId("reason9");
			var combo7 = this.getView().byId("reference2");
			var combo8 = this.getView().byId("dis");
			var combo9 = this.getView().byId("long");
			var combo10 = this.getView().byId("date");
			var combo11 = this.getView().byId("date1");
			var combo12 = this.getView().byId("com1");
			
			combo1.setSelectedKey("");
			// combo1.removeAllItems();

		
            // combo2.setSelectedKey("");
			combo3.setSelectedKey("");
			// combo3.removeAllItems();

			combo4.setSelectedKey("");
			// combo4.removeAllItems();
			combo6.setValue("");
			combo11.setValue("");
			combo7.setValue("");
			combo8.setValue("");
			combo9.setValue("");
			combo10.setValue("");
			combo12.setValue("");
			// combo5.setValue("");

			// var input1 = this.getView().byId("date1");
			// var input2 = this.getView().byId("dis");
			// var input3 = this.getView().byId("long");
			// var input4 = this.getView().byId("date");
			// input1.setValue();
			// input2.setValue("");
			// input3.setValue("");
			// input4.setValue("");

		},

		onSubmit: function(oEvent) {
			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label1").getSelectedItem().getText();
			var dateValue = oView.byId("date1").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
		
			

			var oData = {
				CollegeCode: clg,
			    // RequestType: oView.byId("label2").getSelectedItem().getText(),
				RequestType: "N2 - Hostel Change Room",
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
				RoomType: selectedCheckboxText,
				// RequestDate: oView.byId("date1").getValue(),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority: oView.byId("label3").getSelectedItem().getText().split("-")[0],
				ReportedBy: oView.byId("label4").getSelectedItem().getText(),
				ReportedOn: oView.byId("date").getValue(),
				NotificationNumber: oView.byId("reference2").getValue(),
				Message: "X"
				
				
				
				

				// Add other properties as needed
			};

			$.ajax({
				url: oModel,
				method: "POST",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response

					var d = response.querySelector("Message").textContent;

					MessageBox.success("Data successfully updated in backend:" + d);

					note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					// MessageBox.success("created successfully", successMessage);

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageToast.show("data not added", error);
				}
			});
			this.refreshCombo();
		},
		onItemSelected: function(oEvent) {
			var selectedIndex = oEvent.getParameter("selectedItem").getKey();
			// Perform actions based on selected item
			switch (selectedIndex) {
				case "1":
					this.handleButton1Click();
					break;
				case "2":
					this.handleButton2Click();
					break;
				case "3":
					this.handleButton3Click();
					break;
				default:
					break;
			}
		},
		handleButton1Click: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(false);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(true);
			var Sub = this.getView().byId("sub");
			Sub.setVisible(true);
			var Cr = this.getView().byId("sub2");
			Cr.setVisible(false);
			var Cr1 = this.getView().byId("sub3");
			Cr1.setVisible(false);

		},
		handleButton2Click: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(true);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(false);
			
			var Cr = this.getView().byId("sub");
			Cr.setVisible(false);
				var Cr1 = this.getView().byId("sub2");
			Cr1.setVisible(true);
				var Cr2 = this.getView().byId("sub3");
			Cr2.setVisible(false);
			
			
			// for hide
				var hide1= this.getView().byId("general");
			hide1.setVisible(true);
			var hide2= this.getView().byId("res");
			hide2.setVisible(true);
			var hide3= this.getView().byId("label10");
			hide3.setVisible(true);
			var hide4= this.getView().byId("com12");
			hide4.setVisible(true);
			var hide5= this.getView().byId("checkboxContain1");
			hide5.setVisible(true);
			var hide6= this.getView().byId("reason");
			hide6.setVisible(true);
			var hide7= this.getView().byId("date12");
			hide7.setVisible(true);
			var hide8= this.getView().byId("dis12");
			hide8.setVisible(true);
				var hide9= this.getView().byId("long12");
			hide9.setVisible(true);
				var hide10= this.getView().byId("label15");
			hide10.setVisible(true);
				var hide11= this.getView().byId("date15");
			hide11.setVisible(true);
				var hide12= this.getView().byId("label14");
			hide12.setVisible(true);
			
			
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			var oView = this.getView();
			var entityId = note;
			oModel.read("/CreateNotificationSet('" + entityId + "')", {

				success: function(oData) {
					// Handle successful data retrieval

					var defaultId = oData.NotificationNumber;
					this.getView().byId("notification").setValue(defaultId);

					var defaultIdCollege = oData.CollegeCode;
					this.getView().byId("label10").setValue(defaultIdCollege);

					var defaultIdRequest = oData.Reason;
					this.getView().byId("reason").setValue(defaultIdRequest);
				

					var defaultIdDate = oData.RequestDate;
					this.getView().byId("date12").setValue(defaultIdDate);

					var defaultIdDis = oData.Description;
					this.getView().byId("dis12").setValue(defaultIdDis);

					var defaultIdPrior = oData.Priority;
					this.getView().byId("label14").setValue(defaultIdPrior);

					var defaultIdBy = oData.ReportedBy;
					this.getView().byId("label15").setValue(defaultIdBy);

					var defaultIdOn = oData.ReportedOn;
					this.getView().byId("date15").setValue(defaultIdOn);
					
					var defaultIdLong = oData.LongText;
					this.getView().byId("long12").setText(defaultIdLong);

				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			oView.setModel(oModel);

			var oModel2 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");

			oModel2.read("/NotificationNoSet", {
				success: function(oData) {
					// Handle successful data retrieval
				},
				error: function(oError) {
					// Handle error
				}
			});
		
		},
		handleButton3Click: function() {
			var Sub = this.getView().byId("sub");
			Sub.setVisible(false);
			var Cr = this.getView().byId("sub2");
			Cr.setVisible(false);
				var Cr1 = this.getView().byId("sub3");
			Cr1.setVisible(true);
			
			// for hide
			var hide1= this.getView().byId("general");
			hide1.setVisible(false);
			var hide2= this.getView().byId("res");
			hide2.setVisible(false);
			var hide3= this.getView().byId("label10");
			hide3.setVisible(false);
			var hide4= this.getView().byId("com12");
			hide4.setVisible(false);
			var hide5= this.getView().byId("checkboxContain1");
			hide5.setVisible(false);
			var hide6= this.getView().byId("reason");
			hide6.setVisible(false);
			var hide7= this.getView().byId("date12");
			hide7.setVisible(false);
			var hide8= this.getView().byId("dis12");
			hide8.setVisible(false);
				var hide9= this.getView().byId("long12");
			hide9.setVisible(false);
				var hide10= this.getView().byId("label15");
			hide10.setVisible(false);
				var hide11= this.getView().byId("date15");
			hide11.setVisible(false);
				var hide12= this.getView().byId("label14");
			hide12.setVisible(false);
			
		},
		
		onSelectionChange: function(oEvent) {
			var selectedItem = oEvent.getParameter("selectedItem");
			var selectedId = selectedItem.getKey();
			// Assuming you have an ODataModel named "oDataModel2" for the second OData service
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			oModel.read("/CreateNotificationSet('" + selectedId + "')", {
				success: function(oData) {
					// Assuming property1 and property2 are properties in the returned data
					var property1 = oData.CollegeCode;
					// var property2 = oData.RequestType;
					var property3 = oData.RoomType;
					var property4 = oData.RequestDate;
					var property5 = oData.Priority;
					var property6 = oData.ReportedBy;
					var property7 = oData.ReportedOn;
					var property8 = oData.Description;
					var property9 = oData.LongText;
					
					// Assuming you have Input fields with IDs "inputField1" and "inputField2"
					this.getView().byId("label10").setValue(property1);
					// this.getView().byId("label11").setValue(property2);
					this.getView().byId("room1").setValue(property3);
					this.getView().byId("date12").setValue(property4);
					this.getView().byId("label14").setValue(property5);
					this.getView().byId("label15").setValue(property6);
					this.getView().byId("date15").setValue(property7);
					this.getView().byId("dis12").setValue(property8);
					this.getView().byId("long12").setValue(property9);
				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
		},
		
			refreshCombo1: function() {
			

			// var input1 = this.getView().byId("notification");
			var input2 = this.getView().byId("label10");
			var input3 = this.getView().byId("com12");
			var input4 = this.getView().byId("reason");
			var input6 = this.getView().byId("date12");
			var input8 = this.getView().byId("dis12");
			var input9 = this.getView().byId("long12");
			var input10 = this.getView().byId("label15");
			var input11 = this.getView().byId("date15");
			var input12 = this.getView().byId("label14");
			
			// input1.setValue("");
			input2.setValue("");
			input3.setValue("");
			input4.setValue("");
			input6.setValue("");
			input8.setValue("");
			input9.setValue("");
			input10.setSelectedKey("");
				input11.setValue("");
				input12.setValue("");

		},
			onSubmit2:function(){
		    var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label10").getValue();
			var dateValue = oView.byId("date12").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
					var ref = oView.byId("notification").getValue();

			var oData = {
				CollegeCode: clg,
				// RequestType: oView.byId("label2").getSelectedItem().getText(),
				RequestType: "N2 - Hostel FacilityReqst",
				RoomType: selectedCheckboxText2,
				// RoomType: oView.byId("room1").getValue(),
				// RequestDate: oView.byId("date1").getValue(),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis12").getValue(),
				LongText: oView.byId("long12").getValue(),
				Priority: oView.byId("label14").getValue(),
				ReportedBy: oView.byId("label15").getValue(),
				ReportedOn: oView.byId("date15").getValue(),
				NotificationNumber: ref,
				Message: "X"

				// Add other properties as needed
			};
			 var supdateurl = oModel + "('" + ref + "')";

			$.ajax({
				url: supdateurl,
				method: "PUT",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response
				
					// var d = response.querySelector("Message").textContent;

					// MessageBox.success("Data successfully updated in backend:" + d);

					// note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					MessageBox.success("Notification Number" + "'" + ref + "'" + "successfully updated ");

				}.bind(this),
				error: function(error) {
					// Handle error response
				MessageBox.error("Please Select other Notification Number", error);
				}
			});
			this.refreshCombo1();
		},
			onCancel: function() {
			this.refreshCombo();
			this.refreshCombo1();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("View1");

		},
		
		
			_reportValueHelpDialog: function(sBindingObj5, oDialogName5, filters5, stockType5) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5 = sap.ui.xmlfragment("HostelFacility.fragments.ReportedByValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog5);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5.setTitle(sBindingObj5.oDialogTitle5);
				this._oAllValueHelpDialog5.destroyItems();
				this._oAllValueHelpDialog5.destroyCustomData();
				this._sBindingValueHelpPath5 = sBindingObj5.entityPath;
				this._oAllValueHelpDialog5.bindAggregation("items", {
					path: sBindingObj5.entityPath,
					templateSharable: false,
					filters: filters5,
					template: new StandardListItem(sBindingObj5.entityProperties)
				});
				this._oAllValueHelpDialog5.addCustomData(new CustomData({
					key: sBindingObj5.customData.key,
					value: sBindingObj5.customData.value
				}));
			}

			this._oAllValueHelpDialog5.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog5;
		},

		onReportValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "/NotificationNoSet",
				"entityProperties": {
					title: "{path:'NotifNo',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._reportValueHelpDialog(sBindingObj5, null);

		},

		onReportDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("reference2").setValue(sTitle);
			
			

		},
		
		
		onSubmit3: function() {
		 var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/CreateNotificationSet";
			var clg = oView.byId("label10").getValue();
			var dateValue = oView.byId("date12").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
					var ref = oView.byId("notification").getValue();

			var oData = {
				// CollegeCode: clg,
				// // RequestType: oView.byId("label2").getSelectedItem().getText(),
				// RequestType: "N2 - Hostel FacilityReqst",
				// // RoomType: oView.byId("checkbox1").getSelected().toString(),
				// RoomType: oView.byId("room1").getValue(),
				// // RequestDate: oView.byId("date1").getValue(),
				// RequestDate: dateFormat.format(dateValue),
				// Description: oView.byId("dis12").getValue(),
				// LongText: oView.byId("long12").getValue(),
				// Priority: oView.byId("label14").getValue(),
				// ReportedBy: oView.byId("label15").getValue(),
				// ReportedOn: oView.byId("date15").getValue(),
				NotificationNumber: ref,
				Message: "X"

				// Add other properties as needed
			};
			 var supdateurl = oModel + "('" + ref + "')";

			$.ajax({
				url: supdateurl,
				method: "DELETE",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response
				
					// var d = response.querySelector("Message").textContent;

					// MessageBox.success("Data successfully updated in backend:" + d);

					// note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					MessageBox.success("Notification Number" + "'" + ref + "'" + "successfully closed ");

				}.bind(this),
				error: function(error) {
					// Handle error response
				MessageBox.error("Please Select other Notification Number", error);
				}
			});
			var noti= this.getView().byId("notification");
			noti.setValue("");
		},
		
		
		
		
		
		
		_codeValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelFacility.fragments.ReferenceValueHelp", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onCodeValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "/NotificationNoSet",
				"entityProperties": {
					title: "{path:'NotifNo',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._codeValueHelpDialog(sBindingObj, null);

		},

		onDialogClose1: function(oEvent) {

			// var sTitle = oEvent.getParameter("selectedItem").getTitle();
			// this.getView().byId("notification").setValue(sTitle);
				var selectedItem = oEvent.getParameter("selectedItem");
				if(selectedItem){
					var sTitle = selectedItem.getTitle();
					this.getView().byId("notification").setValue(sTitle);
					this._fetchAdditionalData(sTitle);
					
				}
			

		},
		_fetchAdditionalData:function(selectedData){
			
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			oModel.read("/CreateNotificationSet('" + selectedData + "')", {
				success: function(oData) {
					// Assuming property1 and property2 are properties in the returned data
					var property1 = oData.CollegeCode;
					// var property2 = oData.RequestType;
					// var property3 = oData.RoomType;
					var property4 = oData.RequestDate;
					var property5 = oData.Priority;
					var property6 = oData.ReportedBy;
					var property7 = oData.ReportedOn;
					var property8 = oData.Description;
					var property9 = oData.LongText;
					
					

					// Assuming you have Input fields with IDs "inputField1" and "inputField2"
					this.getView().byId("label10").setValue(property1);
					// this.getView().byId("label11").setValue(property2);
					// this.getView().byId("room1").setValue(property3);
					this.getView().byId("date12").setValue(property4);
					this.getView().byId("label14").setValue(property5);
					this.getView().byId("label15").setValue(property6);
					this.getView().byId("date15").setValue(property7);
					this.getView().byId("dis12").setValue(property8);
					this.getView().byId("long12").setValue(property9);
				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			
		},
		
			_AllValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelFacility.fragments.AllValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},
		onLocationValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'FunctionalLocation',templateSharable:true}",
					description: "{path:'FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._AllValueHelpDialog(sBindingObj, null);

		},

		onDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("com1").setValue(sTitle);

		},
			_RoomTypeValueHelpDialog: function(sBindingObj3, oDialogName3, filters3, stockType3) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3 = sap.ui.xmlfragment("HostelFacility.fragments.RoomValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog3);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog3);
			}
			if (this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3.setTitle(sBindingObj3.oDialogTitle1);
				this._oAllValueHelpDialog3.destroyItems();
				this._oAllValueHelpDialog3.destroyCustomData();
				this._sBindingValueHelpPath3 = sBindingObj3.entityPath;
				this._oAllValueHelpDialog3.bindAggregation("items", {
					path: sBindingObj3.entityPath,
					templateSharable: false,
					filters: filters3,
					template: new StandardListItem(sBindingObj3.entityProperties)
				});
				this._oAllValueHelpDialog3.addCustomData(new CustomData({
					key: sBindingObj3.customData.key,
					value: sBindingObj3.customData.value
				}));
			}

			this._oAllValueHelpDialog3.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog3;
		},

		onSecondLocationValueHelpRequest: function(OEvent) {

			var sBindingObj3 = {
					"entityPath": "/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'FunctionalLocation',templateSharable:true}",
					description: "{path:'FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._RoomTypeValueHelpDialog(sBindingObj3, null);

		},

		onRoomDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("com12").setValue(sTitle);

		},

	});
});