sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	// "../model/models"
	"../util/Formatter"

], function(Controller, StandardListItem, CustomData, Filter, FilterOperator, JSONModel, Formatter) {
	"use strict";
	var A = "a";
	return Controller.extend("HostelFacility.controller.HostelAvailability", {
		onInit: function() {
			// this.getOwnerComponent().getModel("codeODataModel");
			// var oModel = this.getOwnerComponent().getModel("codeODataModel");
			// this.getView().getModel(oModel, "MainModel");
			// var oTable = this.byId("HostelTable");
			// oTable.setVisible(false);

			// 		var oDataModel = this.getOwnerComponent().getModel("codeODataModel");
			// this.getView().setModel(oDataModel, "oDataModel");

		},

		_codeValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelFacility.fragments.CodeValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onCodeValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "codeODataModel>/ZIPMPLANTVH",
				"entityProperties": {
					title: "{path:'codeODataModel>Plant',templateSharable:true}",
					description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "Plant",
					"value": ""
				}
			};
			this._codeValueHelpDialog(sBindingObj, null);

		},

		onDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In1").setValue(sTitle);

		},

		_locValueHelpDialog: function(sBindingObj1, oDialogName1, filters1, stockType1) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1 = sap.ui.xmlfragment("HostelFacility.fragments.LocationValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog1);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog1);
			}
			if (this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1.setTitle(sBindingObj1.oDialogTitle1);
				this._oAllValueHelpDialog1.destroyItems();
				this._oAllValueHelpDialog1.destroyCustomData();
				this._sBindingValueHelpPath1 = sBindingObj1.entityPath;
				this._oAllValueHelpDialog1.bindAggregation("items", {
					path: sBindingObj1.entityPath,
					templateSharable: false,
					filters: filters1,
					template: new StandardListItem(sBindingObj1.entityProperties)
				});
				this._oAllValueHelpDialog1.addCustomData(new CustomData({
					key: sBindingObj1.customData.key,
					value: sBindingObj1.customData.value
				}));
			}

			this._oAllValueHelpDialog1.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog1;
		},

		_filters: function(sFiltersObject, conditionalFlag) {
			var arrayFilters = [],
				aFilters;
			sFiltersObject.forEach(function(element, index) {
				var operator = FilterOperator[element.filterOperator] ? FilterOperator[element.filterOperator] : FilterOperator.Contains;
				arrayFilters.push(new Filter(element.sPath, operator, element.sValue));
				//	arrayFilters.push(new Filter(element.sPath, FilterOperator.EQ, element.sValue));
			});
			aFilters = new Filter({
				filters: arrayFilters,
				and: conditionalFlag
			});
			return aFilters;
		},

		onLocationValueHelpRequest: function(OEvent) {
				if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("HostelFacility.fragments.Note", this);
				this.getView().addDependent(this._oDialog);

			}
			this._oDialog.open();
		
			// var sBindingObj1 = {
			// 	"entityPath": "codeODataModel>/I_PMNotificationTypeStdVH",
			// 	"entityProperties": {
			// 		title: "{path:'codeODataModel>NotificationType',templateSharable:true}",
			// 		description: "{path:'codeODataModel>NotificationType_Text',templateSharable:true}"
			// 	},
			// 	// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
			// 	"customData": {
			// 		"key": "NotificationType",
			// 		"value": ""
			// 	}
			// };
			// //var sPlant = this.getView().getModel("LocalDataModel").getProperty("/filters/Plant"),
			// this._locValueHelpDialog(sBindingObj1, null);
		

		},

		onNotDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In2").setValue(sTitle);
			this._oDialog.close();

		},

		// for room
		_roomValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelFacility.fragments.RoomValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog2);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
			}
			if (this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
				this._oAllValueHelpDialog2.destroyItems();
				this._oAllValueHelpDialog2.destroyCustomData();
				this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
				this._oAllValueHelpDialog2.bindAggregation("items", {
					path: sBindingObj2.entityPath,
					templateSharable: false,
					filters: filters2,
					template: new StandardListItem(sBindingObj2.entityProperties)
				});
				this._oAllValueHelpDialog2.addCustomData(new CustomData({
					key: sBindingObj2.customData.key,
					value: sBindingObj2.customData.value
				}));
			}

			this._oAllValueHelpDialog2.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog2;
		},

		onRoomValueHelpRequest: function(OEvent) {

			var sBindingObj2 = {
				"entityPath": "codeODataModel>/ZIROOMTYPEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>DomainDescription',templateSharable:true}",
					description: "{path:'codeODataModel>DomainValue',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._roomValueHelpDialog(sBindingObj2, null);

		},

		onRoomDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},

		// for priority

		_priorValueHelpDialog: function(sBindingObj3, oDialogName3, filters3, stockType3) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3 = sap.ui.xmlfragment("HostelFacility.fragments.PriorityValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog3);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog3);
			}
			if (this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3.setTitle(sBindingObj3.oDialogTitle1);
				this._oAllValueHelpDialog3.destroyItems();
				this._oAllValueHelpDialog3.destroyCustomData();
				this._sBindingValueHelpPath3 = sBindingObj3.entityPath;
				this._oAllValueHelpDialog3.bindAggregation("items", {
					path: sBindingObj3.entityPath,
					templateSharable: false,
					filters: filters3,
					template: new StandardListItem(sBindingObj3.entityProperties)
				});
				this._oAllValueHelpDialog3.addCustomData(new CustomData({
					key: sBindingObj3.customData.key,
					value: sBindingObj3.customData.value
				}));
			}

			this._oAllValueHelpDialog3.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog3;
		},

		onPriorValueHelpRequest: function(OEvent) {

			var sBindingObj3 = {
				"entityPath": "codeODataModel>/ZIPMPRIORITYVH",
				"entityProperties": {
					title: "{path:'codeODataModel>MaintPriorityDesc',templateSharable:true}",
					description: "{path:'codeODataModel>MaintPriority',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._priorValueHelpDialog(sBindingObj3, null);

		},

		onPriorDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In4").setValue(sTitle);

		},

		// for system

		_systemValueHelpDialog: function(sBindingObj4, oDialogName4, filters4, stockType4) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4 = sap.ui.xmlfragment("HostelFacility.fragments.SystemValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog4);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog4);
			}
			if (this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4.setTitle(sBindingObj4.oDialogTitle1);
				this._oAllValueHelpDialog4.destroyItems();
				this._oAllValueHelpDialog4.destroyCustomData();
				this._sBindingValueHelpPath4 = sBindingObj4.entityPath;
				this._oAllValueHelpDialog4.bindAggregation("items", {
					path: sBindingObj4.entityPath,
					templateSharable: false,
					filters: filters4,
					template: new StandardListItem(sBindingObj4.entityProperties)
				});
				this._oAllValueHelpDialog4.addCustomData(new CustomData({
					key: sBindingObj4.customData.key,
					value: sBindingObj4.customData.value
				}));
			}

			this._oAllValueHelpDialog4.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog4;
		},

		onSystemValueHelpRequest: function(OEvent) {

			var sBindingObj4 = {
				"entityPath": "codeODataModel>/ZISYSTEMSTATUSVH",
				"entityProperties": {
					title: "{path:'codeODataModel>FinalStatus',templateSharable:true}",
					description: "{path:'codeODataModel>StatusKey',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._systemValueHelpDialog(sBindingObj4, null);

		},

		onSystemDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In5").setValue(sTitle);

		},

		// for reported

		_reportValueHelpDialog: function(sBindingObj5, oDialogName5, filters5, stockType5) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5 = sap.ui.xmlfragment("HostelFacility.fragments.ReportedByValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog5);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5.setTitle(sBindingObj5.oDialogTitle5);
				this._oAllValueHelpDialog5.destroyItems();
				this._oAllValueHelpDialog5.destroyCustomData();
				this._sBindingValueHelpPath5 = sBindingObj5.entityPath;
				this._oAllValueHelpDialog5.bindAggregation("items", {
					path: sBindingObj5.entityPath,
					templateSharable: false,
					filters: filters5,
					template: new StandardListItem(sBindingObj5.entityProperties)
				});
				this._oAllValueHelpDialog5.addCustomData(new CustomData({
					key: sBindingObj5.customData.key,
					value: sBindingObj5.customData.value
				}));
			}

			this._oAllValueHelpDialog5.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog5;
		},

		onReportValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "codeODataModel>/CreatedBySet",
				"entityProperties": {
					title: "{path:'codeODataModel>username',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "username",
					"value": ""
				}
			};
			this._reportValueHelpDialog(sBindingObj5, null);

		},

		onReportDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In6").setValue(sTitle);

		},

		onGo: function() {
			// var selectedValue = this.byId("In1").getValue();
			// var selectedValue1 = this.byId("In2").getValue();
			// // var selectedValue2 = this.byId("In4").getValue();
			// var selectedValue4 = this.byId("In6").getValue();
			// // var selectedValue5 = this.byId("In5").getValue();

			// // Construct filter for second OData service
			// var oFilter = new sap.ui.model.Filter("CollegeCode", sap.ui.model.FilterOperator.EQ, selectedValue);
			// var oFilter1 = new sap.ui.model.Filter("NotificationType", sap.ui.model.FilterOperator.EQ, selectedValue1);
			// // var oFilter2 = new sap.ui.model.Filter("Priority", sap.ui.model.FilterOperator.EQ, selectedValue2);

			// var oFilter4 = new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue4);
			// // var oFilter5 = new sap.ui.model.Filter("SystemStatus", sap.ui.model.FilterOperator.EQ, selectedValue5);

			// var combinedFilter = new sap.ui.model.Filter({
			// 	// filters: [oFilter, oFilter1, oFilter2, oFilter4, oFilter5],
			// 	filters: [oFilter, oFilter1, oFilter4 ],
			// 	and: false
			// });

			// // Get data from second OData service with filter
			// var oModel = this.getOwnerComponent().getModel("codeODataModel");
			// oModel.read("/GetHostelDataSet", {
			// 	filters: [combinedFilter],
			// 	success: function(oData, response) {
			// 		// Handle success response
			// 		var oFilteredData = oData.results.filter(function(item) {
			// 			// return item.CollegeCode === selectedValue || item.Location === selectedValue1 || item.Priority === selectedValue2 || item.ReportedBy === selectedValue4 || item.SystemStatus === selectedValue5;
			// 			// return item.CollegeCode === selectedValue && item.NotificationType === selectedValue1 && item.username === selectedValue4;

			// 			var matchFound = false;
			// 			// Check if any of the conditions match
			// 			if (item.CollegeCode === selectedValue) {
			// 				matchFound = true;
			// 			} else if (item.NotificationType === selectedValue1) {
			// 				matchFound = true;
			// 			} 
			// 			// else if (item.Priority === selectedValue2) {
			// 			// 	matchFound = true;
			// 			// } 
			// 			// else if (item.SystemStatus === selectedValue5) {
			// 			// 	matchFound = true;
			// 			// }
			// 			else if (item.ReportedBy === selectedValue4) {
			// 				matchFound = true;
			// 			}

			// 			return matchFound;

			// 		});

			// 		var selecteDate = this.byId("date").getValue();

			// 		var oTable = this.byId("HostelTable");
			// 		oTable.setModel(new sap.ui.model.json.JSONModel({
			// 			results: oFilteredData,
			// 			selecteDate: selecteDate
			// 		}));
			// 	}.bind(this),
			// 	error: function(oError) {
			// 		// Handle error
			// 	}

			// });

			var oTable = this.getView().byId("HostelTable");
			var selectedValue = this.byId("In1").getValue();
			var selectedValue1 = this.byId("In2").getValue();
			var selectedValue4 = this.byId("In6").getValue();

			var aFilters = [];

			// Construct filters
			if (selectedValue) {
				aFilters.push(new sap.ui.model.Filter("CollegeCode", sap.ui.model.FilterOperator.EQ, selectedValue));
			}

			if (selectedValue1) {
				aFilters.push(new sap.ui.model.Filter("NotificationType", sap.ui.model.FilterOperator.EQ, selectedValue1));
			}

			if (selectedValue4) {
				aFilters.push(new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue4));
			}

			// Apply filters to the table binding
			oTable.getBinding("items").filter(aFilters);

		},
		// Define formatter function
		formatCellColor: function(value) {
			if (value === "available") {
				return "sapUiGreen"; // Apply green color class
			} else {
				return "sapUiRed"; // Apply red color class
			}
		},
		onNavBack: function() {

			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("View1", {}, true);

		},
		onCreateHostel: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("HostelRequest");
		},
		onChangeHostel: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("HostelData");
		},
		onVacateHostel: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeScreen");
		},
		  removeLeadingZeros: function(sValue) {
         if (sValue.startsWith("0000")) {
            return sValue.substring(4);
         }
         return sValue;
      }

	});
});