sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData"

], function(Controller, History, MessageBox, StandardListItem, CustomData) {
	"use strict";
	var note;
	return Controller.extend("HostelFacility.controller.ChangeScreen", {

		onInit: function() {
			var sModel = "/sap/opu/odata/sap/ZSL_HOSTELFACLITY_VACATE_SRV/";
			var pModel = new sap.ui.model.odata.ODataModel(sModel, true);
			this.getView().setModel(pModel, "VacateModel");
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.getRoute("ChangeScreen").attachPatternMatched(this._onRouteMatched, this);
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.getRoute("ChangeScreen").attachMatched(this._onRouteMatched, this);

			var oModel2 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTELFACLITY_VACATE_SRV/");

			oModel2.read("/NotificationNoSet", {
				success: function(oData) {
					// Handle successful data retrieval
				},
				error: function(oError) {
					// Handle error
				}
			});

		},
		// _onRouteMatched: function(oEvent) {
		// 	var selectedData = oEvent.getParameter("arguments").selectedData;

		// 	var oModel = new sap.ui.model.json.JSONModel({
		// 		selectedData: [{
		// 			value: selectedData

		// 		}]
		// 	});
		// 	var oTable = this.getView().byId("tableId"); // Assuming tableId is the ID of your table
		// 	oTable.setModel(oModel);
		// },

		// _onRouteMatched: function(oEvent) {
		// 	var code = oEvent.getParameter("arguments").Code;
		// 	var prior = oEvent.getParameter("arguments").Priority;
		// 	var note = oEvent.getParameter("arguments").Notification;
		// 	var by = oEvent.getParameter("arguments").By;
		// 	var on = oEvent.getParameter("arguments").On;
		// 	var oModel = new sap.ui.model.json.JSONModel({
		// 		selectedData: [{
		// 			value: code,
		// 			value1: prior,
		// 			value2: note,
		// 			value3: by,
		// 			value4: on

		// 		}]
		// 	});
		// 	var oTable = this.getView().byId("tableId"); // Assuming tableId is the ID of your table
		// 	oTable.setModel(oModel);

		// },

		onNav: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View", {}, true);
			}

		},

		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View1", {}, true);
			}
		},

		onCreate: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/"; // Replace this with your actual service URL
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			// Set the model to the view
			this.getView().setModel(oModel);

			var oTable = this.getView().byId("tableId");
			var aSelectedItems = oTable.getSelectedItems();

			var aData = [];
			aSelectedItems.forEach(function(oItem) {
				var oBindingContext = oItem.getBindingContext();
				var oSelectedData = oBindingContext.getObject();
				aData.push(oSelectedData);
			});

			var oPayload = {
				"data": aData
			};
			oModel.create("/CreateNotificationSet", oPayload, {
				success: function(oData, response) {
					// Handle success response

					MessageBox.success("created successfully");
				},
				error: function(oError) {
					// Handle error response
					MessageBox.error("getting error");
				}
			});
		},

		_AllValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelFacility.fragments.AllValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},
		onLocationValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "VacateModel>/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'VacateModel>FunctionalLocation',templateSharable:true}",
					description: "{path:'VacateModel>FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._AllValueHelpDialog(sBindingObj, null);

		},

		onDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("com1").setValue(sTitle);

		},

		// _PriorValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
		// 	this._customDataValue = "";
		// 	//	var oAllValueHelpDialog = oDialogName;
		// 	if (!this._oAllValueHelpDialog2) {
		// 		this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelFacility.fragment.PriorValueHelp", this);
		// 		this.getView().addDependent(this._oAllValueHelpDialog2);
		// 		jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
		// 	}
		// 	if (this._oAllValueHelpDialog2) {
		// 		this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
		// 		this._oAllValueHelpDialog2.destroyItems();
		// 		this._oAllValueHelpDialog2.destroyCustomData();
		// 		this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
		// 		this._oAllValueHelpDialog2.bindAggregation("items", {
		// 			path: sBindingObj2.entityPath,
		// 			templateSharable: false,
		// 			filters: filters2,
		// 			template: new StandardListItem(sBindingObj2.entityProperties)
		// 		});
		// 		this._oAllValueHelpDialog2.addCustomData(new CustomData({
		// 			key: sBindingObj2.customData.key,
		// 			value: sBindingObj2.customData.value
		// 		}));
		// 	}

		// 	this._oAllValueHelpDialog2.open();
		// 	//	this._currentDialog = oAllValueHelpDialog;
		// 	return this._oAllValueHelpDialog2;
		// },

		// onPriorValueHelpRequest: function(OEvent) {
		// 	var sBindingObj1 = {
		// 		"entityPath": "VacateModel>/ZIPMPRIORITYVH",
		// 		"entityProperties": {
		// 			title: "{path:'VacateModel>MaintPriorityDesc',templateSharable:true}",
		// 			description: "{path:'VacateModel>MaintPriority',templateSharable:true}"
		// 		},
		// 		// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
		// 		"customData": {
		// 			"key": "MaintPriorityDesc",
		// 			"value": ""
		// 		}
		// 	};
		// 	this._PriorValueHelpDialog(sBindingObj1, null);

		// },

		// onPriorDialogClose: function(oEvent) {

		// 	var sTitle = oEvent.getParameter("selectedItem").getTitle();
		// 	this.getView().byId("In2").setValue(sTitle);

		// },

		_RoomTypeValueHelpDialog: function(sBindingObj3, oDialogName3, filters3, stockType3) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3 = sap.ui.xmlfragment("HostelFacility.fragment.RoomTypeValueHelp", this);
				this.getView().addDependent(this._oAllValueHelpDialog3);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog3);
			}
			if (this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3.setTitle(sBindingObj3.oDialogTitle1);
				this._oAllValueHelpDialog3.destroyItems();
				this._oAllValueHelpDialog3.destroyCustomData();
				this._sBindingValueHelpPath3 = sBindingObj3.entityPath;
				this._oAllValueHelpDialog3.bindAggregation("items", {
					path: sBindingObj3.entityPath,
					templateSharable: false,
					filters: filters3,
					template: new StandardListItem(sBindingObj3.entityProperties)
				});
				this._oAllValueHelpDialog3.addCustomData(new CustomData({
					key: sBindingObj3.customData.key,
					value: sBindingObj3.customData.value
				}));
			}

			this._oAllValueHelpDialog3.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog3;
		},

		onRoomTypeValueHelpRequest: function(OEvent) {

			var sBindingObj3 = {
				"entityPath": "VacateModel>/ZIROOMTYPEVH",
				"entityProperties": {
					title: "{path:'VacateModel>DomainValue',templateSharable:true}",
					description: "{path:'VacateModel>DomainDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "DomainValue",
					"value": ""
				}
			};
			this._RoomTypeValueHelpDialog(sBindingObj3, null);

		},

		onRoomTypeDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},

		_requestValueHelpDialog: function(sBindingObj4, oDialogName4, filters4, stockType4) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4 = sap.ui.xmlfragment("HostelFacility.fragment.RequestValueHelp", this);
				this.getView().addDependent(this._oAllValueHelpDialog4);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog4);
			}
			if (this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4.setTitle(sBindingObj4.oDialogTitle1);
				this._oAllValueHelpDialog4.destroyItems();
				this._oAllValueHelpDialog4.destroyCustomData();
				this._sBindingValueHelpPath4 = sBindingObj4.entityPath;
				this._oAllValueHelpDialog4.bindAggregation("items", {
					path: sBindingObj4.entityPath,
					templateSharable: false,
					filters: filters4,
					template: new StandardListItem(sBindingObj4.entityProperties)
				});
				this._oAllValueHelpDialog4.addCustomData(new CustomData({
					key: sBindingObj4.customData.key,
					value: sBindingObj4.customData.value
				}));
			}

			this._oAllValueHelpDialog4.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog4;
		},

		onRequestValueHelpRequest: function(OEvent) {

			var sBindingObj4 = {
				"entityPath": "VacateModel>/ZIPMREQUESTORVH",
				"entityProperties": {
					title: "{path:'VacateModel>Description',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "Description",
					"value": ""
				}
			};
			this._requestValueHelpDialog(sBindingObj4, null);

		},

		onRequestTypeDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In4").setValue(sTitle);

		},

		_collegeValueHelpDialog: function(sBindingObj5, oDialogName5, filters5, stockType5) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5 = sap.ui.xmlfragment("HostelFacility.fragment.CollegeValueHelp", this);
				this.getView().addDependent(this._oAllValueHelpDialog5);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5.setTitle(sBindingObj5.oDialogTitle5);
				this._oAllValueHelpDialog5.destroyItems();
				this._oAllValueHelpDialog5.destroyCustomData();
				this._sBindingValueHelpPath5 = sBindingObj5.entityPath;
				this._oAllValueHelpDialog5.bindAggregation("items", {
					path: sBindingObj5.entityPath,
					templateSharable: false,
					filters: filters5,
					template: new StandardListItem(sBindingObj5.entityProperties)
				});
				this._oAllValueHelpDialog5.addCustomData(new CustomData({
					key: sBindingObj5.customData.key,
					value: sBindingObj5.customData.value
				}));
			}

			this._oAllValueHelpDialog5.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog5;
		},

		onCollegeValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "VacateModel>/ZIPMPLANTVH",
				"entityProperties": {
					title: "{path:'VacateModel>Plant',templateSharable:true}",
					description: "{path:'VacateModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "Plant",
					"value": ""
				}
			};
			this._collegeValueHelpDialog(sBindingObj5, null);

		},

		onCollegeTypeDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In5").setValue(sTitle);

		},

		_ReportValueHelpDialog: function(sBindingObj6, oDialogName6, filters6, stockType6) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog6) {
				this._oAllValueHelpDialog6 = sap.ui.xmlfragment("HostelFacility.fragments.ReportedByValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog6);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog6) {
				this._oAllValueHelpDialog6.setTitle(sBindingObj6.oDialogTitle6);
				this._oAllValueHelpDialog6.destroyItems();
				this._oAllValueHelpDialog6.destroyCustomData();
				this._sBindingValueHelpPath6 = sBindingObj6.entityPath;
				this._oAllValueHelpDialog6.bindAggregation("items", {
					path: sBindingObj6.entityPath,
					templateSharable: false,
					filters: filters6,
					template: new StandardListItem(sBindingObj6.entityProperties)
				});
				this._oAllValueHelpDialog6.addCustomData(new CustomData({
					key: sBindingObj6.customData.key,
					value: sBindingObj6.customData.value
				}));
			}

			this._oAllValueHelpDialog6.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog6;
		},

		onSeconLocationValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "VacateModel>/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'VacateModel>FunctionalLocation',templateSharable:true}",
					description: "{path:'VacateModel>FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._ReportValueHelpDialog(sBindingObj5, null);
			

		},

		onReportDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("label12").setValue(sTitle);

		},

		_PriorValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelFacility.fragments.ReferenceValueHelp", this);
				this.getView().addDependent(this._oAllValueHelpDialog2);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
			}
			if (this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
				this._oAllValueHelpDialog2.destroyItems();
				this._oAllValueHelpDialog2.destroyCustomData();
				this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
				this._oAllValueHelpDialog2.bindAggregation("items", {
					path: sBindingObj2.entityPath,
					templateSharable: false,
					filters: filters2,
					template: new StandardListItem(sBindingObj2.entityProperties)
				});
				this._oAllValueHelpDialog2.addCustomData(new CustomData({
					key: sBindingObj2.customData.key,
					value: sBindingObj2.customData.value
				}));
			}

			this._oAllValueHelpDialog2.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog2;
		},
		onReferenceValueHelpRequest: function(OEvent) {

			var sBindingObj1 = {
				"entityPath": "VacateModel>/NotificationNoSet",
				"entityProperties": {
					title: "{path:'VacateModel>NotifNo',templateSharable:true}"
						// description: "{path:'VacateModel>MaintPriority',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._PriorValueHelpDialog(sBindingObj1, null);

		},

		onDialogClose1: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("reference").setValue(sTitle);

		},

		onItemSelected: function(oEvent) {
			var selectedIndex = oEvent.getParameter("selectedItem").getKey();
			// Perform actions based on selected item
			switch (selectedIndex) {
				case "1":
					this.handleButton1Click();
					break;
				case "2":
					this.handleButton2Click();
					break;
				case "3":
					this.handleButton3Click();
					break;
				default:
					break;
			}
		},
		handleButton1Click: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(false);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(true);
			var Sub = this.getView().byId("sub");
			Sub.setVisible(true);
			var Sub2 = this.getView().byId("sub2");
			Sub2.setVisible(false);
			var Sub3 = this.getView().byId("sub3");
			Sub3.setVisible(false);

		},
		handleButton2Click: function() {
			var Panel2 = this.getView().byId("panel2");
			Panel2.setVisible(true);
			var Panel1 = this.getView().byId("panel1");
			Panel1.setVisible(false);
			var Cr = this.getView().byId("sub2");
			Cr.setVisible(true);
			var Cr1 = this.getView().byId("sub");
			Cr1.setVisible(false);
			var Cr3 = this.getView().byId("sub3");
			Cr3.setVisible(false);
			// // code for hide
			var hide1 = this.getView().byId("label10");
			hide1.setVisible(true);
			var hide2 = this.getView().byId("label11");
			hide2.setVisible(true);
			var hide3 = this.getView().byId("label12");
			hide3.setVisible(true);
			var hide4 = this.getView().byId("label13");
			hide4.setVisible(true);
			var hide5 = this.getView().byId("res");
			hide5.setVisible(true);
			var hide6 = this.getView().byId("date2");
			hide6.setVisible(true);
			var hide7 = this.getView().byId("dis13");
			hide7.setVisible(true);
			var hide8 = this.getView().byId("long13");
			hide8.setVisible(true);
			var hide9 = this.getView().byId("label14");
			hide9.setVisible(true);
			var hide10 = this.getView().byId("label15");
			hide10.setVisible(true);
			var hide11 = this.getView().byId("date3");
			hide11.setVisible(true);

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			var oView = this.getView();
			var entityId = note;
			oModel.read("/CreateNotificationSet('" + entityId + "')", {

				success: function(oData) {
					// Handle successful data retrieval

					var defaultId = oData.NotificationNumber;
					this.getView().byId("refer").setValue(defaultId);

					var defaultIdCollege = oData.CollegeCode;
					this.getView().byId("label10").setValue(defaultIdCollege);

					var defaultIdRequest = oData.RoomType;
					this.getView().byId("label13").setValue(defaultIdRequest);

					var defaultIdDate = oData.RequestDate;
					this.getView().byId("date2").setValue(defaultIdDate);

					var defaultIdDis = oData.Description;
					this.getView().byId("dis13").setValue(defaultIdDis);

					var defaultIdPrior = oData.Priority;
					this.getView().byId("label14").setValue(defaultIdPrior);

					var defaultIdBy = oData.ReportedBy;
					this.getView().byId("label15").setValue(defaultIdBy);

					var defaultIdOn = oData.ReportedOn;
					this.getView().byId("date3").setValue(defaultIdOn);

					var defaultIdLong = oData.LongText;
					this.getView().byId("long13").setValue(defaultIdLong);

					var defaultIdLoc = oData.Location;
					this.getView().byId("label12").setValue(defaultIdLoc);

					var defaultIdRes = oData.Location;
					this.getView().byId("res").setValue(defaultIdRes);

				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			oView.setModel(oModel);

			var oModel2 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");

			oModel2.read("/NotificationNoSet", {
				success: function(oData) {
					// Handle successful data retrieval
				},
				error: function(oError) {
					// Handle error
				}
			});
		},

		handleButton3Click: function() {
			var gen = this.getView().byId("general");
			gen.setVisible(false);
			var res = this.getView().byId("response");
			res.setVisible(false);

			var Sub = this.getView().byId("sub");
			Sub.setVisible(false);
			var Sub2 = this.getView().byId("sub2");
			Sub2.setVisible(false);
			var Sub3 = this.getView().byId("sub3");
			Sub3.setVisible(true);

			// code for hide
			var hide1 = this.getView().byId("label10");
			hide1.setVisible(false);
			var hide2 = this.getView().byId("label11");
			hide2.setVisible(false);
			var hide3 = this.getView().byId("label12");
			hide3.setVisible(false);
			var hide4 = this.getView().byId("label13");
			hide4.setVisible(false);
			var hide5 = this.getView().byId("res");
			hide5.setVisible(false);
			var hide6 = this.getView().byId("date2");
			hide6.setVisible(false);
			var hide7 = this.getView().byId("dis13");
			hide7.setVisible(false);
			var hide8 = this.getView().byId("long13");
			hide8.setVisible(false);
			var hide9 = this.getView().byId("label14");
			hide9.setVisible(false);
			var hide10 = this.getView().byId("label15");
			hide10.setVisible(false);
			var hide11 = this.getView().byId("date3");
			hide11.setVisible(false);

		},

		onSubmit: function() {
			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTELFACLITY_VACATE_SRV/CreateNotificationSet";

			var dateValue = oView.byId("date1").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});

			var oData = {
				// CollegeCode: oView.byId("label1").getSelectedItem().getBindingContext("VacateModel").getProperty("Plant"),
				// ReqType: "",
				// Location: oView.byId("com1").getSelectedItem().getBindingContext("VacateModel").getProperty("FunctionalLocation"),
				// RoomType: oView.byId("In3").getSelectedItem().getBindingContext("VacateModel").getProperty("DomainDescription"),
				// ReqVacHos: "",
				// ReqTrsHos: "",
				// Reason: oView.byId("reson").getValue(),
				// ReqDate: dateFormat.format(dateValue),
				// Equipment: "",
				// RefNo: "",
				// Description: oView.byId("dis").getValue(),
				// Priority: oView.byId("label3").getSelectedItem().getBindingContext("VacateModel").getProperty("MaintPriority"),
				// TimePeriod: "",
				// RepBy: oView.byId("label4").getSelectedItem().getBindingContext("VacateModel").getProperty("UserName"),
				// RepOn: oView.byId("date").getValue(),
				// Longtext: oView.byId("long").getValue(),
				// AttachmentsSet: ""

				CollegeCode: oView.byId("label1").getSelectedItem().getBindingContext("VacateModel").getProperty("Plant"),
				RequestType: "N3",
				RoomType: oView.byId("In3").getSelectedItem().getBindingContext("VacateModel").getProperty("DomainValue"),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority: oView.byId("label3").getSelectedItem().getBindingContext("VacateModel").getProperty("MaintPriority"),
				ReportedBy: oView.byId("label4").getSelectedItem().getBindingContext("VacateModel").getProperty("UserName"),
				ReportedOn: "",
				NotificationNumber: oView.byId("reference").getValue(),
				Message: "",
				Location: oView.byId("com1").getValue(),
				Reason: oView.byId("reson").getValue()

				// "AttachmentsSet":""

				// Add other properties as needed
			};

			$.ajax({
				url: oModel,
				method: "POST",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response

					var d = response.querySelector("Message").textContent;

					MessageBox.success("Data successfully updated in backend:" + d);

					note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					// MessageBox.success("created successfully", successMessage);

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageBox.show("data not added", error);
				}
			});
			this.refreshCombo();
		},
		
			refreshCombo: function() {
			var combo1 = this.getView().byId("label1");
			// var combo2 = this.getView().byId("label2");
			var combo3 = this.getView().byId("In3");
			var combo4 = this.getView().byId("com1");
			combo1.setSelectedKey("");
			// combo1.removeAllItems();

			combo3.setSelectedKey("");
			// combo3.removeAllItems();

			combo4.setSelectedKey("");
			// combo4.removeAllItems();

		
			var input2 = this.getView().byId("dis");
			var input3 = this.getView().byId("long");
			var input4 = this.getView().byId("date1");
			var input5 = this.getView().byId("label3");
			var input6 = this.getView().byId("label4");
			var input7 = this.getView().byId("reference");
			var input8 = this.getView().byId("date");
			var input9 = this.getView().byId("reson");
			
			input2.setValue("");
			input3.setValue("");
			input4.setValue("");
			input5.setValue("");
			input6.setValue("");
			input7.setValue("");
			input8.setValue("");
			input9.setValue("");

		},
		

		_ReferValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelFacility.fragments.RoomValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onReferenceValueHelp: function(OEvent) {

			var sBindingObj = {
				"entityPath": "/NotificationNoSet",
				"entityProperties": {
					title: "{path:'NotifNo',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._ReferValueHelpDialog(sBindingObj, null);

		},

		onRoomDialogClose: function(oEvent) {

			// var sTitle = oEvent.getParameter("selectedItem").getTitle();
			// this.getView().byId("notification").setValue(sTitle);
			var selectedItem = oEvent.getParameter("selectedItem");
			if (selectedItem) {
				var sTitle = selectedItem.getTitle();
				this.getView().byId("refer").setValue(sTitle);
				this._fetchAdditionalData(sTitle);

			}

		},
		
			onSelectionChange: function(oEvent) {
			var selectedItem = oEvent.getParameter("selectedItem");
			var selectedId = selectedItem.getKey();
			// Assuming you have an ODataModel named "oDataModel2" for the second OData service
			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			oModel.read("/CreateNotificationSet('" + selectedId + "')", {
				success: function(oData) {
					// Assuming property1 and property2 are properties in the returned data
					var property1 = oData.CollegeCode;
					// var property2 = oData.RequestType;
					var property3 = oData.RoomType;
					var property4 = oData.RequestDate;
					var property5 = oData.Priority;
					var property6 = oData.ReportedBy;
					var property7 = oData.ReportedOn;
					var property8 = oData.Description;
					var property9 = oData.LongText;

					// Assuming you have Input fields with IDs "inputField1" and "inputField2"
					this.getView().byId("label10").setValue(property1);
					// this.getView().byId("label11").setValue(property2);
					this.getView().byId("label13").setValue(property3);
					this.getView().byId("date2").setValue(property4);
					this.getView().byId("label14").setValue(property5);
					this.getView().byId("label15").setValue(property6);
					this.getView().byId("date3").setValue(property7);
					this.getView().byId("dis13").setValue(property8);
					this.getView().byId("long13").setValue(property9);
				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
		},
		
			_fetchAdditionalData:function(selectedData){
			
				var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FACILITY_SRV/");
			oModel.read("/CreateNotificationSet('" + selectedData + "')", {
				success: function(oData) {
					// Assuming property1 and property2 are properties in the returned data
					var property1 = oData.CollegeCode;
					// var property2 = oData.RequestType;
					var property3 = oData.RoomType;
					var property4 = oData.RequestDate;
					var property5 = oData.Priority;
					var property6 = oData.ReportedBy;
					var property7 = oData.ReportedOn;
					var property8 = oData.Description;
					var property9 = oData.LongText;

					// Assuming you have Input fields with IDs "inputField1" and "inputField2"
					this.getView().byId("label10").setValue(property1);
					// this.getView().byId("label11").setValue(property2);
					this.getView().byId("label13").setValue(property3);
					this.getView().byId("date2").setValue(property4);
					this.getView().byId("label14").setValue(property5);
					this.getView().byId("label15").setValue(property6);
					this.getView().byId("date3").setValue(property7);
					this.getView().byId("dis13").setValue(property8);
					this.getView().byId("long13").setValue(property9);
				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			
		},
		
			onSubmit2: function() {
				
					var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTELFACLITY_VACATE_SRV/CreateNotificationSet";

			var dateValue = oView.byId("date2").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
            var ref = oView.byId("refer").getValue();
			var oData = {
			

				// CollegeCode: oView.byId("label10").getSelectedItem().getBindingContext("VacateModel").getProperty("Plant"),
				// RequestType: "N3",
				// RoomType: oView.byId("label13").getSelectedItem().getBindingContext("VacateModel").getProperty("DomainValue"),
				// RequestDate: dateFormat.format(dateValue),
				// Description: oView.byId("dis13").getValue(),
				// LongText: oView.byId("long13").getValue(),
				// Priority: oView.byId("label4").getSelectedItem().getBindingContext("VacateModel").getProperty("MaintPriority"),
				// ReportedBy: oView.byId("label5").getSelectedItem().getBindingContext("VacateModel").getProperty("UserName"),
				// ReportedOn: "",
				// NotificationNumber: ref,
				// Message: "",
				// Location: oView.byId("label12").getSelectedItem().getBindingContext("VacateModel").getProperty("FunctionalLocation"),
				// Reason: oView.byId("res").getValue()
				
				CollegeCode: oView.byId("label10").getValue(),
				RequestType: "N3",
				RoomType: oView.byId("label13").getValue(),
				RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis13").getValue(),
				LongText: oView.byId("long13").getValue(),
				Priority: oView.byId("label14").getValue(),
				ReportedBy: oView.byId("label15").getValue(),
				ReportedOn: "",
				NotificationNumber: ref,
				Message: "",
				Location: oView.byId("label12").getValue(),
				Reason: oView.byId("res").getValue()

				// "AttachmentsSet":""

				// Add other properties as needed
			};
			
				var supdateurl = oModel + "('" + ref + "')";

			$.ajax({
				url: supdateurl,
				method: "PUT",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response

					// var d = response.querySelector("Message").textContent;

					MessageBox.success("Ticket Number : " + "'" + ref + "'" + "successfully updated in backend with");

					// note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					// MessageBox.success("created successfully", successMessage);

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageBox.show("Please select other ticket", error);
				}
			});
			this.refreshCombo1();
		

		},
		
			refreshCombo1: function() {
			var combo1 = this.getView().byId("label10");
			// var combo2 = this.getView().byId("label2");
			var combo3 = this.getView().byId("label11");
			var combo4 = this.getView().byId("com1");
			combo1.setSelectedKey("");
			// combo1.removeAllItems();

			combo3.setSelectedKey("");
			// combo3.removeAllItems();

			combo4.setSelectedKey("");
			// combo4.removeAllItems();

		
			var input2 = this.getView().byId("dis13");
			var input3 = this.getView().byId("long13");
			var input4 = this.getView().byId("date2");
			var input5 = this.getView().byId("label12");
			var input6 = this.getView().byId("label13");
			var input7 = this.getView().byId("refer");
			var input8 = this.getView().byId("label14");
			var input9 = this.getView().byId("res");
			var input10 = this.getView().byId("label15");
			var input11 = this.getView().byId("date3");
			
			input2.setValue("");
			input3.setValue("");
			input4.setValue("");
			input5.setValue("");
			input6.setValue("");
			input7.setValue("");
			input8.setValue("");
			input9.setValue("");
			input10.setValue("");

	       input11.setValue("");


		},
		
			onSubmit3: function() {
				
					var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTELFACLITY_VACATE_SRV/CreateNotificationSet";

			var dateValue = oView.byId("date2").getDateValue();
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
            var ref = oView.byId("refer").getValue();
			var oData = {
			

				// CollegeCode: oView.byId("label10").getSelectedItem().getBindingContext("VacateModel").getProperty("Plant"),
				// RequestType: "N3",
				// RoomType: oView.byId("label13").getSelectedItem().getBindingContext("VacateModel").getProperty("DomainValue"),
				// RequestDate: dateFormat.format(dateValue),
				// Description: oView.byId("dis13").getValue(),
				// LongText: oView.byId("long13").getValue(),
				// Priority: oView.byId("label4").getSelectedItem().getBindingContext("VacateModel").getProperty("MaintPriority"),
				// ReportedBy: oView.byId("label5").getSelectedItem().getBindingContext("VacateModel").getProperty("UserName"),
				// ReportedOn: "",
				// NotificationNumber: ref,
				// Message: "",
				// Location: oView.byId("label12").getSelectedItem().getBindingContext("VacateModel").getProperty("FunctionalLocation"),
				// Reason: oView.byId("res").getValue()
				
			
				NotificationNumber: ref,
				Message: ""
			

				// "AttachmentsSet":""

				// Add other properties as needed
			};
			
				var supdateurl = oModel + "('" + ref + "')";

			$.ajax({
				url: supdateurl,
				method: "DELETE",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// Handle success response

					// var d = response.querySelector("Message").textContent;

					MessageBox.success("Ticket Number : " + "'" + ref + "'" + "successfully Closed");

					// note = response.querySelector("NotificationNumber").textContent;

					// var combo1=this.getView().byId("label1");
					//   combo1.removeAllItems();

					//   var successMessage = response.Message;
					// MessageBox.success("created successfully", successMessage);

				}.bind(this),
				error: function(error) {
					// Handle error response
					MessageBox.show("Ticket Number" + "'" + ref + "'" + "already closed" +  error);
				}
			});
			this.refreshCombo1();
		  

		},
		


	});
});