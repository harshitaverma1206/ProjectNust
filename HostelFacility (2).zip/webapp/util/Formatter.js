sap.ui.define([], function() {
	"use strict";
	return {
		formatCellColor: function(value) {
			if (value === "Available") {
				return "rgb(0, 128, 0)"; // Apply green color directly
			} else {
				return "rgb(255, 0, 0)"; // Apply red color directly
			}
		}
	};
});