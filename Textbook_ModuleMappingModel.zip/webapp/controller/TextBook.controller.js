sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast"
], function(Controller, StandardListItem, CustomData, Filter, FilterOperator, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("Textbook_ModuleMappingModel.controller.TextBook", {
		sDescription: "",
		oLastAddedItem: null,
		onInit: function() {

			this.onReadCollageData();
			this.onReadBookData();

		},
		onReadCollageData: function() {

			// var service = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Z_MAP_BOOK_SRV/");

			// service.read("/ZshStextSet", {
			// 	success: function(oData) {

			// 		var oModel = new sap.ui.model.json.JSONModel();
			// 		oModel.setData(oData);

			// 	}.bind(this),
			// 	error: function(err) {

			// 	}
			// });

			var ssServiceUrl3 = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/";
			var oModel3 = new sap.ui.model.odata.ODataModel(ssServiceUrl3, true);
			this.getView().setModel(oModel3);
			var oJSONModel3 = new sap.ui.model.json.JSONModel();

			oModel3.read("/ZshStextSet", {
				success: function(response) {

					oJSONModel3.setData(response.results);

					this.getView().setModel(oJSONModel3, "Mode");

				}.bind(this),
				error: function(error) {
					//MessageBox.error("technical problem ");

				}
			});

		},
		onReadBookData: function() {

			// var service = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/Z_MAP_BOOK_SRV/");

			// service.read("/ZshStextSet", {
			// 	success: function(oData) {

			// 		var oModel = new sap.ui.model.json.JSONModel();
			// 		oModel.setData(oData);

			// 	}.bind(this),
			// 	error: function(err) {

			// 	}
			// });

			var ssServiceUrl = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(ssServiceUrl, true);
			this.getView().setModel(oModel);
			var oJSONModel = new sap.ui.model.json.JSONModel();

			oModel.read("/ZshMaktxSet", {
				success: function(response) {

					oJSONModel.setData(response.results);

					this.getView().setModel(oJSONModel, "Mode");

				}.bind(this),
				error: function(error) {
					//MessageBox.error("technical problem ");

				}
			});

		},

		onModuleValueHelpRequest: function(oEvent) {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("Textbook_ModuleMappingModel.fragments.ModuleDialog", this);
				this.getView().addDependent(this._oDialog);

			}
			this._oDialog.open();

		},
		onClose: function() {
			this._oDialog.close();
		},
		onListItemPress: function(oEvent) {

			//      var sTitle = oEvent.getParameter("selectedItem").getTitle();
			// this.getView().byId("inputField").setValue(sTitle);
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				// var sSelectedName = oSelectedItem.getTitle(); // Assuming the title contains the value you want to display
				var sSelectedName = oSelectedItem.getTitle();
				this.sSelectedName1 = oSelectedItem.getDescription();

				var oInputField = this.byId("In1"); // Replace with the ID of your input field
				oInputField.setValue(sSelectedName);
			}
			// var table =	this.oTable;
			//   var data= table.getModel().getData().results;
			//   var oModeltab= new sap.ui.model.json.JSONModel();
			// oModeltab.setData(data);
			// this.getView().setModel(oModeltab);
			// var sSelectedData = this.getView().byId("In1").getValue();
			var sUrl = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			// Construct filter object
			this.oFilter = new sap.ui.model.Filter("Objectid", sap.ui.model.FilterOperator.EQ, this.sSelectedName1);
			// Read data from OData service with filter
			oModel.read("/BookStoreSet", {
				filters: [this.oFilter],
				success: function(oData) {
					// Assuming oData contains the retrieved data in JSON format
					var oTableModel = new sap.ui.model.json.JSONModel();
					oTableModel.setData(oData);
					// var oTable = this.getView().byId("myTable");
					// oTable.setModel(oTableModel);
					this.oTable = this.getView().byId("myTable");
					this.oTable.setModel(oTableModel);
					this.oTable.bindItems({
						path: "/results",
						template: this.oTable.getItems()[0] // Use the first item as a template
					});
				}.bind(this),
				error: function(error) {
					// Handle error
				}
			});

		},

		onBookValueHelpRequest: function(oEvent) {
			if (!this._pDialog) {
				this._pDialog = sap.ui.xmlfragment("Textbook_ModuleMappingModel.fragments.SearchBook", this);
				this.getView().addDependent(this._pDialog);

			}
			this._pDialog.open();

		},
		onCloseBook: function() {
			this._pDialog.close();
		},
		onListItemBookPress: function(oEvent) {

			var oSelectedItem1 = oEvent.getParameter("selectedItem");
			if (oSelectedItem1) {
				var sSelectedName1 = oSelectedItem1.getTitle(); // Assuming the title contains the value you want to display
				this.sDescription1 = oSelectedItem1.getDescription();
				var sDescription1 = this.sDescription1;

				var oInputField1 = this.byId("In2"); // Replace with the ID of your input field
				oInputField1.setValue(sSelectedName1);
			}

		},

		// onAdd: function (oEvent){
		// 	var ssServiceUrl3 = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/";
		// 	var oModel3 = new sap.ui.model.odata.ODataModel(ssServiceUrl3, true);
		// 	this.getView().setModel(oModel3);
		// 	var oJSONModel3 = new sap.ui.model.json.JSONModel();

		// 	oModel3.read("/ZshDipaSet", {
		// 		success: function(response) {

		// 			oJSONModel3.setData(response.results);

		// 			this.getView().setModel(oJSONModel3, "Mode");

		// 		}.bind(this),
		// 		error: function(error) {
		// 			//MessageBox.error("technical problem ");

		// 		}
		// 	});

		// },
		onAdd: function() {
			// var sSelectedData = this.getView().byId("In2").getValue();
			// var sUrl = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/";
			// var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
			// // Construct filter object
			// var oFilter = new sap.ui.model.Filter("Maktx", sap.ui.model.FilterOperator.EQ, sSelectedData);
			// // Read data from OData service with filter
			// oModel.read("/ZshDipaSet", {
			// 	filters: [oFilter],
			// 	success: function(oData) {
			// 		// Assuming oData contains the retrieved data in JSON format
			// 		var oTableModel = new sap.ui.model.json.JSONModel();
			// 		oTableModel.setData(oData);
			// 		// var oTable = this.getView().byId("myTable");
			// 		// oTable.setModel(oTableModel);
			// 		this.oTable = this.getView().byId("ShortProductList");
			// 		this.oTable.setModel(oTableModel);
			// 		this.oTable.bindItems({
			// 			path: "/results",
			// 			template: this.oTable.getItems()[0] // Use the first item as a template
			// 		});
			// 	}.bind(this),
			// 	error: function(error) {
			// 		// Handle error
			// 	}
			// });
			var sDescription1 = this.sDescription1;
			var sInputValue = this.byId("In2").getValue();
			var oTable = this.byId("myTable");
			// Create a new item for the table
			var oNewItem = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Text({
						text: sInputValue
					}),
					new sap.m.Text({
						text: sDescription1
					})
				]
			});
			// Add the new item to the table
			oTable.addItem(oNewItem);
			this.oLastAddedItem = oNewItem;

			// 		var sInputValue = this.byId("In2").getValue();
			// var aInputData = sInputValue.split(" "); // Assuming there's a space between ID and name
			// // Extract ID and name from the array
			// var sId = aInputData[0].trim();
			// var sName = aInputData.slice(1).join(" ").trim(); // Join remaining array elements as name
			// var oTable = this.byId("myTable");
			// // Create a new item for the table
			// var oNewItem = new sap.m.ColumnListItem({
			// cells: [
			// new sap.m.Text({ text: sId }),
			// new sap.m.Text({ text: sName })
			// ]
			// });
			// // Add the new item to the table
			// oTable.addItem(oNewItem);

		},
		onSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Stext", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);

		},
		onBookSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter("Maktx", sap.ui.model.FilterOperator.Contains, sValue);
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		onSubmitPress: function() {

			var oTable = this.byId("myTable");
			var aSelectedItems = oTable.getSelectedItems();
			var oModel = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/BookStoreSet";
			var sObjectid = this.sSelectedName1;
			aSelectedItems.forEach(function(oSelectedItem) {
				var oCells = oSelectedItem.getCells();
				var sInputValue = oCells[0].getText(); // Assuming the input value is in the first cell
				var sDescription1 = oCells[1].getText(); // Assuming the description is in the second cell
				// Now you can use sInputValue and sDescription1 as needed
				var oData = {

					Objectid: sObjectid,
					Material: sDescription1

					// Add other properties as needed
				};
				var supdateurl = oModel + "('" + sObjectid + "')";

				$.ajax({
					url: supdateurl,
					method: "PUT",
					contentType: "application/json",
					data: JSON.stringify(oData),
					success: function(response, selectedIndices) {
						// Handle success response
						MessageToast.show("Data successfully updated in backend:", response);
						// var oBinding = oTable.getBinding("items");
						// oBinding.refresh(true);

					
						var oItems = oTable.getItems();
						oItems.forEach(function(oItem) {
							oTable.removeItem(oItem);
						});
						var aInput = sap.ui.getCore().byId("In1");
						var bInput = sap.ui.getCore().byId("In2");
						aInput.setValue("");
						bInput.setValue("");
						
						// if (oBinding) {
						// 	oBinding.refresh();
						// 	oTable.removeSelections(true); // Clear previous selections
						// 	selectedIndices.forEach(function(index) {
						// 		oTable.addSelectionInterval(index, index);
						// 	});
						// } else {
						// 	MessageToast.show("Binding object is undefined");
						// }

					},
					error: function(error) {
						// Handle error response
						MessageToast.show("Book is already added:", error);
					}
				});
			});

		},

		onDeletePress: function() {

			var oTable = this.byId("myTable");
			var aSelectedItems = oTable.getSelectedItems();

			var sObjectid = this.sSelectedName1;

			aSelectedItems.forEach(function(oSelectedItem) {
				var oCells = oSelectedItem.getCells();
				// var sInputValue = oCells[0].getText(); // Assuming the input value is in the first cell
				var sDescription1 = oCells[1].getText(); // Assuming the description is in the second cell
				// Now you can use sInputValue and sDescription1 as needed
				var oData = {

					Objectid: sObjectid,
					Material: sDescription1

					// Add other properties as needed
				};
				// var sEntityId = oModel.getProperty(sPath + "/Material"); // Assuming "ID" is the unique identifier
				var oModel = "/sap/opu/odata/sap/Z_MAP_BOOK_SRV/BookStoreSet"; // Replace with your actual endpoint

				// Send POST request to delete endpoint
				$.ajax({
					url: oModel,
					type: "POST",
					contentType: "application/json",
					data: JSON.stringify(oData),
					success: function() {
						// Handle success
						// oModel.refresh(); // Refresh model to reflect changes

						MessageToast.show("Data successfully deleted");
						aSelectedItems.forEach(function(oSelectedItem1) {
							oTable.removeItem(oSelectedItem1);
						});
						oTable.rerender();

					},

					error: function() {
						// Handle error
					}

				});
			});

		},

		onCancelPress: function() {
			var oTable = this.byId("myTable");
			if (this.oLastAddedItem) {
				oTable.removeItem(this.oLastAddedItem);
			}
			MessageToast.show("New Added book is canceld");

		}

	});
});