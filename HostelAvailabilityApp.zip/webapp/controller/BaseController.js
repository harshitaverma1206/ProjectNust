sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/ui/core/routing/History",
		"sap/ui/core/UIComponent",
		"sap/ui/Device",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/m/StandardListItem",
		"sap/ui/core/CustomData",
		"sap/m/Input"
], function(Controller, History, UIComponent, Device, Filter, FilterOperator, StandardListItem, CustomData, Input) {
	"use strict";

	return Controller.extend("HostelAvailabilityApp.controller.BaseController", {
		_oResourceBundle: null,
			_busyDialog: null,
         onInit:function(){
         	
         },
        getRouter: function () {
				return UIComponent.getRouterFor(this);
			},
			/**
			 * Convenience method for getting the view model by name.
			 * @public
			 * @param {string} [sName] the model name
			 * @returns {sap.ui.model.Model} the model instance
			 */
			getModel: function (sName) {
				if (sName) {
					return this.getOwnerComponent().getModel(sName);
				} else {
					return this.getOwnerComponent().getModel();
				}
			},
			/**
			 * Getter for the resource bundle.
			 * @public
			 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
			 */
			getResourceBundle: function () {
				if ($.isEmptyObject(this._oResourceBundle)) {
					this._oResourceBundle = this.getOwnerComponent().getModel("i18n")._oResourceBundle;
				}
				return this._oResourceBundle;
			},
			/**
			 * @param {string} key, retrun the text
			 * @returns {BaseController_L6.BaseControllerAnonym$1@pro;_oResourceBundle@call;getText} string
			 */
			getTextFromBundle: function (key) {
				return this.getResourceBundle().getText(key);
			},
			/**
			 *It returns the instance of the main model for storing all data across screen. The name of the model is 'DataExchng'
			 * @public
			 * @returns {BaseController_L6.BaseControllerAnonym$1@call;getOwnerComponent@call;getModel} model
			 */
			getDataExchngModel: function () {
				return this.getOwnerComponent().getModel("DataExchng");
			},
			/**
			 * It returns the instance of the main model for storing all data across screen. The name of the model is 'LocalDataModel'
			 * @returns {undefined}
			 */
			getLocalModel: function () {
				return this.getOwnerComponent().getModel("LocalDataModel");
			},
			/**
			 * It returns the instance of the language model for storing all data across screen. The name of the model is 'LocalDataModel'
			 * @returns {undefined}
			 */
			getLanguageModel: function () {
				return this.getOwnerComponent().getModel("LanguageModel");
			},
			/**
			 *
			 * @returns {undefined}
			 */
			onRouteMatched: function () {
				//abstract method, child will implement it.
			},
			/**
			 *
			 * @returns {undefined}
			 */
			hideBusyDialog: function () {
				this._oErrorHandler.hideBusyDialog();
			},
			showBusyDialog: function () {
				this._oErrorHandler.showBusyDialog();
			},
			showBusyMessageDialog: function (msg) {
				this._oErrorHandler.showBusyMessageDialog(msg);
			},
			/**
			 *
			 * @returns {undefined}
			 */
			hideBusyMessageDialog: function () {
				this._oErrorHandler.hideBusyMessageDialog();
			},
			showMessage: function (text, type, fncallBack) {
				var sText = text;
				if ($.isEmptyObject(sText)) {
					sText = "MESSAGE_GEN_EXCEPTION";
				}
				/*var fullText = this.getTextFromBundle(sText);
				if ($.isEmptyObject(sText)) {
					fullText = sText;
				}*/
				this._oErrorHandler.showMessage(sText, type, fncallBack);
			},
			/**
			 * @param {type} value, return the string
			 * @returns {Boolean} boolean
			 */
			isBackendDataNotNull: function (value) {
				return !$.isEmptyObject(value) && value.hasOwnProperty("results") && value.results.length > 0;
			},
			showMessageToast: function (text, options) {
				var sText = text;
				if ($.isEmptyObject(sText)) {
					sText = this.getTextFromBundle("MESSAGE_GEN_EXCEPTION");
				}
				this._oErrorHandler.showMessageToast(sText, options);
			},
			_showServiceError: function (sText) {
				this._oErrorHandler._showServiceError(sText);
			},

			/**
			 * Event handler for navigating back.
			 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
			 * If not, it will replace the current entry of the browser history with the master route.
			 * @public
			 */
			onPressNavBack: function (oEvent) {
				var appContent = this.byId("homeGenericApp");
				if (appContent) {
					appContent.back();
					if (this._lastTileName) {
						this.getModel("LocalDataModel").setProperty("/titles/groupTileName", this._lastTileName);
					}
				}
			},
			getDeviceProperties: function () {
				return Device;
			},
			// need to remove unneccesary code 
			_createValueHelpDialogs: function (fragmentName, oDialogName, filters, stockType) {
				this._customDataValue = "";
				if (!oDialogName) {
					oDialogName = sap.ui.xmlfragment("HostelAvailabilityApp.fragments." + fragmentName, this);
					this.getView().addDependent(oDialogName);
				}
				if (filters) {
					var content = oDialogName.getAggregation("_dialog").getAggregation("content");
					if (content && content.length > 0) {
						content[1].getBinding("items").filter(filters);
					}
				}
				oDialogName.open();
				this._currentDialog = oDialogName;
				return oDialogName;
			},
			//=======
			onCancel: function (oEvent) {
				this._oAllValueHelpDialog.close();
			},
			onLiveSearch: function (oEvent) {
				if (oEvent.getParameter("value").length > 2) {
					//	this._oErrorHandler.showBusyDialog();
					this.onSearch(oEvent);
				}
			},
			onSearch: function (oEvent) {
				var sQuery = oEvent.getParameter("value"),
					aFilters;
				this._previousFilters = [];
				if (sQuery) {
					var properties = oEvent.getSource().getBinding("items") && oEvent.getSource().getBinding("items").oEntityType ? oEvent.getSource()
						.getBinding("items").oEntityType.property : "",
						arrayFilters = [],
						sPath = oEvent.getSource().getBinding("items").sPath;
					if (sPath === "/DeliveryHeaderSet" || sPath === "/PurchaseOrderHeaderSet") {
						properties.splice(1, properties.length - 1);
					}
					/*if(sPath === "/PpOrderf4Set"){
						this._filtersArrayObject.aFilters.pop();
						properties.splice(2,properties.length-1);
					}*/
					if (properties && properties.length > 0) {
						properties.forEach(function (element, index) {
							if (element.type === "Edm.String") {
								arrayFilters.push(new Filter(element.name, FilterOperator.Contains, sQuery));
							}
						}.bind(this));
						aFilters = new Filter({
							filters: arrayFilters,
							and: false
						});
						oEvent.getSource().getBinding("items").filter(aFilters);
					}
					aFilters = new Filter({
						filters: arrayFilters,
						and: false
					});
					oEvent.getSource().getBinding("items").filter(aFilters);
					//this._oAllValueHelpDialog.getBinding("items").filter(aFilters);
				} else {
					if (this._filterRequired) {
						oEvent.getSource().getBinding("items").filter(this._filtersArrayObject || []);
						//oEvent.getSource().getBinding("items").filter(this._filtersArrayObject);
					} else {
						oEvent.getSource().getBinding("items").filter(this._previousFilters);
					}
				}
				//	this._oErrorHandler.hideBusyDialog();
			},
		
			_filters: function (sFiltersObject, conditionalFlag) {
				var arrayFilters = [],
					aFilters;
				sFiltersObject.forEach(function (element, index) {
					var operator = FilterOperator[element.filterOperator] ? FilterOperator[element.filterOperator] : FilterOperator.Contains;
					arrayFilters.push(new Filter(element.sPath, operator, element.sValue));
					//	arrayFilters.push(new Filter(element.sPath, FilterOperator.EQ, element.sValue));
				});
				aFilters = new Filter({
					filters: arrayFilters,
					and: conditionalFlag
				});
				return aFilters;
			},
			/**
			 * Returns instance of filter dialog
			 * @returns {Object} fragment for Functional Group Value help
			 * @private
			 */

			_allValueHelpDialog: function (sBindingObj, oDialogName, filters, stockType) {
				this._customDataValue = "";
				//	var oAllValueHelpDialog = oDialogName;
				if (!this._oAllValueHelpDialog) {
					this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.AllValueHelpDialog", this);
					this.getView().addDependent(this._oAllValueHelpDialog);
					jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
				}
				if (this._oAllValueHelpDialog) {
					this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
					this._oAllValueHelpDialog.destroyItems();
					this._oAllValueHelpDialog.destroyCustomData();
					this._sBindingValueHelpPath = sBindingObj.entityPath;
					this._oAllValueHelpDialog.bindAggregation("items", {
						path: sBindingObj.entityPath,
						templateSharable: false,
						filters: filters,
						template: new StandardListItem(sBindingObj.entityProperties)
					});
					this._oAllValueHelpDialog.addCustomData(new CustomData({
						key: sBindingObj.customData.key,
						value: sBindingObj.customData.value
					}));
				}
				// as of now not using, will see later.
				/*this._oAllValueHelpDialog = new SelectDialog({
					noDataText: "{i18n>tableNoDataText}",
					growingThreshold: 50,
					growing: true,
					search: [this.onSearch, this],
					confirm: [this.onDialogClose, this],
					title: sBindingObj.oDialogTitle,
					items: {
						path: sBindingObj.entityPath,
						templateSharable: false,
						filters: filters,
						template: new StandardListItem(sBindingObj.entityProperties)
					},
					customData: {
						key: sBindingObj.customData.key,
						value: sBindingObj.customData.value
					}
				});*/
				this._oAllValueHelpDialog.open();
				//	this._currentDialog = oAllValueHelpDialog;
				return this._oAllValueHelpDialog;
			},
		
			_callMessageDialog: function (fncallBack) {
				var input = new Input({
					placeholder: this.getTextFromBundle("PLEASE_ENTER_FILENAME"),
					value: "{path:'DataExchngModel>/excelObj/excelFileName'}",
					valueState: "{path:'DataExchngModel>/excelObj/valueState'}",
					maxLength: 40
				});
				input.setModel(this.getModel("DataExchngModel"), "DataExchngModel");
				this._oErrorHandler.showMessage(input, "confirm", fncallBack);
			},
			openTransferChartDialog: function () {
				if (!this._oTransferStockChartDialog) {
					this._oTransferStockChartDialog = sap.ui.xmlfragment("com.yash.ui5.inventory.manager.fragments.TransferStockChart", this);
					this.getView().addDependent(this._oTransferStockChartDialog);
				}
				this._oTransferStockChartDialog.open();
			},
			onCancelPressChartDialog: function () {
				this._oTransferStockChartDialog.close();
			},
			_getChartData: function (sQuery) {
				this.getModel().read("/STOCK_TOTSet", {
					urlParameters: {
						$filter: sQuery
					},
					success: function (oData) {
						this.getModel("LocalDataModel").setProperty("/transferStockDataChart", oData.results);
						//	this.openTransferChartDialog(); not required as of now
					}.bind(this),
					error: function (oError) {
						this.hideBusyDialog();
						this._showServiceError(oError);
					}.bind(this)
				});
			},
			onStepNavBack: function (oEvent) {
				this.showBusyDialog();
				var oHistory = History.getInstance(),
					sPreviousHash = oHistory.getPreviousHash();
				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					this.getRouter().navTo("Home", true);
				}
			},
			onPressHome: function () {
				this.showBusyDialog();
				this.getRouter().navTo("Home");
			},

			// dataRangleSelection to identify the dates in the filters
			_objectFilters: function (sfilters, dataRangleSelection) {
				var arrayFilters = [],
					aFilters;
				//	sQuery = "";
				$.each(sfilters, function (key, value) {
					if (key && value) {
						//	sQuery += key + " eq '" + value + "' and ";
						if (key === "PostingDate" || key === "DocumentDate" && dataRangleSelection) {
							var value1 = value.split("-");
							arrayFilters.push(new Filter(key, FilterOperator.BT, value1[0].trim(), value1[1].trim()));
						} else {
							arrayFilters.push(new Filter(key, FilterOperator.EQ, value.toUpperCase()));
						}
						aFilters = new Filter({
							filters: arrayFilters,
							and: true
						});
					}
				});
				return aFilters;
			}
		
		
	});
});