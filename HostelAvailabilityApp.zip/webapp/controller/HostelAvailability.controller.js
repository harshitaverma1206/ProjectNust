sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	// "../model/models"
	"../util/Formatter"

], function(Controller, StandardListItem, CustomData, Filter, FilterOperator, JSONModel, Formatter) {
	"use strict";

	return Controller.extend("HostelAvailabilityApp.controller.HostelAvailability", {
		onInit: function() {
			// this.getOwnerComponent().getModel("codeODataModel");
			// var oModel = this.getOwnerComponent().getModel("codeODataModel");
			// this.getView().getModel(oModel, "MainModel");
			// var oTable = this.byId("HostelTable");
			// oTable.setVisible(false);

			// 		var oDataModel = this.getOwnerComponent().getModel("codeODataModel");
			// this.getView().setModel(oDataModel, "oDataModel");

		},

		_codeValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.CodeValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onCodeValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "codeODataModel>/ZIPMPLANTVH",
				"entityProperties": {
					title: "{path:'codeODataModel>Plant',templateSharable:true}",
					description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "Plant",
					"value": ""
				}
			};
			this._codeValueHelpDialog(sBindingObj, null);

		},

		onDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In1").setValue(sTitle);

		},

		_locValueHelpDialog: function(sBindingObj1, oDialogName1, filters1, stockType1) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1 = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.LocationValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog1);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog1);
			}
			if (this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1.setTitle(sBindingObj1.oDialogTitle1);
				this._oAllValueHelpDialog1.destroyItems();
				this._oAllValueHelpDialog1.destroyCustomData();
				this._sBindingValueHelpPath1 = sBindingObj1.entityPath;
				this._oAllValueHelpDialog1.bindAggregation("items", {
					path: sBindingObj1.entityPath,
					templateSharable: false,
					filters: filters1,
					template: new StandardListItem(sBindingObj1.entityProperties)
				});
				this._oAllValueHelpDialog1.addCustomData(new CustomData({
					key: sBindingObj1.customData.key,
					value: sBindingObj1.customData.value
				}));
			}

			this._oAllValueHelpDialog1.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog1;
		},

		_filters: function(sFiltersObject, conditionalFlag) {
			var arrayFilters = [],
				aFilters;
			sFiltersObject.forEach(function(element, index) {
				var operator = FilterOperator[element.filterOperator] ? FilterOperator[element.filterOperator] : FilterOperator.Contains;
				arrayFilters.push(new Filter(element.sPath, operator, element.sValue));
				//	arrayFilters.push(new Filter(element.sPath, FilterOperator.EQ, element.sValue));
			});
			aFilters = new Filter({
				filters: arrayFilters,
				and: conditionalFlag
			});
			return aFilters;
		},

		onLocationValueHelpRequest: function(OEvent) {
			//         this._filterRequired = true;

			// // var fragmentName = "PlantValueHelpDialog", // fragemntName from fragments folders
			// var filtersObject;
			var sBindingObj1 = {
				"entityPath": "codeODataModel>/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'codeODataModel>FunctionalLocation',templateSharable:true}",
					description: "{path:'codeODataModel>FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			//var sPlant = this.getView().getModel("LocalDataModel").getProperty("/filters/Plant"),
			this._locValueHelpDialog(sBindingObj1, null);
			// 	filtersObject = [{
			// 	"sPath": "Plant",
			// 	"sValue": sPlant,
			// 	"filterOperator": "EQ"
			// }];
			// this._filtersArrayObject = this._filters(filtersObject, true);
			// this._locValueHelpDialog(sBindingObj1, null, this._filtersArrayObject);

		},

		onLocDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In2").setValue(sTitle);

		},

		// for room
		_roomValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.RoomValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog2);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
			}
			if (this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
				this._oAllValueHelpDialog2.destroyItems();
				this._oAllValueHelpDialog2.destroyCustomData();
				this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
				this._oAllValueHelpDialog2.bindAggregation("items", {
					path: sBindingObj2.entityPath,
					templateSharable: false,
					filters: filters2,
					template: new StandardListItem(sBindingObj2.entityProperties)
				});
				this._oAllValueHelpDialog2.addCustomData(new CustomData({
					key: sBindingObj2.customData.key,
					value: sBindingObj2.customData.value
				}));
			}

			this._oAllValueHelpDialog2.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog2;
		},

		onRoomValueHelpRequest: function(OEvent) {

			var sBindingObj2 = {
				"entityPath": "codeODataModel>/ZIROOMTYPEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>DomainDescription',templateSharable:true}",
					description: "{path:'codeODataModel>DomainValue',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._roomValueHelpDialog(sBindingObj2, null);

		},

		onRoomDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},

		// for priority

		_priorValueHelpDialog: function(sBindingObj3, oDialogName3, filters3, stockType3) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3 = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.PriorityValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog3);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog3);
			}
			if (this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3.setTitle(sBindingObj3.oDialogTitle1);
				this._oAllValueHelpDialog3.destroyItems();
				this._oAllValueHelpDialog3.destroyCustomData();
				this._sBindingValueHelpPath3 = sBindingObj3.entityPath;
				this._oAllValueHelpDialog3.bindAggregation("items", {
					path: sBindingObj3.entityPath,
					templateSharable: false,
					filters: filters3,
					template: new StandardListItem(sBindingObj3.entityProperties)
				});
				this._oAllValueHelpDialog3.addCustomData(new CustomData({
					key: sBindingObj3.customData.key,
					value: sBindingObj3.customData.value
				}));
			}

			this._oAllValueHelpDialog3.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog3;
		},

		onPriorValueHelpRequest: function(OEvent) {

			var sBindingObj3 = {
				"entityPath": "codeODataModel>/ZIPMPRIORITYVH",
				"entityProperties": {
					title: "{path:'codeODataModel>MaintPriorityDesc',templateSharable:true}",
					description: "{path:'codeODataModel>MaintPriority',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._priorValueHelpDialog(sBindingObj3, null);

		},

		onPriorDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In4").setValue(sTitle);

		},

		// for system

		_systemValueHelpDialog: function(sBindingObj4, oDialogName4, filters4, stockType4) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4 = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.SystemValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog4);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog4);
			}
			if (this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4.setTitle(sBindingObj4.oDialogTitle1);
				this._oAllValueHelpDialog4.destroyItems();
				this._oAllValueHelpDialog4.destroyCustomData();
				this._sBindingValueHelpPath4 = sBindingObj4.entityPath;
				this._oAllValueHelpDialog4.bindAggregation("items", {
					path: sBindingObj4.entityPath,
					templateSharable: false,
					filters: filters4,
					template: new StandardListItem(sBindingObj4.entityProperties)
				});
				this._oAllValueHelpDialog4.addCustomData(new CustomData({
					key: sBindingObj4.customData.key,
					value: sBindingObj4.customData.value
				}));
			}

			this._oAllValueHelpDialog4.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog4;
		},

		onSystemValueHelpRequest: function(OEvent) {

			var sBindingObj4 = {
				"entityPath": "codeODataModel>/ZISYSTEMSTATUSVH",
				"entityProperties": {
					title: "{path:'codeODataModel>StatusKey',templateSharable:true}",
					description: "{path:'codeODataModel>FinalStatus',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._systemValueHelpDialog(sBindingObj4, null);

		},

		onSystemDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In5").setValue(sTitle);

		},

		// for reported

		_reportValueHelpDialog: function(sBindingObj5, oDialogName5, filters5, stockType5) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5 = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.ReportedByValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog5);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5.setTitle(sBindingObj5.oDialogTitle5);
				this._oAllValueHelpDialog5.destroyItems();
				this._oAllValueHelpDialog5.destroyCustomData();
				this._sBindingValueHelpPath5 = sBindingObj5.entityPath;
				this._oAllValueHelpDialog5.bindAggregation("items", {
					path: sBindingObj5.entityPath,
					templateSharable: false,
					filters: filters5,
					template: new StandardListItem(sBindingObj5.entityProperties)
				});
				this._oAllValueHelpDialog5.addCustomData(new CustomData({
					key: sBindingObj5.customData.key,
					value: sBindingObj5.customData.value
				}));
			}

			this._oAllValueHelpDialog5.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog5;
		},

		onReportValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "codeODataModel>/ZIPMUSERNAMEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>UserName',templateSharable:true}",
					description: "{path:'codeODataModel>LongName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "UserName",
					"value": ""
				}
			};
			this._reportValueHelpDialog(sBindingObj5, null);

		},

		onReportDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In6").setValue(sTitle);

		},

		onGo: function() {
			// var selectedValue = this.byId("In1").getValue();
			// var selectedValue1 = this.byId("In2").getValue();
			// var selectedValue2 = this.byId("In4").getValue();
			// var selectedValue4 = this.byId("In6").getValue();
			// var selectedValue5 = this.byId("In5").getValue();
            
			// // Construct filter for second OData service
			// var oFilter = new sap.ui.model.Filter("CollegeCode", sap.ui.model.FilterOperator.EQ, selectedValue);
			// var oFilter1 = new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.EQ, selectedValue1);
			// var oFilter2 = new sap.ui.model.Filter("Priority", sap.ui.model.FilterOperator.EQ, selectedValue2);

			// var oFilter4 = new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue4);
			// var oFilter5 = new sap.ui.model.Filter("SystemStatus", sap.ui.model.FilterOperator.EQ, selectedValue5);

			// var combinedFilter = new sap.ui.model.Filter({
			// 	filters: [oFilter, oFilter1, oFilter2, oFilter4, oFilter5],
			// 	// filters: [oFilter],
			// 	and: false
			// });
			// // Get data from second OData service with filter
			// var oModel = this.getOwnerComponent().getModel("codeODataModel");
			// oModel.read("/GetHostelDataSet", {
			// 	filters: [combinedFilter],
			// 	success: function(oData, response) {
			// 		// Handle success response
			// 		var oFilteredData = oData.results.filter(function(item) {
			// 			// return item.CollegeCode === selectedValue || item.Location === selectedValue1 || item.Priority === selectedValue2 || item.ReportedBy === selectedValue4 || item.SystemStatus === selectedValue5;
			// 			var matchFound = false;
			// 			// Check if any of the conditions match
			// 			if (item.CollegeCode === selectedValue) {
			// 				matchFound = true;
			// 			} else if (item.Location === selectedValue1) {
			// 				matchFound = true;
			// 			} else if (item.Priority === selectedValue2) {
			// 				matchFound = true;
			// 			} else if (item.SystemStatus === selectedValue5) {
			// 				matchFound = true;
			// 			} else if (item.ReportedBy === selectedValue4) {
			// 				matchFound = true;
			// 			}

			// 			return matchFound;

			// 		});

			// 		var selecteDate = this.byId("date").getValue();

			// 		var oTable = this.byId("HostelTable");
			// 		oTable.setModel(new sap.ui.model.json.JSONModel({
			// 			results: oFilteredData,
			// 			selecteDate: selecteDate
			// 		}));
			// 	}.bind(this),
			// 	error: function(oError) {
			// 		// Handle error
			// 	}

			// });
			
		
			// Construct filter for second OData service
	

		

		
		
		
			var oTable = this.getView().byId("HostelTable");
			var selectedValue = this.byId("In1").getValue();
			var selectedValue1 = this.byId("In2").getValue();
			var selectedValue2 = this.byId("In4").getValue();
			var selectedValue3 = this.byId("In3").getValue();
			var selectedValue4 = this.byId("In6").getValue();
			var selectedValue5 = this.byId("In5").getValue();
			// var selectedValue6 = this.byId("In8").getValue();
			var selectedValue7 = this.byId("In7").getValue();

			var aFilters = [];

			// Construct filters
			if (selectedValue) {
			aFilters.push(new sap.ui.model.Filter("CollegeCode", sap.ui.model.FilterOperator.EQ, selectedValue));
			}

			if (selectedValue1) {
				aFilters.push( new sap.ui.model.Filter("Location", sap.ui.model.FilterOperator.EQ, selectedValue1));
			}

			if (selectedValue2) {
			aFilters.push(new sap.ui.model.Filter("Priority", sap.ui.model.FilterOperator.EQ, selectedValue2));
			}
			if (selectedValue3) {
			aFilters.push(new sap.ui.model.Filter("RoomType", sap.ui.model.FilterOperator.EQ, selectedValue3));
			}
			
			if (selectedValue4) {
			aFilters.push(new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue4));
			}
			
			if (selectedValue5) {
			aFilters.push(new sap.ui.model.Filter("SystemStatus", sap.ui.model.FilterOperator.EQ, selectedValue5));
			}
			if (selectedValue7) {
			aFilters.push(new sap.ui.model.Filter("NotificationNo", sap.ui.model.FilterOperator.EQ, selectedValue7));
			}
			
			

			// Apply filters to the table binding
			oTable.getBinding("items").filter(aFilters);

		

		},
		// Define formatter function
		formatCellColor: function(value) {
			if (value === "available") {
				return "sapUiGreen"; // Apply green color class
			} else {
				return "sapUiRed"; // Apply red color class
			}
		},
		
		
			_RequestNumValueHelpDialog: function(sBindingObj10, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._NumValueHelpDialog) {
				this._NumValueHelpDialog = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.RequestNum", this);
				this.getView().addDependent(this._NumValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._NumValueHelpDialog) {
				this._NumValueHelpDialog.setTitle(sBindingObj10.oDialogTitle);
				this._NumValueHelpDialog.destroyItems();
				this._NumValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj10.entityPath;
				this._NumValueHelpDialog.bindAggregation("items", {
					path: sBindingObj10.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj10.entityProperties)
				});
				this._NumValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj10.customData.key,
					value: sBindingObj10.customData.value
				}));
			}

			this._NumValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._NumValueHelpDialog;
		},

		onRequestNumValueHelp: function(OEvent) {

			var sBindingObj10 = {
				"entityPath": "codeODataModel>/NotificationNoSet",
				"entityProperties": {
					title: "{path:'codeODataModel>NotifNo',templateSharable:true}"
					// description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._RequestNumValueHelpDialog(sBindingObj10, null);

		},
	    onNumDialogClose: function(oEvent) {

			var sTitle10 = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In7").setValue(sTitle10);

		},
		
		
			_RTypeValueHelpDialog: function(sBindingObj11, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._TypeValueHelpDialog) {
				this._TypeValueHelpDialog = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.RequestType", this);
				this.getView().addDependent(this._TypeValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._TypeValueHelpDialog) {
				this._TypeValueHelpDialog.setTitle(sBindingObj11.oDialogTitle);
				this._TypeValueHelpDialog.destroyItems();
				this._TypeValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj11.entityPath;
				this._TypeValueHelpDialog.bindAggregation("items", {
					path: sBindingObj11.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj11.entityProperties)
				});
				this._TypeValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj11.customData.key,
					value: sBindingObj11.customData.value
				}));
			}

			this._TypeValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._TypeValueHelpDialog;
		},

	onReTypeValueHelp: function(OEvent) {

			var sBindingObj11 = {
				"entityPath": "codeODataModel>/I_PMNotificationTypeStdVH",
				"entityProperties": {
					title: "{path:'codeODataModel>NotificationType',templateSharable:true}",
					description: "{path:'codeODataModel>NotificationType_Text',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotificationType",
					"value": ""
				}
			};
			this._RTypeValueHelpDialog(sBindingObj11, null);
			
		

		},
	    onTypeDialogClose: function(oEvent) {

			var sTitle12 = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In8").setValue(sTitle12);

		}
	


	});
});