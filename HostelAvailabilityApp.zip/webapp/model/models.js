// sap.ui.define([
// 	"sap/ui/model/json/JSONModel",
// 	"sap/ui/Device"
// ], function(JSONModel, Device) {
// 	"use strict";

// 	return {

// 		createDeviceModel: function() {
// 			var oModel = new JSONModel(Device);
// 			oModel.setDefaultBindingMode("OneWay");
// 			return oModel;
// 		}

// 	};
// });
sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		_getLocalModelInitialData: function () {
			return {
				"inboundGroupList": [{
					"tileName": "Manage Stock Single Material",
					"subTitle": "with Initial Entry",
					"routeName": "ManageStockMaterial",
					"icon": "sap-icon://inventory",
					"groupName": "inboundGroupList",
					"key": "initialEntry"
				}, {
					"tileName": "Post Goods Receipt",
					"subTitle": "",
					"routeName": "PostGoodsReceipt",
					"icon": "sap-icon://receipt",
					"groupName": "inboundGroupList"
				}],
				"inventoryWareHouseList": [{
					"tileName": "Manage Stock Single Material",
					"subTitle": "with Scrapping",
					"routeName": "ManageStockMaterial",
					"icon": "sap-icon://inventory",
					"subItems": false,
					"key": "scrapping"
				}, {
					"tileName": "Transfer Stock -In Plant",
					"subTitle": "",
					"routeName": "TransferStockInPlant",
					"icon": "sap-icon://shipping-status",
					"groupName": "inventoryWareHouseList"
				}, {
					"tileName": "Physical Inventory",
					"subTitle": "",
					"icon": "sap-icon://inventory",
					"subActions": "physicalInventoryActions",
					"groupName": "inventoryWareHouseList",
					"physicalInventoryActions": [{
						"tileName": "Create Physical Inventory",
						"subTitle": "",
						"routeName": "CreatePhysicalInventory",
						"icon": "sap-icon://add-document"
					}, {
						"tileName": "Physical Inventory Count",
						"subTitle": "",
						"routeName": "PhysicalPostInventoryCount", // same as route targteName in manifest.json file
						"icon": "sap-icon://activity-individual",
						"parameter": "physcialInventoryPage"
					}, {
						"tileName": "Post Inventory Count",
						"subTitle": "",
						"routeName": "PhysicalPostInventoryCount",
						"icon": "sap-icon://activity-items",
						"parameter": "postInventoryPage"
					}]
				}, {
					"tileName": "Material Staging",
					"subTitle": "",
					"routeName": "MaterialStaging",
					"icon": "sap-icon://shipping-status",
					"groupName": "inventoryWareHouseList"
				}],

				"inventoryDashboardList": [{
					"tileName": "Stock Mutliple Material",
					"subTitle": "",
					"routeName": "StockMultipleMaterial",
					"icon": "sap-icon://product",
					"groupName": "inventoryDashboardList"
				}, {
					"tileName": "Batches With Expires Shelf Life",
					"subTitle": "",
					"routeName": "BatchesExpiresShelfLife",
					"icon": "sap-icon://inventory",
					"groupName": "inventoryDashboardList"
				}, {
					"tileName": "Slow Moving Stock",
					"subTitle": "",
					"routeName": "SlowMovingStock",
					"icon": "sap-icon://inventory",
					"groupName": "inventoryDashboardList"
				}, {
					"tileName": "Physical Inventory Documents Not Counted",
					"subTitle": "",
					"routeName": "PhysicalInventoryNotCounted",
					"icon": "sap-icon://inventory",
					"groupName": "inventoryDashboardList"
				}],
				"outboundGroupList": [{
					"tileName": "Manage Stock Single Material",
					"subTitle": "with Cost Center",
					"routeName": "ManageStockMaterial",
					"icon": "sap-icon://inventory",
					"key": "costCenter"
				}, {
					"tileName": "Goods Issue",
					"subTitle": "",
					"routeName": "GoodsIssue",
					"icon": "sap-icon://cart-full",
					"groupName": "outboundGroupList"
				}, {
					"tileName": "Vendor Returns",
					"subTitle": "",
					"routeName": "VendorReturns",
					"icon": "sap-icon://quality-issue",
					"groupName": "outboundGroupList"
				}, {
					"tileName": "Pick Outbound Delivery",
					"subTitle": "",
					"routeName": "PicOutboundDelivery",
					"icon": "sap-icon://quality-issue",
					"groupName": "outboundGroupList"
				}],
				"titles": {
					"groupTileName": "",
					"physicalInventoryLineItems": "",
					"inventoryDocument": "",
					"transferStockPlantTotal": "",
					"manageStockItemsTotal": "",
					"ItemsTotal": ""

				},
				"physicalInventoryHeader": {},
				"createPhysicalInvItemSet": [],
				"height": "250px",
				"width": "400px",
				"createPhyscialInvenHeader": {
					"Physinvtrydochasqtysnapshot": false,
					"Postingisblockedforphysinvtry": false,
					"Plant": "",
					"Storagelocation": ""
				},
				"materialStockDetails": [],
				"transferStockInPlant": [],
				"stockTypeName": "",
				"postStockFragment": {
					"plant": "",
					"material": "",
					"batch": "",
					"storageLocation": "",
					"stockType": "",
					"quantity": "",
					"baseUnit": "",
					"rowObject": {},
					"stockMode": {},
					"reqQuantity": 0,
					// "costCenters": [],
					"costCenterName": "",
					// "reasonCodes": [],
					"reasonCodeName": ""
				},
				"filters": {
					
					"Plant": ""
					
				},
				"headerData": {},
				"itemData": [],
				"processData": {
					"Purchaseordernumber": null,
					"Deliverynumber": null,
					"PostingDate": new Date(),
					"DocumentDate": new Date(),
					"productionOrderNumber": null,
					"processOrdernumber": null
				},
				"goodsIssueData": {
					"OrderNumber": null,
					"ProcessOrderNumber": null,
					"ProductionOrderNUmber": null,
					"PostingDate": new Date(),
					"DocumentDate": new Date(),
					"ProductionDate":null,
					"PpOrder": null
				},
				"materialDocumentOverviewItems": [],
				"vendorReturnsData": {
					"MaterialDocument": null,
					"PostingDate": new Date(),
					"DocumentDate": new Date(),
					"Deliverynumber": null
				}

			};
		},
		_getDataExchngModelInitialData: function () {
			return {
				"visibility": {
					"physcialPostInventoryCount": true,
					"detailSave": true,
					"create": false,
					"settingsBtn": false,
					"excelBtn": false,
					"PORadioBtnSel": false,
					"ODRadioBtnSel": false,
					"ProcRadBtnSel": false,
					"ProdRadBtnSel": false,
					"postButton": false,
					"postButtonEnabled": false,
					"initialEntryKey": false,
					"prdMtlOrder": false,
					"processMtlOrder": false
				},
				"transferStockDialogData": {
					"transferUploadData": {},
					"transferDownloadData": {},
					"PostingDate": new Date(),
					"DocumentDate": new Date(),
					"QuantityInEntryUnit": 0

				},
				"excelObj": {
					"excelFileName": "",
					"valueState": "None"
				},
				"reversalDocMtlItems": {
					"PostingDate": new Date(),
					"MaterialDocumentHeaderText": ""
				},
				"i18n": {
					"manageStockMaterialTitle": "Manage Stock Single Material"
				}

			};
		}

	};
});