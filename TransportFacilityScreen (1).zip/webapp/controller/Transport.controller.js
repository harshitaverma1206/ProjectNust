sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("TransportFacilityScreen.controller.Transport", {
		
		onInit: function() {},

		onSubmit: function(oEvent) {
			// MessageToast.show("hello how are you");
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("SupervisorScreen");
		}

	});
});