sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/m/MessageBox",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/NumberFormat"
], function(Controller, JSONModel, Filter, MessageBox, FilterOperator, NumberFormat) {
	"use strict";

	return Controller.extend("ZFLEXIPAY_NUST.controller.Main", {
		onInit: function() {
			this._oModel = this.getOwnerComponent().getModel();
			//Routing
			this._oRouter = this.getOwnerComponent().getRouter();
			this._oRouter.getRoute("Main").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched: function(oRoute) {
			var oModel = new JSONModel({
				Date: "",
				fromMinDate: new Date()
			});
			this.getView().setModel(oModel, "olocal");
			this.getView().getModel('olocal').setProperty("/date", "");
			//	this.fAmount = 60;
			// var oModel = new JSONModel([{
			// 	"Date": null,
			// 	"Amount": '',
			// 	"PaymentNo": "1",
			// 	"CheckNumber": "",
			// 	"CheckDate": null

			// }, {

			// 	"Date": null,
			// 	"Amount": '',
			// 	"PaymentNo": "2",
			// 	"CheckNumber": "",
			// 	"CheckDate": null
			// }, {
			// 	"Date": null,
			// 	"Amount": '',
			// 	"PaymentNo": "3",
			// 	"CheckNumber": "",
			// 	"CheckDate": null
			// }]);
			// this.getView().setModel(oModel, "local");

			this.HeaderAPI();
			this.FeeDetails();
		},
		FeeDetails: function() {
			var that = this;
			var FinalAmt = 0;
			var oModel = new JSONModel();
			this.getView().setModel(oModel);
			sap.ui.core.BusyIndicator.show();
			that._oModel.read("/FeeDueDetailsSet", {
				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();
					if(oData.results.length===0){
							that.getView().getModel('olocal').setProperty("/NewApply", false);
					}
					else{
					oModel.setData(oData.results);
					that.getView().setModel(oModel, "FeeDetails");
					oData.results.forEach(function(Ele) {
						FinalAmt = FinalAmt + parseFloat(Ele.Amount);

					});
					var fAmount = FinalAmt / 3;
					//	this.getView().getModel("local").refresh(true);
					that.getView().getModel('olocal').setProperty("/fAmount", fAmount);
					that.getView().getModel('olocal').setProperty("/FinalAmt", FinalAmt);
                       that.CheckDetails();
					}
				},
				
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					MessageBox.error(oMessage.error.message.value);

				}
				
			});

		},
		statusText: function(oVal) {
			if (oVal == "04") {
				return "Modified";
			} else if (oVal == "01") {
				return "Applied";
			} else if (oVal == "02") {
				return "Approved";

			} else if (oVal == "03") {
				return "Rejected";

			}
			else if (oVal == ""){
			return 	"Not Applied";
			}
			

		},
	
		HeaderAPI: function() {
			var that = this;
			var oModel = new JSONModel();
			this.getView().setModel(oModel);
			sap.ui.core.BusyIndicator.show();
			that._oModel.read("/StudentHeaderSet", {
				success: function(oData) {
					
					sap.ui.core.BusyIndicator.hide();
					if(oData.results.length ===0){
						that.getView().getModel('olocal').setProperty("/NewApply", false);
                      	that.getView().getModel('olocal').setProperty("/Modifyrecord", false);
                      	that.getView().getModel('olocal').setProperty("/ViewRecords", false);
                      		MessageBox.error("No records found");
                      		
                      	
					}
					else{
					oModel.setData(oData.results[0]);
					that.getView().setModel(oModel, "StudentDetails");
					
					
                       if(oData.results[0].Status===""||oData.results[0].Status==="03"){
                       	that.getView().getModel('olocal').setProperty("/NewApply", true);
                      	that.getView().getModel('olocal').setProperty("/Modifyrecord", false);
                      	that.getView().getModel('olocal').setProperty("/ViewRecords", false);

                       }
                          else if(oData.results[0].Status==="01"||oData.results[0].Status==="02"){
                          	    	that.getView().getModel('olocal').setProperty("/NewApply", false);
                      	that.getView().getModel('olocal').setProperty("/Modifyrecord", false);
                      	that.getView().getModel('olocal').setProperty("/ViewRecords", true);

                          }
                           else if(oData.results[0].Status==="04"){
                          	    	that.getView().getModel('olocal').setProperty("/NewApply", false);
                      	that.getView().getModel('olocal').setProperty("/Modifyrecord", true);
                      	that.getView().getModel('olocal').setProperty("/ViewRecords", false);

                          }
                          
					} 

				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					MessageBox.error(oMessage.error.message.value);

				}
			});

		},
			CheckDetails: function() {
			var that = this;
			var oStdobjid=this.getView().getModel("StudentDetails").getProperty("/ST_OBJID");
			var oModel = new JSONModel();
			this.getView().setModel(oModel);
			sap.ui.core.BusyIndicator.show();
			var oPath = this.getOwnerComponent().getModel().createKey("/ChequeDetSet", {
				"StudentObjid": oStdobjid
			});

			this.getOwnerComponent().getModel().read(oPath, {
				success: function(oData) {
					sap.ui.core.BusyIndicator.hide();
					oModel.setData(oData);
					that.getView().setModel(oModel, "CheckDetails");

				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					MessageBox.error(oMessage.error.message.value);

				}
			});

		},
	
		onCheckNumber: function(oEvent) {
			var oVal = oEvent.getParameter('value');
			if (oVal.length !== 6) {
				MessageBox.error("check number Should contains 6 Numbers only");
				oEvent.getSource().setValueState("Error");
			} else {
				oEvent.getSource().setValueState("None");

			}

		},
		onFlexiPayment: function() {      
			this.getView().byId("idButton").setEnabled(false);
			this.getView().byId("idTable").setVisible(true);
			this.getView().byId("idSaveButton").setVisible(true);
			this.getView().byId("idSaveButton").setVisible(true);
			this.seconddate = "";
			this.thirddate = "";
			var fAmount = this.getView().getModel('olocal').getProperty("/fAmount");
			var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2
					// minFractionDigits:2
			});
			// var oFloatFormat = NumberFormat.getFloatInstance(oFormatOptions);
			fAmount = numberFormat.format(fAmount);
			// this.getView().getModel('local').setProperty("/Amount",fAmount);

			var oModel = new JSONModel([{
				"Date": null,
				"Amount": fAmount,
				"PaymentNo": "1",
				"CheckNumber": "",
				"CheckDate": null

			}, {

				"Date": this.seconddate,
				"Amount": fAmount,
				"PaymentNo": "2",
				"CheckNumber": "",
				"CheckDate": null
			}, {
				"Date": this.thirddate,
				"Amount": fAmount,
				"PaymentNo": "3",
				"CheckNumber": "",
				"CheckDate": null
			}]);
			this.getView().setModel(oModel, "local");
		},
		OnModifyFlexipayment:function(){
						this.getView().byId("idButton2").setEnabled(false);
						this.getView().byId("idEditTable").setVisible(true);
			this.getView().byId("idEdit").setVisible(true);
			this.seconddate = "";
			this.thirddate = "";
			var oEditDataObj= this.getView().getModel('CheckDetails').getProperty("/");

			var fAmount = this.getView().getModel('olocal').getProperty("/fAmount");
			var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2
					// minFractionDigits:2
			});
  

   //if(oEditDataObj.PAYMENT_AMT3!=="0.0" && oEditDataObj.PAYMENT_AMT4==="0.0"){
			var oModel = new JSONModel([{
				"Date": oEditDataObj.PAYMENT_AMT_DATE1,
				"Amount": oEditDataObj.PAYMENT_AMT1,
				"CheckNumber":oEditDataObj.CHEQUE_NO1,
				"CheckDate": oEditDataObj.VALUE_DATE1

			}, {

				"Date": oEditDataObj.PAYMENT_AMT_DATE2,
				"Amount": oEditDataObj.PAYMENT_AMT2,
				"CheckNumber":oEditDataObj.CHEQUE_NO2,
				"CheckDate": oEditDataObj.VALUE_DATE2
			}, {
					"Date": oEditDataObj.PAYMENT_AMT_DATE3,
				"Amount": oEditDataObj.PAYMENT_AMT3,
				"CheckNumber":oEditDataObj.CHEQUE_NO3,
				"CheckDate": oEditDataObj.VALUE_DATE3
			}]);
			this.getView().setModel(oModel, "Editlocal");
	//	}
	var oPDate=this.getView().getModel("Editlocal").getProperty("/")[2].Date;
	var tDate=oPDate;
	var fDate=oPDate;
	var ofourthdate = new Date(tDate.getFullYear(), tDate.getMonth() + 1, tDate.getDate());
	var oFifthdate = new Date(fDate.getFullYear(), fDate.getMonth() + 2, fDate.getDate());

		if(oEditDataObj.PAYMENT_AMT4!=="0.0" && oEditDataObj.PAYMENT_AMT5==="0.0"){
	var oModel = new JSONModel([{
				"Date": oEditDataObj.PAYMENT_AMT_DATE1,
				"Amount": oEditDataObj.PAYMENT_AMT1,
				"CheckNumber":oEditDataObj.CHEQUE_NO1,
				"CheckDate": oEditDataObj.VALUE_DATE1

			}, {

				"Date": oEditDataObj.PAYMENT_AMT_DATE2,
				"Amount": oEditDataObj.PAYMENT_AMT2,
				"CheckNumber":oEditDataObj.CHEQUE_NO2,
				"CheckDate": oEditDataObj.VALUE_DATE2
			}, {
					"Date": oEditDataObj.PAYMENT_AMT_DATE3,
				"Amount": oEditDataObj.PAYMENT_AMT3,
				"CheckNumber":oEditDataObj.CHEQUE_NO3,
				"CheckDate": oEditDataObj.VALUE_DATE3
			},
			{
			"Date": ofourthdate,
				"Amount": oEditDataObj.PAYMENT_AMT4,
				"CheckNumber":oEditDataObj.CHEQUE_NO4,
				"CheckDate": oEditDataObj.VALUE_DATE4
			}
			]);
			
						this.getView().setModel(oModel, "Editlocal");

		}
		 if(oEditDataObj.PAYMENT_AMT5!=="0.0"){
   	
   		var oModel = new JSONModel([{
				"Date": oEditDataObj.PAYMENT_AMT_DATE1,
				"Amount": oEditDataObj.PAYMENT_AMT1,
				"CheckNumber":oEditDataObj.CHEQUE_NO1,
				"CheckDate": oEditDataObj.VALUE_DATE1

			}, {

				"Date": new Date(oEditDataObj.PAYMENT_AMT_DATE2),
				"Amount": oEditDataObj.PAYMENT_AMT2,
				"CheckNumber":oEditDataObj.CHEQUE_NO2,
				"CheckDate": oEditDataObj.VALUE_DATE2
			}, {
					"Date": oEditDataObj.PAYMENT_AMT_DATE3,
				"Amount": oEditDataObj.PAYMENT_AMT3,
				"CheckNumber":oEditDataObj.CHEQUE_NO3,
				"CheckDate": oEditDataObj.VALUE_DATE3
			},{
					"Date": ofourthdate,
				"Amount": oEditDataObj.PAYMENT_AMT4,
				"CheckNumber":oEditDataObj.CHEQUE_NO4,
				"CheckDate": oEditDataObj.VALUE_DATE4
			},{
					"Date":oFifthdate,
				"Amount": oEditDataObj.PAYMENT_AMT5,
				"CheckNumber":oEditDataObj.CHEQUE_NO5,
				"CheckDate": oEditDataObj.VALUE_DATE5
			}
			]);
			this.getView().setModel(oModel, "Editlocal");

}
		},
			OnShowFlexipayment: function() {
			this.getView().byId("idViewTable").setVisible(true);
									this.getView().byId("idButton1").setEnabled(false);

			// this.seconddate = "";
			// this.thirddate = "";
		var oShowDataObj= this.getView().getModel('CheckDetails').getProperty("/");
			// var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
			// 	maxFractionDigits: 2
			// 		minFractionDigits:2
			// });

			var oModel = new JSONModel([{
				"Date": oShowDataObj.PAYMENT_AMT_DATE1,
				"Amount": oShowDataObj.PAYMENT_AMT1,
				"CheckNumber":oShowDataObj.CHEQUE_NO1,
				"CheckDate": oShowDataObj.VALUE_DATE1

			}, {

				"Date": oShowDataObj.PAYMENT_AMT_DATE2,
				"Amount": oShowDataObj.PAYMENT_AMT2,
				"CheckNumber":oShowDataObj.CHEQUE_NO2,
				"CheckDate": oShowDataObj.VALUE_DATE2
			}, {
					"Date": oShowDataObj.PAYMENT_AMT_DATE3,
				"Amount": oShowDataObj.PAYMENT_AMT3,
				"CheckNumber":oShowDataObj.CHEQUE_NO3,
				"CheckDate": oShowDataObj.VALUE_DATE3
			}]);
			this.getView().setModel(oModel, "Showlocal");
		},

//this.getview().getModel('Showlocal')
		handleChange: function(oEvent) {
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var fAmount = this.getView().getModel('olocal').getProperty("/fAmount");
			var numberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2
					// minFractionDigits:2
			});
			// var oFloatFormat = NumberFormat.getFloatInstance(oFormatOptions);
			fAmount = numberFormat.format(fAmount);
			var oTableObj = oEvent.getSource().getParent().getBindingContext("local").getObject();
			if (oTableObj.PaymentNo === "1") {
				var oDate = oTableObj.Date;
				var aDate = oDate;
				var sDate = oDate;
				var Month = oDate.getMonth();
				var oFirstdate = new Date(sDate.getFullYear(), sDate.getMonth() + 1, sDate.getDate());
				var oSecondDate = new Date(aDate.getFullYear(), aDate.getMonth() + 2, aDate.getDate());
				this.getView().getModel("local").setProperty("/0/Date", oDate);
				this.getView().getModel("local").setProperty("/1/Date", oFirstdate);
				this.getView().getModel("local").setProperty("/2/Date", oSecondDate);
				this.getView().getModel("local").refresh(true);
				// var oModel = new JSONModel([{
				// 	"Date": oDate,
				// 	"Amount": fAmount,
				// 	"PaymentNo": "1",
				// 	"CheckNumber": "",
				// 	"CheckDate": null

				// }, {

				// 	"Date": oFirstdate,
				// 	"Amount": fAmount,
				// 	"PaymentNo": "2",
				// 	"CheckNumber": "",
				// 	"CheckDate": null
				// }, {
				// 	"Date": oSecondDate,
				// 	"Amount": fAmount,
				// 	"PaymentNo": "3",
				// 	"CheckNumber": "",
				// 	"CheckDate": null
				// }]);
				// this.getView().setModel(oModel, "local");
				this.getView().getModel("olocal").setProperty("/date", "1");

			}
		},
_State:function(oVal){
			if(oVal==="02" ){
				return "Success";
			}	
				else if(oVal==="01" ||  oVal==="04" ){
				return "Warning";
			}
			else if(oVal==="03" ){
				return "Error";
			}else{
							return "Warning";
	
			}
		},
		UploadDoc: function(oEvt) {
			// console.log(oEvt);
			var oIdx = oEvt.getSource().getParent().getBindingContext("local").sPath.split('/')[1];
			var reader = new FileReader();
			var afile = oEvt.getParameter("files")[0];
			reader.onload = function(e) {
				if (oIdx === '0') {
					this.firstDoc = e.target.result;
				} else if (oIdx === '1') {
					this.secondDoc = e.target.result;
				} else if (oIdx === '2') {
					this.thirdDoc = e.target.result;
				}

			};
			reader.onerror = function(e) {
				sap.m.MessageToast.show("error");
			};
			reader.readAsBinaryString(afile);

		},
		onsave: function() {
			var oflag = false;
			var that = this;
			var aflag = false;
			var FinalAmt = this.getView().getModel('olocal').getProperty("/FinalAmt");

			var oObj = this.getView().getModel("local").getProperty("/");
			var oDecimalType = new sap.ui.model.odata.type.Decimal();
			oObj.forEach(function(Ele) {
				  if(Ele.CheckNumber===''){
					oflag=true;
				}
				if(Ele.checkDate==='' || Ele.checkDate===null){
					aflag=true;
				}
			});
			if (oflag) {
				MessageBox.error("Please Enter Check Details");
				return true;
			}
			if (aflag) {
				MessageBox.error("Please Enter Check Details");
				return true;

			}
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var oAmt = oObj[0].Amount;
			var paymentAmount = oDecimalType.parseValue(oAmt, "string");
			var wPayload = {};

			wPayload.StudentObjid = this.getView().getModel("StudentDetails").getData().ST_OBJID;
			wPayload.Zprogram = this.getView().getModel("StudentDetails").getData().SC_OBJID;
			wPayload.Zyear = this.getView().getModel("StudentDetails").getData().PERYR;
			wPayload.Zsession = this.getView().getModel("StudentDetails").getData().PERID;
			wPayload.Zstage = this.getView().getModel("StudentDetails").getData().ACLEVEL;
			wPayload.CHEQUE_NO1 = oObj[0].CheckNumber;
			// wPayload.VALUE_DATE1 = dateFormat.format(oObj[0].CheckDate);
			wPayload.VALUE_DATE1 = oObj[0].CheckDate;
			wPayload.PAYMENT_AMT1 = paymentAmount;
			
			wPayload.CHEQUE_NO2 = oObj[1].CheckNumber;
			// wPayload.VALUE_DATE2 = dateFormat.format(oObj[1].CheckDate);
				wPayload.VALUE_DATE2 = oObj[1].CheckDate;
			wPayload.PAYMENT_AMT2 = paymentAmount;
			wPayload.CHEQUE_NO3 = oObj[2].CheckNumber;
			// wPayload.VALUE_DATE3 = dateFormat.format(oObj[2].CheckDate);
				wPayload.VALUE_DATE3 = oObj[2].CheckDate;
			wPayload.PAYMENT_AMT3 = paymentAmount;
			// wPayload.PAYMENT_AMT_DATE1 = dateFormat.format(oObj[0].Date);
				wPayload.PAYMENT_AMT_DATE1 = oObj[0].Date;
			
			// wPayload.PAYMENT_AMT_DATE2 = dateFormat.format(oObj[1].Date);
			wPayload.PAYMENT_AMT_DATE2 = oObj[1].Date;
			// wPayload.PAYMENT_AMT_DATE3 = dateFormat.format(oObj[2].Date);
			wPayload.PAYMENT_AMT_DATE3 = oObj[2].Date;
			wPayload.STATUS = '01';
			wPayload.AMOUNT = FinalAmt.toString();

			var drawModel = this.getOwnerComponent().getModel();
			sap.ui.core.BusyIndicator.show();
			drawModel.create("/ChequeDetSet", wPayload, {
				success: function(oData) {

					// if (oData.SucessFlag === true) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.success("Saved successfully!", {
						actions: [MessageBox.Action.OK],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function(oAction) {
							//	that.getHistory();
							that.HeaderAPI();
							that.FeeDetails();
							that.getView().getModel('local').setProperty("/", []);
							that.getView().byId("idTable").setVisible(false);
							that.getView().byId("idSaveButton").setVisible(false);

						}

					});

					// } else {
					// 	MessageBox.error("Some error occured!");

					// }

				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					MessageBox.error(oMessage.error.message.value);
				}
			});

		},
		OnEdit:function(){
				var oflag = false;
			var that = this;
			var aflag = false;
		//	var FinalAmt = this.getView().getModel('olocal').getProperty("/FinalAmt");
			var oTotalAmt = this.getView().getModel("CheckDetails").getProperty("/AMOUNT");

			var oObj = this.getView().getModel("Editlocal").getProperty("/");
			var oDecimalType = new sap.ui.model.odata.type.Decimal();
			oObj.forEach(function(Ele) {
				  if(Ele.CheckNumber===''){
					oflag=true;
				}
				if(Ele.checkDate==='' || Ele.checkDate===null){
					aflag=true;
				}
			});
			if (oflag) {
				MessageBox.error("Please Enter Check Details");
				return true;
			}
			if (aflag) {
				MessageBox.error("Please Enter Check Details");
				return true;

			}
			var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyyMMdd"
			});
			var oAmt = oObj[0].Amount;
			var paymentAmount = oDecimalType.parseValue(oAmt, "string");
			var wPayload = {};
            wPayload.AMOUNT=oTotalAmt;
			wPayload.StudentObjid = this.getView().getModel("StudentDetails").getData().ST_OBJID;
			wPayload.Zprogram = this.getView().getModel("StudentDetails").getData().SC_OBJID;
			wPayload.Zyear = this.getView().getModel("StudentDetails").getData().PERYR;
			wPayload.Zsession = this.getView().getModel("StudentDetails").getData().PERID;
			wPayload.Zstage = this.getView().getModel("StudentDetails").getData().ACLEVEL;
			wPayload.CHEQUE_NO1 = oObj[0].CheckNumber;
			wPayload.VALUE_DATE1 = oObj[0].CheckDate;
			wPayload.PAYMENT_AMT1 =oObj[0].Amount;
			wPayload.CHEQUE_NO2 = oObj[1].CheckNumber;
			wPayload.VALUE_DATE2 = oObj[1].CheckDate;
			wPayload.PAYMENT_AMT2 = oObj[1].Amount;
			wPayload.CHEQUE_NO3 = oObj[2].CheckNumber;
			wPayload.VALUE_DATE3 = oObj[2].CheckDate;
			wPayload.PAYMENT_AMT3 =oObj[2].Amount;
			wPayload.PAYMENT_AMT_DATE1 = oObj[0].Date;
			wPayload.PAYMENT_AMT_DATE2 = oObj[1].Date;
			wPayload.PAYMENT_AMT_DATE3 = oObj[2].Date;
			wPayload.STATUS = '01';
			if(oObj.PAYMENT_AMT4!==undefined && oObj.PAYMENT_AMT5===undefined){
			wPayload.PAYMENT_AMT_DATE4 = dateFormat.format(oObj[3].Date);
			wPayload.CHEQUE_NO4 = oObj[3].CheckNumber;
           	wPayload.PAYMENT_AMT2 = oObj[3].Amount;
			wPayload.VALUE_DATE2 = dateFormat.format(oObj[3].CheckDate);
			}
			if(oObj.PAYMENT_AMT5!==undefined){
			wPayload.PAYMENT_AMT_DATE4 = dateFormat.format(oObj[3].Date);
			wPayload.CHEQUE_NO4 = oObj[3].CheckNumber;
           	wPayload.PAYMENT_AMT2 = oObj[3].Amount;
			wPayload.VALUE_DATE2 = dateFormat.format(oObj[3].CheckDate);

				wPayload.PAYMENT_AMT_DATE5 = dateFormat.format(oObj[4].Date);
			wPayload.CHEQUE_NO5 = oObj[4].CheckNumber;
           	wPayload.PAYMENT_AMT5 = oObj[4].Amount;
			wPayload.VALUE_DATE5 = dateFormat.format(oObj[4].CheckDate);

			}
		//	wPayload.AMOUNT = FinalAmt.toString();

			var drawModel = this.getOwnerComponent().getModel();
			sap.ui.core.BusyIndicator.show();
			drawModel.create("/ChequeDetSet", wPayload, {
				success: function(oData) {

					// if (oData.SucessFlag === true) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.success("Saved successfully!", {
						actions: [MessageBox.Action.OK],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function(oAction) {
							//	that.getHistory();
							that.HeaderAPI();
							that.FeeDetails();
							that.getView().getModel('Editlocal').setProperty("/", []);
							that.getView().byId("idEdit").setVisible(false);
						//	that.getView().byId("idSaveButton").setVisible(false);
								that.getView().byId("idEditTable").setVisible(false);

						

						}

					});

					// } else {
					// 	MessageBox.error("Some error occured!");

					// }

				},
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					var oMessage = JSON.parse(oError.responseText);
					MessageBox.error(oMessage.error.message.value);
				}
			});

		},

		onDelete: function(oEvent) {
			var data = this.getView().getModel("local").getData(),
				deleteItem = oEvent.getParameter("listItem").getBindingContextPath().substring(1);
			data.splice(deleteItem, 1);
			this.getView().getModel("local").refresh();
			var oModel = new sap.ui.model.json.JSONModel(data);
			this.getView().setModel(oModel, "local");
		}

	});
});