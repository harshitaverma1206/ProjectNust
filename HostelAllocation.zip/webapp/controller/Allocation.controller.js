sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function(Controller, StandardListItem, CustomData, Filter, FilterOperator, JSONMODEL ) {
	"use strict";

	return Controller.extend("HostelAllocation.controller.Allocation", {
			onInit: function() {
		

		},
			_codeValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelAllocation.fragments.CodeValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onCodeValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "codeODataModel>/ZIPMPLANTVH",
				"entityProperties": {
					title: "{path:'codeODataModel>Plant',templateSharable:true}",
					description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "Plant",
					"value": ""
				}
			};
			this._codeValueHelpDialog(sBindingObj, null);

		},

		onDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},
		
		
			_locValueHelpDialog: function(sBindingObj1, oDialogName1, filters1, stockType1) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1 = sap.ui.xmlfragment("HostelAllocation.fragments.LocationValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog1);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog1);
			}
			if (this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1.setTitle(sBindingObj1.oDialogTitle1);
				this._oAllValueHelpDialog1.destroyItems();
				this._oAllValueHelpDialog1.destroyCustomData();
				this._sBindingValueHelpPath1 = sBindingObj1.entityPath;
				this._oAllValueHelpDialog1.bindAggregation("items", {
					path: sBindingObj1.entityPath,
					templateSharable: false,
					filters: filters1,
					template: new StandardListItem(sBindingObj1.entityProperties)
				});
				this._oAllValueHelpDialog1.addCustomData(new CustomData({
					key: sBindingObj1.customData.key,
					value: sBindingObj1.customData.value
				}));
			}

			this._oAllValueHelpDialog1.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog1;
		},

		_filters: function(sFiltersObject, conditionalFlag) {
			var arrayFilters = [],
				aFilters;
			sFiltersObject.forEach(function(element, index) {
				var operator = FilterOperator[element.filterOperator] ? FilterOperator[element.filterOperator] : FilterOperator.Contains;
				arrayFilters.push(new Filter(element.sPath, operator, element.sValue));
				//	arrayFilters.push(new Filter(element.sPath, FilterOperator.EQ, element.sValue));
			});
			aFilters = new Filter({
				filters: arrayFilters,
				and: conditionalFlag
			});
			return aFilters;
		},

		onLocationValueHelpRequest: function(OEvent) {
			//         this._filterRequired = true;

			// // var fragmentName = "PlantValueHelpDialog", // fragemntName from fragments folders
			// var filtersObject;
			var sBindingObj1 = {
				"entityPath": "codeODataModel>/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'codeODataModel>FunctionalLocation',templateSharable:true}",
					description: "{path:'codeODataModel>FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			//var sPlant = this.getView().getModel("LocalDataModel").getProperty("/filters/Plant"),
			this._locValueHelpDialog(sBindingObj1, null);
			// 	filtersObject = [{
			// 	"sPath": "Plant",
			// 	"sValue": sPlant,
			// 	"filterOperator": "EQ"
			// }];
			// this._filtersArrayObject = this._filters(filtersObject, true);
			// this._locValueHelpDialog(sBindingObj1, null, this._filtersArrayObject);

		},

		onLocDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In6").setValue(sTitle);

		},
		
		
			_roomValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelAllocation.fragments.RoomValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog2);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
			}
			if (this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
				this._oAllValueHelpDialog2.destroyItems();
				this._oAllValueHelpDialog2.destroyCustomData();
				this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
				this._oAllValueHelpDialog2.bindAggregation("items", {
					path: sBindingObj2.entityPath,
					templateSharable: false,
					filters: filters2,
					template: new StandardListItem(sBindingObj2.entityProperties)
				});
				this._oAllValueHelpDialog2.addCustomData(new CustomData({
					key: sBindingObj2.customData.key,
					value: sBindingObj2.customData.value
				}));
			}

			this._oAllValueHelpDialog2.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog2;
		},

		onRoomValueHelpRequest: function(OEvent) {

			var sBindingObj2 = {
				"entityPath": "codeODataModel>/ZIROOMTYPEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>DomainDescription',templateSharable:true}",
					description: "{path:'codeODataModel>DomainValue',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._roomValueHelpDialog(sBindingObj2, null);

		},

		onRoomDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},
		
		
			_priorValueHelpDialog: function(sBindingObj3, oDialogName3, filters3, stockType3) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3 = sap.ui.xmlfragment("HostelAllocation.fragments.PriorityValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog3);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog3);
			}
			if (this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3.setTitle(sBindingObj3.oDialogTitle1);
				this._oAllValueHelpDialog3.destroyItems();
				this._oAllValueHelpDialog3.destroyCustomData();
				this._sBindingValueHelpPath3 = sBindingObj3.entityPath;
				this._oAllValueHelpDialog3.bindAggregation("items", {
					path: sBindingObj3.entityPath,
					templateSharable: false,
					filters: filters3,
					template: new StandardListItem(sBindingObj3.entityProperties)
				});
				this._oAllValueHelpDialog3.addCustomData(new CustomData({
					key: sBindingObj3.customData.key,
					value: sBindingObj3.customData.value
				}));
			}

			this._oAllValueHelpDialog3.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog3;
		},

		onPriorValueHelpRequest: function(OEvent) {

			var sBindingObj3 = {
				"entityPath": "codeODataModel>/ZIROOMTYPEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>DomainDescription',templateSharable:true}",
					description: "{path:'codeODataModel>DomainValue',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._priorValueHelpDialog(sBindingObj3, null);

		},

		onPriorDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In9").setValue(sTitle);

		},
		
			_systemValueHelpDialog: function(sBindingObj4, oDialogName4, filters4, stockType4) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4 = sap.ui.xmlfragment("HostelAllocation.fragments.SystemValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog4);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog4);
			}
			if (this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4.setTitle(sBindingObj4.oDialogTitle1);
				this._oAllValueHelpDialog4.destroyItems();
				this._oAllValueHelpDialog4.destroyCustomData();
				this._sBindingValueHelpPath4 = sBindingObj4.entityPath;
				this._oAllValueHelpDialog4.bindAggregation("items", {
					path: sBindingObj4.entityPath,
					templateSharable: false,
					filters: filters4,
					template: new StandardListItem(sBindingObj4.entityProperties)
				});
				this._oAllValueHelpDialog4.addCustomData(new CustomData({
					key: sBindingObj4.customData.key,
					value: sBindingObj4.customData.value
				}));
			}

			this._oAllValueHelpDialog4.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog4;
		},

		onSystemValueHelpRequest: function(OEvent) {

			var sBindingObj4 = {
				"entityPath": "codeODataModel>/ZISYSTEMSTATUSVH",
				"entityProperties": {
					title: "{path:'codeODataModel>StatusKey',templateSharable:true}",
					description: "{path:'codeODataModel>FinalStatus',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._systemValueHelpDialog(sBindingObj4, null);

		},

		onSystemDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In5").setValue(sTitle);

		},
		
		
		
			_reportValueHelpDialog: function(sBindingObj5, oDialogName5, filters5, stockType5) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5 = sap.ui.xmlfragment("HostelAllocation.fragments.ReportedByValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog5);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5.setTitle(sBindingObj5.oDialogTitle5);
				this._oAllValueHelpDialog5.destroyItems();
				this._oAllValueHelpDialog5.destroyCustomData();
				this._sBindingValueHelpPath5 = sBindingObj5.entityPath;
				this._oAllValueHelpDialog5.bindAggregation("items", {
					path: sBindingObj5.entityPath,
					templateSharable: false,
					filters: filters5,
					template: new StandardListItem(sBindingObj5.entityProperties)
				});
				this._oAllValueHelpDialog5.addCustomData(new CustomData({
					key: sBindingObj5.customData.key,
					value: sBindingObj5.customData.value
				}));
			}

			this._oAllValueHelpDialog5.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog5;
		},

		onReportValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "codeODataModel>/ZIPMPRIORITYVH",
				"entityProperties": {
					title: "{path:'codeODataModel>MaintPriorityDesc',templateSharable:true}",
					description: "{path:'codeODataModel>MaintPriority',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "UserName",
					"value": ""
				}
			};
			this._reportValueHelpDialog(sBindingObj5, null);

		},

		onReportDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In10").setValue(sTitle);

		},
		
			_RequestNumValueHelpDialog: function(sBindingObj10, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._NumValueHelpDialog) {
				this._NumValueHelpDialog = sap.ui.xmlfragment("HostelAllocation.fragments.RequestNum", this);
				this.getView().addDependent(this._NumValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._NumValueHelpDialog) {
				this._NumValueHelpDialog.setTitle(sBindingObj10.oDialogTitle);
				this._NumValueHelpDialog.destroyItems();
				this._NumValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj10.entityPath;
				this._NumValueHelpDialog.bindAggregation("items", {
					path: sBindingObj10.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj10.entityProperties)
				});
				this._NumValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj10.customData.key,
					value: sBindingObj10.customData.value
				}));
			}

			this._NumValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._NumValueHelpDialog;
		},

		onRequestNumValueHelp: function(OEvent) {

			var sBindingObj10 = {
				"entityPath": "codeODataModel>/NotificationNoSet",
				"entityProperties": {
					title: "{path:'codeODataModel>NotifNo',templateSharable:true}"
					// description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._RequestNumValueHelpDialog(sBindingObj10, null);

		},
	    onNumDialogClose: function(oEvent) {

			var sTitle10 = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In7").setValue(sTitle10);

		},
		
		
			_ReportNumValueHelpDialog: function(sBindingObj10, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._NumValueHelpDialog) {
				this._NumValueHelpDialog = sap.ui.xmlfragment("HostelAllocation.fragments.Report", this);
				this.getView().addDependent(this._NumValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._NumValueHelpDialog) {
				this._NumValueHelpDialog.setTitle(sBindingObj10.oDialogTitle);
				this._NumValueHelpDialog.destroyItems();
				this._NumValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj10.entityPath;
				this._NumValueHelpDialog.bindAggregation("items", {
					path: sBindingObj10.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj10.entityProperties)
				});
				this._NumValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj10.customData.key,
					value: sBindingObj10.customData.value
				}));
			}

			this._NumValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._NumValueHelpDialog;
		},

		onReport2NumValueHelp: function(OEvent) {

			var sBindingObj10 = {
				"entityPath": "codeODataModel>/ZIPMUSERNAMEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>UserName',templateSharable:true}"
					// description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "UserName",
					"value": ""
				}
			};
			this._ReportNumValueHelpDialog(sBindingObj10, null);

		},
	    onReport2DialogClose: function(oEvent) {

			var sTitle10 = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In1").setValue(sTitle10);

		},
		
		
		_TypeValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelAllocation.fragments.Type", this);
				this.getView().addDependent(this._oAllValueHelpDialog2);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
			}
			if (this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
				this._oAllValueHelpDialog2.destroyItems();
				this._oAllValueHelpDialog2.destroyCustomData();
				this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
				this._oAllValueHelpDialog2.bindAggregation("items", {
					path: sBindingObj2.entityPath,
					templateSharable: false,
					filters: filters2,
					template: new StandardListItem(sBindingObj2.entityProperties)
				});
				this._oAllValueHelpDialog2.addCustomData(new CustomData({
					key: sBindingObj2.customData.key,
					value: sBindingObj2.customData.value
				}));
			}

			this._oAllValueHelpDialog2.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog2;
		},

		onTypeValueHelpRequest: function(OEvent) {

			var sBindingObj2 = {
				"entityPath": "codeODataModel>/ZIPMNOTIFICATIONSVH",
				"entityProperties": {
					title: "{path:'codeODataModel>NotificationType',templateSharable:true}"
					// description: "{path:'codeODataModel>DomainValue',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotificationType",
					"value": ""
				}
			};
			this._TypeValueHelpDialog(sBindingObj2, null);

		},

	onTypeDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In8").setValue(sTitle);

		},
		
		onGo:function(){
			var oTable = this.getView().byId("HostelAllocation");
			var selectedValue = this.byId("In3").getValue();
			var selectedValue1 = this.byId("In1").getValue();
			// var selectedValue2 = this.byId("In4").getValue();
			// // var selectedValue3 = this.byId("In3").getValue();
			var selectedValue4 = this.byId("In6").getValue();
			var selectedValue5 = this.byId("In5").getValue();
			var selectedValue6 = this.byId("In10").getValue();
			var selectedValue7 = this.byId("In7").getValue();
			var selectedValue8 = this.byId("In8").getValue();
			var selectedValue9 = this.byId("In9").getValue();

			var aFilters = [];

			// Construct filters
			if (selectedValue) {
			aFilters.push(new sap.ui.model.Filter("CollegeCode", sap.ui.model.FilterOperator.EQ, selectedValue));
			}

			if (selectedValue1) {
				aFilters.push( new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue1));
			}

			if (selectedValue4) {
			aFilters.push(new sap.ui.model.Filter("CurrentLocation", sap.ui.model.FilterOperator.EQ, selectedValue4));
			}
		
			
			if (selectedValue8) {
			aFilters.push(new sap.ui.model.Filter("NotificationType", sap.ui.model.FilterOperator.EQ, selectedValue8));
			}
			
			if (selectedValue5) {
			aFilters.push(new sap.ui.model.Filter("SystemStatus", sap.ui.model.FilterOperator.EQ, selectedValue5));
			}
				if (selectedValue6) {
			aFilters.push(new sap.ui.model.Filter("PriorityText", sap.ui.model.FilterOperator.EQ, selectedValue6));
			}
			if (selectedValue7) {
			aFilters.push(new sap.ui.model.Filter("Notification", sap.ui.model.FilterOperator.EQ, selectedValue7));
			}
				if (selectedValue9) {
			aFilters.push(new sap.ui.model.Filter("RoomType", sap.ui.model.FilterOperator.EQ, selectedValue9));
			}
			
			

			// Apply filters to the table binding
			oTable.getBinding("items").filter(aFilters);

		

		},
		
		onTableSelectionChange: function(oEvent){
			    // var oSelectedItem = oEvent.getParameter("listItem");
       //     var oSelectedContext = oSelectedItem.getBindingContext("codeODataModel");
       //     var oSelectedData = oSelectedContext.getObject();
 
       //     var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
       //     oRouter.navTo("AllocationData", {
       //         selectedData: JSON.stringify(oSelectedData) // Pass the selected data to the second page
       //     });
       var oSelectedItem = oEvent.getParameter("listItem");
    var oBindingContext = oSelectedItem.getBindingContext("codeODataModel");
    // var oModelData1 = oBindingContext.getProperty().CollegeCode; // This will give you the data of the selected row
    //  var oModelData2 = oBindingContext.getProperty().CurrentLocation; 
    //  var oModelData3 = oBindingContext.getProperty().DateTime; 
     //var oModelData4 = oBindingContext.getProperty().PriorityText; 
    //  var oModelData5 = oBindingContext.getProperty().Description; 
    //  var oModelData6 = oBindingContext.getProperty().ReportedBy; 
    //  var oModelData7 = oBindingContext.getProperty().SystemStatus; 
    //  var oModelData8 = oBindingContext.getProperty().Notification; 
       var oModelData = oBindingContext.getProperty(); // This will give you the data of the selected row
     
     
    
    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    oRouter.navTo("AllocationData", {
        param1: oModelData.Notification,
         //param2: oModelData.CurrentLocation
         
           //param2: oModelData.ReportedBy,
           //param3: oModelData.DateTime
          //  param5: oModelData5, 
          //   param6: oModelData6, 
          //    param7: oModelData7,
          //    param8: oModelData8
        // Add more parameters as needed
    });
        
        }
			
			
			
			 //var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
    //         oRouter.navTo("AllocationData");
		

	});
});