sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/StandardListItem",
	"sap/ui/core/CustomData",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(Controller, StandardListItem, CustomData, Filter, FilterOperator, JSONMODEL, MessageBox ) {
	"use strict";

	return Controller.extend("HostelAllocation.controller.AllocationData", {
			onInit: function() {
				
				   //var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
       //     oRouter.getRoute("AllocationData").attachMatched(this._onRouteMatched, this);
            
         var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("AllocationData").attachPatternMatched(this._onRouteMatched, this);
		  

		},
		 _onRouteMatched: function(oEvent) {
            var oArgs = oEvent.getParameter("arguments");
            this.param1 = oArgs.param1;
            
            
            var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/SAP/ZSL_HOSTEL_FAC_ALLOCATION_SRV/");
			var oView = this.getView();
			var entityId = this.param1;
			oModel.read("/CreateNotificationSet('" + entityId + "')", {

				success: function(oData) {
					// Handle successful data retrieval
				// MessageBox.show("this is "+ oData);

					var defaultId = oData.RoomType;
					this.getView().byId("room1").setValue(defaultId);

					var defaultIdCollege = oData.CollegeCode;
					this.getView().byId("label1").setValue(defaultIdCollege);

					var defaultIdRequest = oData.RequestType;
					this.getView().byId("label2").setValue(defaultIdRequest);

					var defaultIdDate = oData.RequestDate;
					this.getView().byId("date1").setValue(defaultIdDate);

					var defaultIdDis = oData.Description;
					this.getView().byId("dis").setValue(defaultIdDis);

					var defaultIdPrior = oData.Priority;
					this.getView().byId("label3").setValue(defaultIdPrior);

					var defaultIdBy = oData.ReportedBy;
					this.getView().byId("label4").setValue(defaultIdBy);

					var defaultIdOn = oData.ReportedOn;
					this.getView().byId("date").setValue(defaultIdOn);

					var defaultIdLong = oData.LongText;
					this.getView().byId("long").setValue(defaultIdLong);

				}.bind(this),
				error: function(oError) {
					// Handle error
				}
			});
			oView.setModel(oModel);

          
            
            // Access other parameters as needed
            
            // this.getView().byId("label1").setValue(param1);
            
 
            // var oModel = new sap.ui.model.json.JSONModel({
            //     param1: param1,
            //     param2: param2
            //     // Add other parameters to the model as needed
            // });
            // this.getView().setModel(oModel);
        },
	
// 	_onRouteMatched: function(oEvent) {
//               var oArgs = oEvent.getParameter("arguments");
//     var oView = this.getView();
 
//     // Retrieve the selected data parameter
//     var sSelectedData = oArgs.selectedData;
   
// oView.byId("com1").setValue(sSelectedData.CurrentLocation);
//     // this.byId("com1").setValue(oSelectedData.CurrentLocation);
    
    
    
       
//         },
			_codeValueHelpDialog: function(sBindingObj, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog = sap.ui.xmlfragment("HostelAllocation.fragments.CodeValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._oAllValueHelpDialog) {
				this._oAllValueHelpDialog.setTitle(sBindingObj.oDialogTitle);
				this._oAllValueHelpDialog.destroyItems();
				this._oAllValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj.entityPath;
				this._oAllValueHelpDialog.bindAggregation("items", {
					path: sBindingObj.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj.entityProperties)
				});
				this._oAllValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj.customData.key,
					value: sBindingObj.customData.value
				}));
			}

			this._oAllValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog;
		},

		onCodeValueHelpRequest: function(OEvent) {

			var sBindingObj = {
				"entityPath": "codeODataModel>/ZIPMPLANTVH",
				"entityProperties": {
					title: "{path:'codeODataModel>Plant',templateSharable:true}",
					description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "Plant",
					"value": ""
				}
			};
			this._codeValueHelpDialog(sBindingObj, null);

		},

		onDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},
		
		
			_locValueHelpDialog: function(sBindingObj1, oDialogName1, filters1, stockType1) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1 = sap.ui.xmlfragment("HostelAllocation.fragments.LocationValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog1);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog1);
			}
			if (this._oAllValueHelpDialog1) {
				this._oAllValueHelpDialog1.setTitle(sBindingObj1.oDialogTitle1);
				this._oAllValueHelpDialog1.destroyItems();
				this._oAllValueHelpDialog1.destroyCustomData();
				this._sBindingValueHelpPath1 = sBindingObj1.entityPath;
				this._oAllValueHelpDialog1.bindAggregation("items", {
					path: sBindingObj1.entityPath,
					templateSharable: false,
					filters: filters1,
					template: new StandardListItem(sBindingObj1.entityProperties)
				});
				this._oAllValueHelpDialog1.addCustomData(new CustomData({
					key: sBindingObj1.customData.key,
					value: sBindingObj1.customData.value
				}));
			}

			this._oAllValueHelpDialog1.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog1;
		},

		_filters: function(sFiltersObject, conditionalFlag) {
			var arrayFilters = [],
				aFilters;
			sFiltersObject.forEach(function(element, index) {
				var operator = FilterOperator[element.filterOperator] ? FilterOperator[element.filterOperator] : FilterOperator.Contains;
				arrayFilters.push(new Filter(element.sPath, operator, element.sValue));
				//	arrayFilters.push(new Filter(element.sPath, FilterOperator.EQ, element.sValue));
			});
			aFilters = new Filter({
				filters: arrayFilters,
				and: conditionalFlag
			});
			return aFilters;
		},

		onLocationValueHelpRequest: function(OEvent) {
			//         this._filterRequired = true;

			// // var fragmentName = "PlantValueHelpDialog", // fragemntName from fragments folders
			// var filtersObject;
			var sBindingObj1 = {
				"entityPath": "codeODataModel>/ZIFUNCLOCATIONVH",
				"entityProperties": {
					title: "{path:'codeODataModel>FunctionalLocation',templateSharable:true}",
					description: "{path:'codeODataModel>FunctionalDescription',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			//var sPlant = this.getView().getModel("LocalDataModel").getProperty("/filters/Plant"),
			this._locValueHelpDialog(sBindingObj1, null);
			// 	filtersObject = [{
			// 	"sPath": "Plant",
			// 	"sValue": sPlant,
			// 	"filterOperator": "EQ"
			// }];
			// this._filtersArrayObject = this._filters(filtersObject, true);
			// this._locValueHelpDialog(sBindingObj1, null, this._filtersArrayObject);

		},

		onLocDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("com1").setValue(sTitle);

		},
		
		
			_roomValueHelpDialog: function(sBindingObj2, oDialogName2, filters2, stockType2) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2 = sap.ui.xmlfragment("HostelAllocation.fragments.RoomValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog2);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog2);
			}
			if (this._oAllValueHelpDialog2) {
				this._oAllValueHelpDialog2.setTitle(sBindingObj2.oDialogTitle1);
				this._oAllValueHelpDialog2.destroyItems();
				this._oAllValueHelpDialog2.destroyCustomData();
				this._sBindingValueHelpPath2 = sBindingObj2.entityPath;
				this._oAllValueHelpDialog2.bindAggregation("items", {
					path: sBindingObj2.entityPath,
					templateSharable: false,
					filters: filters2,
					template: new StandardListItem(sBindingObj2.entityProperties)
				});
				this._oAllValueHelpDialog2.addCustomData(new CustomData({
					key: sBindingObj2.customData.key,
					value: sBindingObj2.customData.value
				}));
			}

			this._oAllValueHelpDialog2.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog2;
		},

		onRoomValueHelpRequest: function(OEvent) {

			var sBindingObj2 = {
				"entityPath": "codeODataModel>/ZIROOMTYPEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>DomainDescription',templateSharable:true}",
					description: "{path:'codeODataModel>DomainValue',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "FunctionalLocation",
					"value": ""
				}
			};
			this._roomValueHelpDialog(sBindingObj2, null);

		},

		onRoomDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In3").setValue(sTitle);

		},
		
		
			_priorValueHelpDialog: function(sBindingObj3, oDialogName3, filters3, stockType3) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3 = sap.ui.xmlfragment("HostelAvailabilityApp.fragments.PriorityValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog3);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog3);
			}
			if (this._oAllValueHelpDialog3) {
				this._oAllValueHelpDialog3.setTitle(sBindingObj3.oDialogTitle1);
				this._oAllValueHelpDialog3.destroyItems();
				this._oAllValueHelpDialog3.destroyCustomData();
				this._sBindingValueHelpPath3 = sBindingObj3.entityPath;
				this._oAllValueHelpDialog3.bindAggregation("items", {
					path: sBindingObj3.entityPath,
					templateSharable: false,
					filters: filters3,
					template: new StandardListItem(sBindingObj3.entityProperties)
				});
				this._oAllValueHelpDialog3.addCustomData(new CustomData({
					key: sBindingObj3.customData.key,
					value: sBindingObj3.customData.value
				}));
			}

			this._oAllValueHelpDialog3.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog3;
		},

		onPriorValueHelpRequest: function(OEvent) {

			var sBindingObj3 = {
				"entityPath": "codeODataModel>/ZIPMPRIORITYVH",
				"entityProperties": {
					title: "{path:'codeODataModel>MaintPriorityDesc',templateSharable:true}",
					description: "{path:'codeODataModel>MaintPriority',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._priorValueHelpDialog(sBindingObj3, null);

		},

		onPriorDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In4").setValue(sTitle);

		},
		
			_systemValueHelpDialog: function(sBindingObj4, oDialogName4, filters4, stockType4) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4 = sap.ui.xmlfragment("HostelAllocation.fragments.SystemValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog4);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog4);
			}
			if (this._oAllValueHelpDialog4) {
				this._oAllValueHelpDialog4.setTitle(sBindingObj4.oDialogTitle1);
				this._oAllValueHelpDialog4.destroyItems();
				this._oAllValueHelpDialog4.destroyCustomData();
				this._sBindingValueHelpPath4 = sBindingObj4.entityPath;
				this._oAllValueHelpDialog4.bindAggregation("items", {
					path: sBindingObj4.entityPath,
					templateSharable: false,
					filters: filters4,
					template: new StandardListItem(sBindingObj4.entityProperties)
				});
				this._oAllValueHelpDialog4.addCustomData(new CustomData({
					key: sBindingObj4.customData.key,
					value: sBindingObj4.customData.value
				}));
			}

			this._oAllValueHelpDialog4.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog4;
		},

		onSystemValueHelpRequest: function(OEvent) {

			var sBindingObj4 = {
				"entityPath": "codeODataModel>/ZISYSTEMSTATUSVH",
				"entityProperties": {
					title: "{path:'codeODataModel>FinalStatus',templateSharable:true}",
					description: "{path:'codeODataModel>StatusKey',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "MaintPriorityDesc",
					"value": ""
				}
			};
			this._systemValueHelpDialog(sBindingObj4, null);

		},

		onSystemDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In5").setValue(sTitle);

		},
		
		
		
			_reportValueHelpDialog: function(sBindingObj5, oDialogName5, filters5, stockType5) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5 = sap.ui.xmlfragment("HostelAllocation.fragments.ReportedByValueHelpDialog", this);
				this.getView().addDependent(this._oAllValueHelpDialog5);
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog5);
			}
			if (this._oAllValueHelpDialog5) {
				this._oAllValueHelpDialog5.setTitle(sBindingObj5.oDialogTitle5);
				this._oAllValueHelpDialog5.destroyItems();
				this._oAllValueHelpDialog5.destroyCustomData();
				this._sBindingValueHelpPath5 = sBindingObj5.entityPath;
				this._oAllValueHelpDialog5.bindAggregation("items", {
					path: sBindingObj5.entityPath,
					templateSharable: false,
					filters: filters5,
					template: new StandardListItem(sBindingObj5.entityProperties)
				});
				this._oAllValueHelpDialog5.addCustomData(new CustomData({
					key: sBindingObj5.customData.key,
					value: sBindingObj5.customData.value
				}));
			}

			this._oAllValueHelpDialog5.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._oAllValueHelpDialog5;
		},

		onReportValueHelpRequest: function(OEvent) {

			var sBindingObj5 = {
				"entityPath": "codeODataModel>/ZIPMUSERNAMEVH",
				"entityProperties": {
					title: "{path:'codeODataModel>UserName',templateSharable:true}",
					description: "{path:'codeODataModel>LongName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "UserName",
					"value": ""
				}
			};
			this._reportValueHelpDialog(sBindingObj5, null);

		},

		onReportDialogClose: function(oEvent) {

			var sTitle = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In1").setValue(sTitle);

		},
		
			_RequestNumValueHelpDialog: function(sBindingObj10, oDialogName, filters, stockType) {
			this._customDataValue = "";
			//	var oAllValueHelpDialog = oDialogName;
			if (!this._NumValueHelpDialog) {
				this._NumValueHelpDialog = sap.ui.xmlfragment("HostelAllocation.fragments.RequestNum", this);
				this.getView().addDependent(this._NumValueHelpDialog);
				// jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAllValueHelpDialog);
			}
			if (this._NumValueHelpDialog) {
				this._NumValueHelpDialog.setTitle(sBindingObj10.oDialogTitle);
				this._NumValueHelpDialog.destroyItems();
				this._NumValueHelpDialog.destroyCustomData();
				this._sBindingValueHelpPath = sBindingObj10.entityPath;
				this._NumValueHelpDialog.bindAggregation("items", {
					path: sBindingObj10.entityPath,
					templateSharable: false,
					filters: filters,
					template: new StandardListItem(sBindingObj10.entityProperties)
				});
				this._NumValueHelpDialog.addCustomData(new CustomData({
					key: sBindingObj10.customData.key,
					value: sBindingObj10.customData.value
				}));
			}

			this._NumValueHelpDialog.open();
			//	this._currentDialog = oAllValueHelpDialog;
			return this._NumValueHelpDialog;
		},

		onRequestNumValueHelp: function(OEvent) {

			var sBindingObj10 = {
				"entityPath": "codeODataModel>/ZIPMNOTIFICATIONSVH",
				"entityProperties": {
					title: "{path:'codeODataModel>Notification',templateSharable:true}"
					// description: "{path:'codeODataModel>PlantName',templateSharable:true}"
				},
				// "oDialogTitle": this.getTextFromBundle("SELECT_PROCESS_ORDER"),
				"customData": {
					"key": "NotifNo",
					"value": ""
				}
			};
			this._RequestNumValueHelpDialog(sBindingObj10, null);

		},
	    onNumDialogClose: function(oEvent) {

			var sTitle10 = oEvent.getParameter("selectedItem").getTitle();
			this.getView().byId("In7").setValue(sTitle10);

		},
		
		onGo:function(){
			var oTable = this.getView().byId("HostelAllocation");
			var selectedValue = this.byId("In3").getValue();
			var selectedValue1 = this.byId("In1").getValue();
			// var selectedValue2 = this.byId("In4").getValue();
			// var selectedValue3 = this.byId("In3").getValue();
			var selectedValue4 = this.byId("In6").getValue();
			var selectedValue5 = this.byId("In5").getValue();
			// var selectedValue6 = this.byId("In8").getValue();
			var selectedValue7 = this.byId("In7").getValue();

			var aFilters = [];

			// Construct filters
			if (selectedValue) {
			aFilters.push(new sap.ui.model.Filter("CollegeCode", sap.ui.model.FilterOperator.EQ, selectedValue));
			}

			if (selectedValue1) {
				aFilters.push( new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue1));
			}

			if (selectedValue4) {
			aFilters.push(new sap.ui.model.Filter("CurrentLocation", sap.ui.model.FilterOperator.EQ, selectedValue4));
			}
			// if (selectedValue3) {
			// aFilters.push(new sap.ui.model.Filter("RoomType", sap.ui.model.FilterOperator.EQ, selectedValue3));
			// }
			
			if (selectedValue4) {
			aFilters.push(new sap.ui.model.Filter("ReportedBy", sap.ui.model.FilterOperator.EQ, selectedValue4));
			}
			
			if (selectedValue5) {
			aFilters.push(new sap.ui.model.Filter("SystemStatus", sap.ui.model.FilterOperator.EQ, selectedValue5));
			}
			if (selectedValue7) {
			aFilters.push(new sap.ui.model.Filter("Notification", sap.ui.model.FilterOperator.EQ, selectedValue7));
			}
			
			

			// Apply filters to the table binding
			oTable.getBinding("items").filter(aFilters);

		

		},
			onNavBack: function() {

			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("Allocation", {}, true);

		},
			
		
		
			onSubmit: function() {
			var oView = this.getView();
			var oModel = "/sap/opu/odata/sap/ZSL_HOSTEL_ALLOCATION_SRV/CreateNotificationSet";
			// ZSL_HOSTEL_ALLOCATION_SRV/CreateNotificationSet('000010000000')
		
			// var dateValue = oView.byId("date16").getDateValue();
			// var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
			// 	pattern: "yyyyMMdd"
			// });
			var ref = this.param1;

			var oData = {

				CollegeCode: oView.byId("label1").getValue(),
			    // RequestType: oView.byId("label2").getSelectedItem().getText(),
				RequestType:  oView.byId("label2").getValue() ,
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
				RoomType:  oView.byId("room1").getValue(),
				RequestDate: oView.byId("date1").getValue(),
				// RequestDate: dateFormat.format(dateValue),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority:  oView.byId("label3").getValue(),
				ReportedBy:  oView.byId("label4").getValue(),
				ReportedOn: oView.byId("date").getValue(),
				NotificationNumber: ref,
				Message: "X",
				Location: oView.byId("com1").getValue()

				// Add other properties as needed
			};
			var supdateurl = oModel + "('" + ref + "')";
			$.ajax({
				url: supdateurl,
				method: "PUT",
				contentType: "application/json",
				data: JSON.stringify(oData),

				success: function(response, selectedIndices) {
					// MessageBox.success("Notification updated successfully" + ref);
					// var d = response.querySelector("Message").textContent;
				
				
						
				MessageBox.success("Ticket Number" + "'" +  ref +"'" + "successfully updated");
				

				

				

				}.bind(this),
				error: function(error) {
					// Handle error response
						MessageBox.error("Ticket Number" + "'" + ref  + "'" + "is already submitted Please Select other Number");
				
				}
			});
		

		},
		
		

	});
});