sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageBox"
], function(Controller, History, MessageBox) {
	"use strict";

	return Controller.extend("HostelFacility.controller.ChangeScreen", {

		onInit: function() {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.getRoute("ChangeScreen").attachPatternMatched(this._onRouteMatched, this);
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.getRoute("ChangeScreen").attachMatched(this._onRouteMatched, this);

		},
		// _onRouteMatched: function(oEvent) {
		// 	var selectedData = oEvent.getParameter("arguments").selectedData;

		// 	var oModel = new sap.ui.model.json.JSONModel({
		// 		selectedData: [{
		// 			value: selectedData

		// 		}]
		// 	});
		// 	var oTable = this.getView().byId("tableId"); // Assuming tableId is the ID of your table
		// 	oTable.setModel(oModel);
		// },

		// _onRouteMatched: function(oEvent) {
		// 	var code = oEvent.getParameter("arguments").Code;
		// 	var prior = oEvent.getParameter("arguments").Priority;
		// 	var note = oEvent.getParameter("arguments").Notification;
		// 	var by = oEvent.getParameter("arguments").By;
		// 	var on = oEvent.getParameter("arguments").On;
		// 	var oModel = new sap.ui.model.json.JSONModel({
		// 		selectedData: [{
		// 			value: code,
		// 			value1: prior,
		// 			value2: note,
		// 			value3: by,
		// 			value4: on

		// 		}]
		// 	});
		// 	var oTable = this.getView().byId("tableId"); // Assuming tableId is the ID of your table
		// 	oTable.setModel(oModel);

		// },

		onNav: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View", {}, true);
			}

		},

		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View1", {}, true);
			}
		},

		onCreate: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/"; // Replace this with your actual service URL
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			// Set the model to the view
			this.getView().setModel(oModel);

			var oTable = this.getView().byId("tableId");
			var aSelectedItems = oTable.getSelectedItems();
		
			var aData = [];
			aSelectedItems.forEach(function(oItem) {
				var oBindingContext = oItem.getBindingContext();
				var oSelectedData = oBindingContext.getObject();
				aData.push(oSelectedData);
			});
			
			var oPayload ={
				"data" : aData
			};
			oModel.create("/CreateNotificationSet", oPayload, {
				success: function(oData, response) {
					// Handle success response
					
					MessageBox.success("created successfully");
				},
				error: function(oError) {
					// Handle error response
						MessageBox.error("getting error");
				}
			});
		}

	});
});