sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(Controller, History, MessageToast, MessageBox) {
	"use strict";
	var selectedCheckboxText = "";

	return Controller.extend("HostelFacility.controller.HostelData", {

		onInit: function() {
				var oModel = this.getOwnerComponent().getModel("MainModel");
				this.getView().setModel(oModel, "newModel");

		},
			onHostelSubmit: function(oEvent) {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// oRouter.navTo("ChangeData");
		},
			onNavBack:function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View1", {}, true);
			}
		},
		
			onCheckboxSelect: function(oEvent) {
			selectedCheckboxText = oEvent.getSource().getText(); // Store the text of the selected checkbox
			var oView = this.getView();
			var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			for (var i = 0; i < aCheckboxes.length; i++) {
				if (aCheckboxes[i] !== oEvent.getSource()) {
					aCheckboxes[i].setEditable(oEvent.getSource().getSelected() ? false : true);
				}
			}

		},
		
			onSubmit: function(oEvent) {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// // oRouter.navTo("ChangeScreen");

			// // var selectedData =	this.getView().byId("label1").getSelectedItem().getText();

			// // 		oRouter.navTo("ChangeScreen",{
			// // 			selectedData:selectedData

			// // 		});

			// var selectedData = this.getView().byId("label1").getSelectedItem().getText();
			// var selectedData1 = this.getView().byId("label3").getSelectedItem().getText();
			// var selectedData2 = this.getView().byId("label8").getSelectedItem().getText();
			// var selectedData3 = this.getView().byId("label4").getSelectedItem().getText();
			// var selectedData4 = this.getView().byId("date").getValue();

			// oRouter.navTo("ChangeScreen", {
			// 	Code: selectedData,
			// 	Priority: selectedData1,
			// 	Notification: selectedData2,
			// 	By: selectedData3,
			// 	On: selectedData4

			// });

			var oView = this.getView();

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/");
			// Add headers to the request
			var mHeaders = {
				"Content-Type": "application/json"
					// Add more headers as needed
			};
			var oPayload = {
				CollegeCode: oView.byId("label1").getSelectedItem().getText(),
				RequestType: oView.byId("label2").getSelectedItem().getText(),
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
                RoomType:selectedCheckboxText,
				RequestDate: oView.byId("date1").getValue(),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority: oView.byId("label3").getSelectedItem().getText().split("-")[0],
				ReportedBy: oView.byId("label4").getSelectedItem().getText(),
				ReportedOn: oView.byId("date").getValue(),
				NotificationNumber: "",
				Message: ""

			};
			oModel.create("/CreateNotificationSet", oPayload, {
				headers: mHeaders,
				success: function(data) {
					MessageBox.success("created successfully");
					var successMessage = data.message;
					MessageBox.success("created successfully", successMessage);

				},
				error: function(err) {
					var errmsg = err.message;
					MessageBox.error(errmsg);

				}
			});
		}
		
	

	});
});