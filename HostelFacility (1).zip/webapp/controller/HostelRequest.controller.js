sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox"
], function(Controller, History, MessageToast, ODataModel, MessageBox) {
	"use strict";
	var selectedCheckboxText = "";
	return Controller.extend("HostelFacility.controller.HostelRequest", {

		onInit: function() {

			this.onReadCollageData();
			this.onReadProrityData();
			this.onReadResponsibiltyData();
			this.onReadNotificationData();

		},

		onReadCollageData: function() {
			var oDropdown = this.getView().byId("label1");
			var oCollageModel = this.getOwnerComponent().getModel("MainModel");

			oCollageModel.read("/CollegeCodeVHSet", {
				success: function(oData) {

					oDropdown.setModel(new sap.ui.model.json.JSONModel(oData.results));

				}.bind(this),
				error: function(err) {

				}
			});

			// var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			// var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			// this.getView().setModel(oModel);

			// var oDropdown = this.getView().byId("label1");
			// oModel.read("/CollegeCodeVHSet", {
			// 	success: function(oData, oResponse) {
			// 		var oModel1 = new sap.ui.model.json.JSONModel();
			// 		oModel.setData(oData);
			// 		oDropdown.setModel(oModel1);
			// 	},
			// 	error: function(oError) {
			// 		// Handle error
			// 	}
			// });

		},

		onReadProrityData: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label3");
			oModel.read("/PriorityVHSet", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		onReadResponsibiltyData: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);

			var oDropdown = this.getView().byId("label4");
			oModel.read("/ResponsibilitiesSet", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);

					// Set the binding path of date picker control
					var oDatePicker = this.getView().byId("date");
					oDatePicker.bindProperty("value", {
						path: "ReportedOn"
					});
				},
				error: function(oError) {
					// Handle error
				}
			});

			// oModel.read("/ResponsibilitiesSet", {
			// 	success: function(response) {
			// 		var resarry = response.results;
			// 		this.getView().byId("By").setText(resarry[0].ReportedBy);
			// 		this.getView().byId("date").setValue(resarry[0].ReportedOn);

			// 	}.bind(this),
			// 	error: function(error) {
			// 		//MessageBox.error("technical problem ");
			// 	}
			// });

		},
		onReadNotificationData: function() {

			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);
			var oDropdown = this.getView().byId("label2");
			oModel.read("/I_PMNotificationTypeStdVH", {
				success: function(oData, oResponse) {
					var oModel1 = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					oDropdown.setModel(oModel1);
				},
				error: function(oError) {
					// Handle error
				}
			});

		},

		// onSubmit: function(oEvent) {
		// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 	// oRouter.navTo("ChangeScreen");

		// 	// var selectedData =	this.getView().byId("label1").getSelectedItem().getText();

		// 	// 		oRouter.navTo("ChangeScreen",{
		// 	// 			selectedData:selectedData

		// 	// 		});

		// 	var selectedData = this.getView().byId("label1").getSelectedItem().getText();
		// 	var selectedData1 = this.getView().byId("label3").getSelectedItem().getText();
		// 	var selectedData2 = this.getView().byId("label8").getSelectedItem().getText();
		// 	var selectedData3 = this.getView().byId("label4").getSelectedItem().getText();
		// 	var selectedData4 = this.getView().byId("date").getValue();

		// 	oRouter.navTo("ChangeScreen", {
		// 		Code: selectedData,
		// 		Priority: selectedData1,
		// 		Notification: selectedData2,
		// 		By: selectedData3,
		// 		On: selectedData4

		// 	});

		// },

		onUploadButtonPress: function() {
			var fileUploader = this.byId("fileUploader");
			fileUploader.upload();
		},
		onFileUploadChange: function(event) {
			var uploadedFile = event.getParameter("files")[0];
			if (uploadedFile) {
				MessageToast.show("File selected: " +
					uploadedFile.name
				);
				this.handleFile(uploadedFile);
			} else {
				MessageToast.show("No file selected");
			}
		},
		handleFile: function(file) {
			var fileType = file.type.toLowerCase();
			if (fileType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
				// Excel file handling
				this.handleExcelFile(file);
			} else if (fileType === "text/csv") {
				// CSV file handling
				this.handleCsvFile(file);
			} else if (fileType.startsWith("image/")) {
				// Image file handling
				this.handleImageFile(file);
			} else if (fileType === "text/plain") {
				// Text file handling
				this.handleTextFile(file);
			} else {
				// Unsupported file type
				MessageToast.show("Unsupported file type. Please select a valid file.");
			}
		},
		handleExcelFile: function(file) {
			// Handle Excel file parsing
			MessageToast.show("Excel file uploaded: " +
				file.name
			);
		},
		handleCsvFile: function(file) {
			// Handle CSV file parsing
			MessageToast.show("CSV file uploaded: " +
				file.name
			);
		},
		handleImageFile: function(file) {
			// Handle image file parsing
			MessageToast.show("Image file uploaded: " +
				file.name
			);
		},
		handleTextFile: function(file) {
			// Handle text file parsing
			MessageToast.show("Text file uploaded: " +
				file.name
			);
		},
		onFileUploadComplete: function(event) {
			var response = event.getParameter("response");
			if (response) {
				MessageToast.show("File uploaded successfully");
			} else {
				MessageToast.show("File upload failed");
			}
		},

		onAddLink: function(oDialogName) {
			// if (!oDialogName) {
			// 			oDialogName = sap.ui.xmlfragment("HostelFacility.fragment.AddLink" , this);
			// 			this.getView().addDependent(oDialogName);
			// 		}
			// 	oDialogName.open();
			// }
			this._Dialog = sap.ui.xmlfragment("HostelFacility.fragment.AddLink",
				this);
			this._Dialog.open();

		},
		onOk: function() {
			this._Dialog.close();
		},
		onNavBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("View1", {}, true);
			}
		},

		onCheckboxSelect: function(oEvent) {
			// var oSourceCheckbox = oEvent.getSource();
			// var oView = this.getView();
			// var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			// for (var i = 0; i < aCheckboxes.length; i++) {
			// 	if (aCheckboxes[i] !== oSourceCheckbox) {
			// 		aCheckboxes[i].setEditable(oSourceCheckbox.getSelected() ? false : true);
			// 	}
			// }
			selectedCheckboxText = oEvent.getSource().getText(); // Store the text of the selected checkbox
			var oView = this.getView();
			var aCheckboxes = [oView.byId("checkbox1"), oView.byId("checkbox2"), oView.byId("checkbox3")];
			for (var i = 0; i < aCheckboxes.length; i++) {
				if (aCheckboxes[i] !== oEvent.getSource()) {
					aCheckboxes[i].setEditable(oEvent.getSource().getSelected() ? false : true);
				}
			}

		},

		onCreate: function() {
			var sServiceUrl = "/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/"; // Replace this with your actual service URL
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl);
			// Set the model to the view
			this.getView().setModel(oModel);

			var oTable = this.getView().byId("tableId");
			var aSelectedItems = oTable.getSelectedItems();

			var aData = [];
			aSelectedItems.forEach(function(oItem) {
				var oBindingContext = oItem.getBindingContext();
				var oSelectedData = oBindingContext.getObject();
				aData.push(oSelectedData);
			});

			var oPayload = {
				"data": aData
			};
			oModel.create("/CreateNotificationSet", oPayload, {
				success: function(oData, response) {
					// Handle success response

					MessageBox.success("created successfully");
				},
				error: function(oError) {
					// Handle error response
					MessageBox.error("getting error");
				}
			});
		},

		onSubmit: function(oEvent) {
			// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// // oRouter.navTo("ChangeScreen");

			// // var selectedData =	this.getView().byId("label1").getSelectedItem().getText();

			// // 		oRouter.navTo("ChangeScreen",{
			// // 			selectedData:selectedData

			// // 		});

			// var selectedData = this.getView().byId("label1").getSelectedItem().getText();
			// var selectedData1 = this.getView().byId("label3").getSelectedItem().getText();
			// var selectedData2 = this.getView().byId("label8").getSelectedItem().getText();
			// var selectedData3 = this.getView().byId("label4").getSelectedItem().getText();
			// var selectedData4 = this.getView().byId("date").getValue();

			// oRouter.navTo("ChangeScreen", {
			// 	Code: selectedData,
			// 	Priority: selectedData1,
			// 	Notification: selectedData2,
			// 	By: selectedData3,
			// 	On: selectedData4

			// });

			var oView = this.getView();

			var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZSL_HOSTEL_FACILITY_SRV/");
			// Add headers to the request
			var mHeaders = {
				"Content-Type": "application/json"
					// Add more headers as needed
			};
			var oPayload = {
				CollegeCode: oView.byId("label1").getSelectedItem().getText(),
				RequestType: oView.byId("label2").getSelectedItem().getText(),
				// RoomType: oView.byId("checkbox1").getSelected().toString(),
                RoomType:selectedCheckboxText,
				RequestDate: oView.byId("date1").getValue(),
				Description: oView.byId("dis").getValue(),
				LongText: oView.byId("long").getValue(),
				Priority: oView.byId("label3").getSelectedItem().getText().split("-")[0],
				ReportedBy: oView.byId("label4").getSelectedItem().getText(),
				ReportedOn: oView.byId("date").getValue(),
				NotificationNumber: "",
				Message: ""

			};
			oModel.create("/CreateNotificationSet", oPayload, {
				headers: mHeaders,
				success: function(data) {
					MessageBox.success("created successfully");
					var successMessage = data.message;
					MessageBox.success("created successfully", successMessage);

				},
				error: function(err) {
					var errmsg = err.message;
					MessageBox.error(errmsg);

				}
			});
		}

	});
});