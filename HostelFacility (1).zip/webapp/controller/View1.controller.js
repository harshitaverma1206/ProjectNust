sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("HostelFacility.controller.View1", {

		onInit: function() {},

		onSubmit: function(oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ChangeScreen");
		},

		onUploadButtonPress: function() {
			var fileUploader = this.byId("fileUploader");
			fileUploader.upload();
		},
		onFileUploadChange: function(event) {
			var uploadedFile = event.getParameter("files")[0];
			if (uploadedFile) {
				MessageToast.show("File selected: " +
					uploadedFile.name
				);
				this.handleFile(uploadedFile);
			} else {
				MessageToast.show("No file selected");
			}
		},
		handleFile: function(file) {
			var fileType = file.type.toLowerCase();
			if (fileType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
				// Excel file handling
				this.handleExcelFile(file);
			} else if (fileType === "text/csv") {
				// CSV file handling
				this.handleCsvFile(file);
			} else if (fileType.startsWith("image/")) {
				// Image file handling
				this.handleImageFile(file);
			} else if (fileType === "text/plain") {
				// Text file handling
				this.handleTextFile(file);
			} else {
				// Unsupported file type
				MessageToast.show("Unsupported file type. Please select a valid file.");
			}
		},
		handleExcelFile: function(file) {
			// Handle Excel file parsing
			MessageToast.show("Excel file uploaded: " +
				file.name
			);
		},
		handleCsvFile: function(file) {
			// Handle CSV file parsing
			MessageToast.show("CSV file uploaded: " +
				file.name
			);
		},
		handleImageFile: function(file) {
			// Handle image file parsing
			MessageToast.show("Image file uploaded: " +
				file.name
			);
		},
		handleTextFile: function(file) {
			// Handle text file parsing
			MessageToast.show("Text file uploaded: " +
				file.name
			);
		},
		onFileUploadComplete: function(event) {
			var response = event.getParameter("response");
			if (response) {
				MessageToast.show("File uploaded successfully");
			} else {
				MessageToast.show("File upload failed");
			}
		},

		onAddLink: function(oDialogName) {
		// if (!oDialogName) {
		// 			oDialogName = sap.ui.xmlfragment("HostelFacility.fragment.AddLink" , this);
		// 			this.getView().addDependent(oDialogName);
		// 		}
		// 	oDialogName.open();
		// }
		  this._Dialog = sap.ui.xmlfragment("HostelFacility.fragment.AddLink",
                                this);
                this._Dialog.open();
			
		},
		 onOk : function() {
                this._Dialog.close();
    },
    
    onPressRequest:function(oEvent){
    		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("HostelRequest");
    },
    onPressData:function(oEvent){
    	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("HostelData");
	},
	onPressVacate:function(oEvent){
			var oRouter1 = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter1.navTo("ChangeScreen");
	}
    

	});
});