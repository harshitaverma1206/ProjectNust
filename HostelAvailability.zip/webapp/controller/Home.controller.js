sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
"sap/ui/model/FilterOperator"
], function(Controller, JSONModel, Fragment, Filter, FilterOperator ) {
	"use strict";

	return Controller.extend("HostelAvailability.controller.Home", {
		onInit: function() {
			// Access the OData model defined in the manifest
			// this.oDataModel = this.getOwnerComponent().getModel("ODataModel");

			var oModel = this.getOwnerComponent().getModel("ODataModel");
			this.getView().setModel(oModel, "MainModel");

		},
		onCodeOpenDialog: function(oEvent) {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("HostelAvailability.fragments.CodeDialog", this);
				this.getView().addDependent(this._oDialog);

			}
			this._oDialog.open();

		},
		onClose: function() {
			this._oDialog.close();
		},
		onListItemPress: function(oEvent) {

			//      var sTitle = oEvent.getParameter("selectedItem").getTitle();
			// this.getView().byId("inputField").setValue(sTitle);
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				var sSelectedName = oSelectedItem.getTitle(); // Assuming the title contains the value you want to display
				var oInputField = this.byId("inputField1"); // Replace with the ID of your input field
				oInputField.setValue(sSelectedName);
			}

			// Get the selected value from the first input field

		},

		onChange: function(oEvent) {
			var sSelectedValue = oEvent.getParameter("value");
			var oInput2 = this.getView().byId("inputField2");
			var oBinding = oInput2.getBinding("value");
			if (oBinding) {
				var oFilter = new Filter("Plant", FilterOperator.EQ, sSelectedValue);
				oBinding.filter([oFilter]);
			}
		},

			onLocOpenDialog: function() {
			if (!this._oDialog1) {
				this._oDialog1 = sap.ui.xmlfragment("HostelAvailability.fragments.LocDialog", this);
				this.getView().addDependent(this._oDialog1);

			}
			this._oDialog1.open();
		},
		onLocClose: function() {
			this._oDialog1.close();
		},

		onLocListItemPress: function(oEvent) {

			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				var sSelectedName = oSelectedItem.getTitle(); // Assuming the title contains the value you want to display
				var oInputField = this.byId("inputField2"); // Replace with the ID of your input field
				oInputField.setValue(sSelectedName);
			}

		}

		// Fetch data from OData service
		// fetchDataFromOData: function() {
		// 	var that = this;
		// 	this.oDataModel.read("/ZIPMPLANTVH", {
		// 		success: function(oData, response) {
		// 			// Process data and add it to the dialog's content

		// 			var oDialogModel = new JSONModel(oData);
		// 			that._oDialog.setModel(oDialogModel, "odata");
		// 		},
		// 		error: function(error) {
		// 			// Handle error
		// 		}
		// 	});
		// }

	});
});