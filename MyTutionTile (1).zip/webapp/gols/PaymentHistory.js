sap.ui.define(["sap/ui/core/library", 'sap/uxap/BlockBase'], function (coreLibrary, BlockBase) {
	"use strict";

	var ViewType = coreLibrary.mvc.ViewType;

	var PaymentHistory = BlockBase.extend("MyTutionTile.gols.PaymentHistory", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "MyTutionTile.gols.PaymentHistory",
					type: ViewType.XML
				},
				Expanded: {
					viewName: "MyTutionTile.gols.PaymentHistory",
					type: ViewType.XML
				}
			}
		}
	});
	return PaymentHistory;
});