sap.ui.define(["sap/ui/core/library", 'sap/uxap/BlockBase'], function (coreLibrary, BlockBase) {
	"use strict";

	var ViewType = coreLibrary.mvc.ViewType;

	var DownloadReceipt = BlockBase.extend("MyTutionTile.gols.DownloadReceipt", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "MyTutionTile.gols.DownloadReceipt",
					type: ViewType.XML
				},
				Expanded: {
					viewName: "MyTutionTile.gols.DownloadReceipt",
					type: ViewType.XML
				}
			}
		}
	});
	return DownloadReceipt;
});