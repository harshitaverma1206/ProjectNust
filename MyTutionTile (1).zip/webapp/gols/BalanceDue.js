sap.ui.define(["sap/ui/core/library", 'sap/uxap/BlockBase'], function (coreLibrary, BlockBase) {
	"use strict";

	var ViewType = coreLibrary.mvc.ViewType;

	var BalanceDue = BlockBase.extend("MyTutionTile.gols.BalanceDue", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "MyTutionTile.gols.BalanceDue",
					type: ViewType.XML
				},
				Expanded: {
					viewName: "MyTutionTile.gols.BalanceDue",
					type: ViewType.XML
				}
			}
		}
	});
	return BalanceDue;
});