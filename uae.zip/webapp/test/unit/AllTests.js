sap.ui.define([
	"uae/test/unit/controller/Page1.controller"
], function () {
	"use strict";
});
