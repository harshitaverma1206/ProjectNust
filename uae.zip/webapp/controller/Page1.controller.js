sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
],

    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */

    function (Controller, JSONModel) {
        "use strict";

        return Controller.extend("uae.controller.Page1", {
            onInit: function () {
                this.data = {
                    items: [
                    ]
                };
                this.localModel = new JSONModel();
                this.localModel.setData(this.data);
                this.getView().setModel(this.localModel, "localModel");
                this.getView().byId("Hbid").setVisible(false);

            },
            AddBtnPressed: function (oEvent) {
                var output1 = this.getView().byId("id1").getSelectedItem().getText(),
                    output2 = this.getView().byId("id2").getSelectedItem().getText(),
                    output3 = this.getView().byId("id3").getSelectedItem().getText(),
                    output4 = this.getView().byId("id4").getSelectedItem().getText(),
                    output5 = this.getView().byId("id5").getSelectedItem().getText(),
                    output6 = this.getView().byId("id6").getSelectedItem().getText()
                    ;
                var Button1 = this.getView().byId("btn1"),
                    Button2 = this.getView().byId("btn2"),
                    Button3 = this.getView().byId("btn3"),
                    Button4 = this.getView().byId("btn4"),
                    Button5 = this.getView().byId("btn5"),
                Button6 = this.getView().byId("btn6");

                Button1.setText(output1);
                Button2.setText(output2);
                Button3.setText(output3);
                Button4.setText(output4);
                Button5.setText(output5);
                Button6.setText(output6);


                this.getView().byId("btns").setVisible(true);

                this.getView().byId("btn1").addStyleClass("size");



                var value1= this.getView().byId("id1").getSelectedItem().getText();
                var value2= this.getView().byId("id2").getSelectedItem().getText();
                var value3= this.getView().byId("id3").getSelectedItem().getText();

                var value4= this.getView().byId("id1").getSelectedItem().getText();
                var value5= this.getView().byId("id2").getSelectedItem().getText();
                var value6= this.getView().byId("id3").getSelectedItem().getText();


                var value7= this.getView().byId("id1").getSelectedItem().getText();
                var value8= this.getView().byId("id2").getSelectedItem().getText();
                var value9= this.getView().byId("id3").getSelectedItem().getText();


                var value10= this.getView().byId("id1").getSelectedItem().getText();
                var value11= this.getView().byId("id2").getSelectedItem().getText();
                var value12= this.getView().byId("id3").getSelectedItem().getText();
               

                var newCondition = true;
                if(newCondition){
                if(value1==="Bauxite ore" && value2==="Refinery" && value3==="Electricity"){
                    this.getView().byId("out1").setText("2.5tCO2");

                }
                if(value4==="Baking Mix" && value5==="Oven" && value6==="Natural Gas"){
                    this.getView().byId("out1").setText("2.1tCO2");

                }
                if(value7==="Coco" && value8==="Crusher" && value9==="Diesl"){
                    this.getView().byId("out1").setText("1.2tCO2");

                }
                if(value10==="Iron Ore" && value11==="Coke Oven" && value12==="Fossil Fuel"){
                    this.getView().byId("out1").setText("3.5tCO2");

                }
                // else{
                 
                // }
            }
            
            
                
            

                

            },
            SimulateBtnPressed: function () {
                this.getView().byId("Hbid").setVisible(true);
                // var finishedProduct=this.getView().byId("id6").getSelectedItem().getText();
                // this.getView().byId("In6").setValue(finishedProduct);



                // this.getView().byId("btns").setVisible(false);      
            },
            RunSimulateBtnPressed: function () {
                var input1 = this.getView().byId("In1").getValue(),
                    input2 = this.getView().byId("In2").getValue(),
                    input3 = this.getView().byId("In3").getValue(),
                    input4 = this.getView().byId("In4").getValue(),
                    input5 = this.getView().byId("In5").getValue(),
                    Input6 = this.getView().byId("In6").getValue();


                var InputBtn1 = this.getView().byId("Inbtn1"),
                    InputBtn2 = this.getView().byId("Inbtn2"),
                    InputBtn3 = this.getView().byId("Inbtn3"),
                    InputBtn4 = this.getView().byId("Inbtn4"),
                    InputBtn5 = this.getView().byId("Inbtn5"),
                    InputBtn6 = this.getView().byId("Inbtn6");
                    
                    
                InputBtn6.setText(Input6);

                InputBtn1.setText(input1);
                InputBtn2.setText(input2);
                InputBtn3.setText(input3);
                InputBtn4.setText(input4);
                InputBtn5.setText(input5);

                this.getView().byId("Ifbtn").setVisible(true);



                var value7= this.getView().byId("In1").getValue();
                if(value7==="1000T"){
                    this.getView().byId("out2").setText("1.72tCO2");

                }
                else{

                }


            },
            onReset: function () {
                this.getView().byId("btns").setVisible(false);
                this.getView().byId("Ifbtn").setVisible(false);
                this.getView().byId("Hbid").setVisible(false);


                var drop1 = this.byId("company");
                var drop2 = this.byId("entity");
                var drop3 = this.byId("Entity1Id");
                var drop4 = this.byId("id1");
                var drop5 = this.byId("id2");
                var drop6 = this.byId("id3");
                var drop7 = this.byId("id4");
                var drop8 = this.byId("id5");
                var drop9 = this.byId("id6");
                var in1 = this.byId("In1");
                var in2 = this.byId("In2");
                var in3 = this.byId("In3");
                var in4 = this.byId("In4");
                var in5 = this.byId("In5");
                var in6 = this.byId("In6");

                 


                drop1.setSelectedKey("");
                drop2.setSelectedKey("");
                drop3.setSelectedKey("");
                drop4.setSelectedKey("");
                drop5.setSelectedKey("");
                drop6.setSelectedKey("");
                drop7.setSelectedKey("");
                drop8.setSelectedKey("");
                drop9.setSelectedKey("");
                in1.setSelectedKey("");
                in2.setSelectedKey("");
                in3.setSelectedKey("");
                in4.setSelectedKey("");
                in5.setSelectedKey("");
                in6.setSelectedKey("");
                

                // this.getView().getModel().refresh();

                // second dropdownlist

                this.getView().byId("out1").setText("");
                this.getView().byId("out2").setText("");




            },
            onRefresh: function () {
                location.reload();
            }
        });
    });
